import { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { ClusterVisualizer } from './components/ClusterVisualizer';
import { ObjectBrowser } from './components/ObjectBrowser';
import { ChaosLab } from './components/ChaosLab';
import { BenchmarkSuite } from './components/BenchmarkSuite';
import { ArchitectureDocs } from './components/ArchitectureDocs';
import { AuditLogs } from './components/AuditLogs';
import { QuotaManager } from './components/QuotaManager';
import { RecoveryWizard } from './components/RecoveryWizard';
import { AuthModal } from './components/AuthModal';
import { NotificationCenter } from './components/NotificationCenter';

import { StorageEngine } from './services/storageEngine';
import { AuthService } from './services/authService';
import { OfflineSyncService } from './services/offlineSyncService';
import { StorageNode, StorageObject, ClusterEvent, RepairJob, UserAccount } from './types/storage';
import { useDeviceTilt } from './hooks/useDeviceTilt';

export default function App() {
  const [activeTab, setActiveTab] = useState<'cluster' | 'objects' | 'quotas' | 'chaos' | 'benchmark' | 'audit' | 'architecture'>('cluster');
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('aetherstore_theme');
      return saved ? saved === 'dark' : true;
    }
    return true;
  });

  const [nodes, setNodes] = useState<StorageNode[]>([]);
  const [objects, setObjects] = useState<StorageObject[]>([]);
  const [events, setEvents] = useState<ClusterEvent[]>([]);
  const [repairJobs, setRepairJobs] = useState<RepairJob[]>([]);
  const [user, setUser] = useState<UserAccount | null>(null);

  const [isOnline, setIsOnline] = useState(true);
  const [pendingSyncCount, setPendingSyncCount] = useState(0);

  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isRecoveryWizardOpen, setIsRecoveryWizardOpen] = useState(false);
  const [recoveryTargetObjectId, setRecoveryTargetObjectId] = useState<string | null>(null);
  const [toastAlert, setToastAlert] = useState<{ type: string; title: string; msg: string } | null>(null);

  const tilt = useDeviceTilt();

  const handleOpenRecoveryWizard = (objectId?: string) => {
    setRecoveryTargetObjectId(objectId || null);
    setIsRecoveryWizardOpen(true);
  };

  // Initialize and subscribe to services
  useEffect(() => {
    StorageEngine.init();
    AuthService.init();
    OfflineSyncService.init();

    const unsubStorage = StorageEngine.subscribe(() => {
      setNodes(StorageEngine.getNodes());
      setObjects(StorageEngine.getObjects());
      setEvents(StorageEngine.getEvents());
      setRepairJobs(StorageEngine.getRepairJobs());
    });

    const unsubAuth = AuthService.subscribe(u => {
      setUser(u);
    });

    const unsubSync = OfflineSyncService.subscribe((online, count) => {
      setIsOnline(online);
      setPendingSyncCount(count);
    });

    // Populate initial state
    setNodes(StorageEngine.getNodes());
    setObjects(StorageEngine.getObjects());
    setEvents(StorageEngine.getEvents());
    setRepairJobs(StorageEngine.getRepairJobs());
    setUser(AuthService.getUser());

    return () => {
      unsubStorage();
      unsubAuth();
      unsubSync();
    };
  }, []);

  // Theme synchronization
  useEffect(() => {
    localStorage.setItem('aetherstore_theme', isDarkMode ? 'dark' : 'light');
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const notify = (type: 'success' | 'warning' | 'error' | 'info', title: string, msg: string) => {
    StorageEngine.logEvent(type, title, msg);
    setToastAlert({ type, title, msg });
    setTimeout(() => {
      setToastAlert(null);
    }, 4000);
  };

  return (
    <div
      className={`min-h-screen relative flex flex-col font-sans selection:bg-cyan-500/20 selection:text-cyan-900 dark:selection:text-cyan-200 transition-colors duration-300 ${
        isDarkMode ? 'bg-[#060B14] text-slate-100' : 'bg-slate-50 text-slate-900'
      }`}
    >
      {/* 3D Liquid Glass Ambient Dynamic Lights & Glow Background */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div
          className={`absolute -top-40 -left-40 w-96 h-96 rounded-full blur-3xl transition-transform duration-500 ease-out ${
            isDarkMode ? 'opacity-30' : 'opacity-15'
          }`}
          style={{
            background: 'radial-gradient(circle, #06b6d4 0%, #3b82f6 100%)',
            transform: `translate3d(${tilt.rotateY * 12}px, ${tilt.rotateX * 12}px, 0)`,
          }}
        />
        <div
          className={`absolute top-1/3 -right-40 w-96 h-96 rounded-full blur-3xl transition-transform duration-500 ease-out ${
            isDarkMode ? 'opacity-20' : 'opacity-10'
          }`}
          style={{
            background: 'radial-gradient(circle, #8b5cf6 0%, #06b6d4 100%)',
            transform: `translate3d(${-tilt.rotateY * 15}px, ${-tilt.rotateX * 15}px, 0)`,
          }}
        />
        <div
          className={`absolute -bottom-40 left-1/4 w-[500px] h-96 rounded-full blur-3xl transition-transform duration-500 ease-out ${
            isDarkMode ? 'opacity-20' : 'opacity-10'
          }`}
          style={{
            background: 'radial-gradient(circle, #0ea5e9 0%, #10b981 100%)',
            transform: `translate3d(${tilt.rotateY * 8}px, ${tilt.rotateX * 8}px, 0)`,
          }}
        />
      </div>

      {/* Top Bar Contract (1 Row, 3 Zones) */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isDarkMode={isDarkMode}
        setIsDarkMode={setIsDarkMode}
        user={user}
        onOpenAuth={() => setIsAuthOpen(true)}
        isOnline={isOnline}
        pendingSyncCount={pendingSyncCount}
        unreadAlertCount={events.length}
        onOpenNotifications={() => setIsNotificationsOpen(true)}
        onOpenRecoveryWizard={() => handleOpenRecoveryWizard()}
      />

      {/* Main Viewport Content */}
      <main className="relative z-10 flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {activeTab === 'cluster' && (
          <ClusterVisualizer
            nodes={nodes}
            objects={objects}
            isDarkMode={isDarkMode}
            onNotify={notify}
          />
        )}

        {activeTab === 'objects' && (
          <ObjectBrowser
            objects={objects}
            currentUser={user}
            isDarkMode={isDarkMode}
            isOnline={isOnline}
            onNotify={notify}
            onOpenRecoveryWizard={handleOpenRecoveryWizard}
          />
        )}

        {activeTab === 'quotas' && (
          <QuotaManager
            objects={objects}
            currentUser={user}
            isDarkMode={isDarkMode}
            onNotify={notify}
          />
        )}

        {activeTab === 'chaos' && (
          <ChaosLab
            nodes={nodes}
            objects={objects}
            repairJobs={repairJobs}
            isDarkMode={isDarkMode}
            onNotify={notify}
            onOpenRecoveryWizard={handleOpenRecoveryWizard}
          />
        )}

        {activeTab === 'benchmark' && (
          <BenchmarkSuite isDarkMode={isDarkMode} onNotify={notify} />
        )}

        {activeTab === 'audit' && (
          <AuditLogs
            events={events}
            repairJobs={repairJobs}
            nodes={nodes}
            objects={objects}
            isDarkMode={isDarkMode}
            onNotify={notify}
          />
        )}

        {activeTab === 'architecture' && <ArchitectureDocs isDarkMode={isDarkMode} />}
      </main>

      {/* Quiet Footer */}
      <footer className="relative z-10 border-t border-slate-200 dark:border-slate-800/40 py-6 text-center text-xs font-mono text-slate-600 dark:text-slate-400">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-center gap-2">
          <span>Zero-Knowledge AES-256-GCM · WebAuthn Enclave · Byzantine &amp; Fail-Stop Tolerant</span>
        </div>
      </footer>

      {/* Auth & Credential Modal */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        user={user}
        isDarkMode={isDarkMode}
        onNotify={notify}
      />

      {/* Real-time Notification Center Drawer */}
      <NotificationCenter
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        events={events}
        isDarkMode={isDarkMode}
        onClear={() => {
          localStorage.removeItem('aetherstore_events_v1');
          setEvents([]);
        }}
      />

      {/* Interactive Quorum Recovery Wizard */}
      <RecoveryWizard
        isOpen={isRecoveryWizardOpen}
        onClose={() => setIsRecoveryWizardOpen(false)}
        objects={objects}
        nodes={nodes}
        initialObjectId={recoveryTargetObjectId}
        isDarkMode={isDarkMode}
        onNotify={notify}
        onViewInAuditLogs={() => setActiveTab('audit')}
      />

      {/* Toast Alert Popup */}
      {toastAlert && (
        <div className="fixed bottom-6 right-6 z-50 animate-bounce duration-300">
          <div
            className={`flex items-center gap-3 px-4 py-3 rounded-2xl shadow-xl border text-xs font-mono backdrop-blur-xl ${
              toastAlert.type === 'error'
                ? isDarkMode
                  ? 'bg-rose-950/80 text-rose-200 border-rose-800'
                  : 'bg-rose-50 text-rose-950 border-rose-300 shadow-rose-100'
                : toastAlert.type === 'warning'
                ? isDarkMode
                  ? 'bg-amber-950/80 text-amber-200 border-amber-800'
                  : 'bg-amber-50 text-amber-950 border-amber-300 shadow-amber-100'
                : toastAlert.type === 'success'
                ? isDarkMode
                  ? 'bg-emerald-950/80 text-emerald-200 border-emerald-800'
                  : 'bg-emerald-50 text-emerald-950 border-emerald-300 shadow-emerald-100'
                : isDarkMode
                ? 'bg-slate-900/90 text-cyan-200 border-slate-700'
                : 'bg-white text-slate-900 border-slate-300 shadow-md'
            }`}
          >
            <div className="w-2 h-2 rounded-full bg-current animate-ping" />
            <div>
              <div className="font-bold">{toastAlert.title}</div>
              <div className="text-[11px] opacity-90 truncate max-w-xs">{toastAlert.msg}</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
