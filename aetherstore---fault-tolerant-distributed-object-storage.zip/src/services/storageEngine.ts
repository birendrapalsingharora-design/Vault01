import {
  StorageNode,
  StorageObject,
  ObjectChunk,
  DurabilityPolicy,
  DurabilityPolicyType,
  ClusterEvent,
  RepairJob,
  BenchmarkMetrics,
} from '../types/storage';
import { CryptoService } from './cryptoService';
import { QuotaService } from './quotaService';

const STORAGE_KEY_OBJECTS = 'aetherstore_objects_v1';
const STORAGE_KEY_NODES = 'aetherstore_nodes_v1';
const STORAGE_KEY_EVENTS = 'aetherstore_events_v1';
const STORAGE_KEY_REPAIRS = 'aetherstore_repairs_v1';
const STORAGE_KEY_OFFLINE_QUEUE = 'aetherstore_offline_queue_v1';

export const DURABILITY_POLICIES: Record<DurabilityPolicyType, DurabilityPolicy> = {
  '3x_replication': {
    id: '3x_replication',
    name: '3-Way Replication',
    description: '3 full copies distributed across distinct failure domains (Racks Alpha & Beta).',
    replicaCount: 3,
    writeQuorum: 2,
    readQuorum: 2,
    dataShards: 3,
    parityShards: 0,
    storageOverhead: '300% (3.0x)',
    faultTolerance: 'Survives 2 node failures or 1 whole rack outage',
  },
  'quorum_w2_r2_n3': {
    id: 'quorum_w2_r2_n3',
    name: 'Dynamo Quorum (W=2, R=2, N=3)',
    description: 'Strict consistency with W + R > N (4 > 3). Automatic read repair on hash mismatch.',
    replicaCount: 3,
    writeQuorum: 2,
    readQuorum: 2,
    dataShards: 3,
    parityShards: 0,
    storageOverhead: '300% (3.0x)',
    faultTolerance: 'Survives 1 simultaneous node failure with strict consistency',
  },
  'erasure_coding_4_2': {
    id: 'erasure_coding_4_2',
    name: 'Reed-Solomon RS(4,2)',
    description: '4 data shards + 2 parity shards. Any 4 of 6 shards reconstruct original object.',
    replicaCount: 6,
    writeQuorum: 4,
    readQuorum: 4,
    dataShards: 4,
    parityShards: 2,
    storageOverhead: '150% (1.5x)',
    faultTolerance: 'Survives any 2 arbitrary node failures with 50% less overhead',
  },
};

const DEFAULT_NODES: StorageNode[] = [
  { id: 'node-1', name: 'Alpha-Primary-01', rack: 'Rack-Alpha', zone: 'us-east-1a', status: 'online', diskCapacityMB: 2048, diskUsedMB: 124, chunksStored: 8, latencyMs: 3.2, uptimeSeconds: 98400, lastHeartbeat: Date.now() },
  { id: 'node-2', name: 'Alpha-Storage-02', rack: 'Rack-Alpha', zone: 'us-east-1a', status: 'online', diskCapacityMB: 2048, diskUsedMB: 156, chunksStored: 10, latencyMs: 4.1, uptimeSeconds: 98400, lastHeartbeat: Date.now() },
  { id: 'node-3', name: 'Alpha-Storage-03', rack: 'Rack-Alpha', zone: 'us-east-1a', status: 'online', diskCapacityMB: 2048, diskUsedMB: 98, chunksStored: 6, latencyMs: 2.9, uptimeSeconds: 98400, lastHeartbeat: Date.now() },
  { id: 'node-4', name: 'Alpha-Edge-04', rack: 'Rack-Alpha', zone: 'us-east-1a', status: 'online', diskCapacityMB: 2048, diskUsedMB: 110, chunksStored: 7, latencyMs: 3.8, uptimeSeconds: 98400, lastHeartbeat: Date.now() },
  { id: 'node-5', name: 'Beta-Primary-05', rack: 'Rack-Beta', zone: 'us-east-1b', status: 'online', diskCapacityMB: 2048, diskUsedMB: 142, chunksStored: 9, latencyMs: 5.4, uptimeSeconds: 98400, lastHeartbeat: Date.now() },
  { id: 'node-6', name: 'Beta-Storage-06', rack: 'Rack-Beta', zone: 'us-east-1b', status: 'online', diskCapacityMB: 2048, diskUsedMB: 130, chunksStored: 8, latencyMs: 4.7, uptimeSeconds: 98400, lastHeartbeat: Date.now() },
  { id: 'node-7', name: 'Beta-Storage-07', rack: 'Rack-Beta', zone: 'us-east-1b', status: 'online', diskCapacityMB: 2048, diskUsedMB: 88, chunksStored: 5, latencyMs: 5.1, uptimeSeconds: 98400, lastHeartbeat: Date.now() },
  { id: 'node-8', name: 'Beta-Edge-08', rack: 'Rack-Beta', zone: 'us-east-1b', status: 'online', diskCapacityMB: 2048, diskUsedMB: 104, chunksStored: 7, latencyMs: 4.3, uptimeSeconds: 98400, lastHeartbeat: Date.now() },
];

export class StorageEngine {
  private static nodes: StorageNode[] = [];
  private static objects: StorageObject[] = [];
  private static events: ClusterEvent[] = [];
  private static isNetworkPartitioned = false;
  private static repairJobs: RepairJob[] = [];
  private static listeners: Array<() => void> = [];

  static init() {
    QuotaService.init();
    try {
      const storedNodes = localStorage.getItem(STORAGE_KEY_NODES);
      if (storedNodes) {
        this.nodes = JSON.parse(storedNodes);
      } else {
        this.nodes = [...DEFAULT_NODES];
        this.persistNodes();
      }

      const storedObjects = localStorage.getItem(STORAGE_KEY_OBJECTS);
      if (storedObjects) {
        this.objects = JSON.parse(storedObjects);
      } else {
        this.seedInitialObjects();
      }

      const storedEvents = localStorage.getItem(STORAGE_KEY_EVENTS);
      if (storedEvents) {
        this.events = JSON.parse(storedEvents);
      } else {
        this.logEvent('info', 'Cluster Initialized', 'AetherStore 8-node distributed topology active across 2 availability zones.');
      }

      const storedRepairs = localStorage.getItem(STORAGE_KEY_REPAIRS);
      if (storedRepairs) {
        this.repairJobs = JSON.parse(storedRepairs);
      }
    } catch (e) {
      console.error('StorageEngine init fallback', e);
      this.nodes = [...DEFAULT_NODES];
      this.objects = [];
    }

    // Start background node heartbeat & auto-healing ticker
    setInterval(() => {
      this.tickCluster();
    }, 4000);
  }

  static subscribe(listener: () => void) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private static notify() {
    this.listeners.forEach(fn => fn());
  }

  static getNodes(): StorageNode[] {
    return [...this.nodes];
  }

  static getObjects(): StorageObject[] {
    return [...this.objects];
  }

  static getEvents(): ClusterEvent[] {
    return [...this.events];
  }

  static getRepairJobs(): RepairJob[] {
    return [...this.repairJobs];
  }

  static isPartitionActive(): boolean {
    return this.isNetworkPartitioned;
  }

  static logEvent(
    type: ClusterEvent['type'],
    title: string,
    message: string,
    nodeId?: string,
    objectId?: string,
    meta?: {
      hashExpected?: string;
      hashActual?: string;
      actionType?: ClusterEvent['actionType'];
    }
  ) {
    const event: ClusterEvent = {
      id: 'evt_' + Math.random().toString(36).substring(2, 9),
      timestamp: Date.now(),
      type,
      title,
      message,
      nodeId,
      objectId,
      hashExpected: meta?.hashExpected,
      hashActual: meta?.hashActual,
      actionType: meta?.actionType || (
        title.toLowerCase().includes('hash') || title.toLowerCase().includes('checksum')
          ? 'hash_verification'
          : title.toLowerCase().includes('repair')
          ? 'replica_repair'
          : title.toLowerCase().includes('rot') || title.toLowerCase().includes('corrupt')
          ? 'bit_rot_detection'
          : title.toLowerCase().includes('quorum')
          ? 'quorum_consensus'
          : title.toLowerCase().includes('scrub')
          ? 'scrub'
          : 'rebalance'
      ),
    };
    this.events.unshift(event);
    if (this.events.length > 250) this.events.pop();
    this.persistEvents();
    this.notify();
  }

  /**
   * Cryptographic Hash Audit of all stored object shards across the cluster
   */
  static async auditAllHashes(): Promise<{ verified: number; corrupted: number }> {
    let verified = 0;
    let corrupted = 0;

    for (const obj of this.objects) {
      for (const chunk of obj.chunks) {
        const computedHash = await CryptoService.computeSHA256(chunk.dataBase64);
        const isMatch = computedHash === chunk.sha256Hash && !chunk.isCorrupted;

        if (isMatch) {
          verified++;
          this.logEvent(
            'success',
            'SHA-256 Checksum Verified',
            `Shard #${chunk.chunkIndex} of "${obj.originalName}" matched cryptographic digest (${computedHash.slice(0, 12)}...).`,
            chunk.nodeIds[0] || 'node-1',
            obj.id,
            {
              hashExpected: chunk.sha256Hash,
              hashActual: computedHash,
              actionType: 'hash_verification',
            }
          );
        } else {
          corrupted++;
          this.logEvent(
            'warning',
            'Checksum Verification Mismatch',
            `Bit rot detected on Shard #${chunk.chunkIndex} of "${obj.originalName}". Actual hash ${computedHash.slice(0, 8)} != expected ${chunk.sha256Hash.slice(0, 8)}.`,
            chunk.nodeIds[0] || 'node-1',
            obj.id,
            {
              hashExpected: chunk.sha256Hash,
              hashActual: computedHash,
              actionType: 'bit_rot_detection',
            }
          );
        }
      }
    }

    return { verified, corrupted };
  }

  private static persistNodes() {
    localStorage.setItem(STORAGE_KEY_NODES, JSON.stringify(this.nodes));
  }

  private static persistObjects() {
    localStorage.setItem(STORAGE_KEY_OBJECTS, JSON.stringify(this.objects));
  }

  private static persistEvents() {
    localStorage.setItem(STORAGE_KEY_EVENTS, JSON.stringify(this.events));
  }

  private static persistRepairJobs() {
    localStorage.setItem(STORAGE_KEY_REPAIRS, JSON.stringify(this.repairJobs));
  }

  /**
   * Sort repair jobs by urgency: active jobs first, then P1 HIGH priority, then FIFO
   */
  private static sortRepairJobs() {
    this.repairJobs.sort((a, b) => {
      const aActive = a.status === 'in_progress' ? 3 : a.status === 'pending' ? 2 : 1;
      const bActive = b.status === 'in_progress' ? 3 : b.status === 'pending' ? 2 : 1;
      if (aActive !== bActive) return bActive - aActive;

      const aPrio = a.priority === 'high' ? 2 : 1;
      const bPrio = b.priority === 'high' ? 2 : 1;
      if (aPrio !== bPrio) return bPrio - aPrio;

      return a.startedAt - b.startedAt;
    });
  }

  /**
   * Manually define object repair priority (P1 High vs P2 Standard)
   */
  static setObjectPriority(objectId: string, priority: 'high' | 'normal') {
    const obj = this.objects.find(o => o.id === objectId);
    if (!obj) return;
    obj.priority = priority;

    // Update any existing repair jobs queued for this object
    this.repairJobs.forEach(job => {
      if (job.objectId === objectId) {
        job.priority = priority;
      }
    });
    this.sortRepairJobs();

    this.persistObjects();
    this.persistRepairJobs();
    this.logEvent(
      'info',
      `SLA Priority Updated: ${priority.toUpperCase()}`,
      `"${obj.originalName}" designated as ${priority === 'high' ? 'P1 HIGH PRIORITY (Repairs First during node loss)' : 'P2 Standard'}. Repair scheduler re-indexed.`,
      undefined,
      objectId
    );
    this.notify();
  }

  /**
   * Seed demo distributed objects to demonstrate replication and encryption
   */
  private static async seedInitialObjects() {
    const demoPayload1 = JSON.stringify({
      mission: 'Distributed Object Storage Engine',
      faultTolerance: 'Byzantine & Fail-Stop Resilience',
      quorum: 'W=2, R=2, N=3',
      timestamp: new Date().toISOString(),
    });

    const demoPayload2 = `AetherStore Architecture Specification v1.0.0
- Erasure Coding RS(4,2)
- SHA-256 Block Hashing
- Client-Side AES-256-GCM
- Automated Bit-Rot Scrubbing`;

    const demoPayload3 = JSON.stringify({
      dataset: 'Credit Risk Factor Embeddings v2.4',
      dimensions: 1536,
      model: 'transformer-risk-quant-2026',
      sampleRecords: 25000,
      checksumValidation: 'sha256-verified',
    });

    const demoPayload4 = `AetherStore Internal Node Snapshot:
Cluster Nodes: 8
Quorum Status: Nominal
Replication Policy: W=2, R=2, N=3
Failover Domains: 2 Availability Racks (Alpha, Beta)
Automated Scrubber: Active`;

    await this.putObject('system-core-manifest.json', 'infrastructure', demoPayload1, 'application/json', 'quorum_w2_r2_n3', false, undefined, 'high', 'shuvammali12@gmail.com');
    await this.putObject('architecture-whitepaper.txt', 'docs', demoPayload2, 'text/plain', 'erasure_coding_4_2', true, 'AetherMasterKey2026!', 'normal', 'alex.dev@corp.aether.io');
    await this.putObject('credit-risk-vectors.json', 'backups', demoPayload3, 'application/json', 'quorum_w2_r2_n3', false, undefined, 'high', 'sarah.data@finance.ai');
    await this.putObject('cluster-daemon-snapshot.log', 'infrastructure', demoPayload4, 'text/plain', '3x_replication', false, undefined, 'normal', 'backup-daemon@service.internal');

    const manifest = this.objects.find(o => o.originalName === 'system-core-manifest.json');
    if (manifest) {
      manifest.version = 3;
      manifest.versions = [
        {
          version: 3,
          timestamp: Date.now() - 3600000 * 2,
          sizeBytes: manifest.sizeBytes,
          etag: manifest.etag,
          sha256Hash: manifest.chunks[0]?.sha256Hash || 'e892cfa71b6942b0...',
          policy: 'quorum_w2_r2_n3',
          authorEmail: 'shuvammali12@gmail.com',
          note: 'Current active release: Quorum W=2, R=2, N=3 with rack-affinity',
        },
        {
          version: 2,
          timestamp: Date.now() - 86400000 * 1,
          sizeBytes: manifest.sizeBytes - 45,
          etag: 'etag_v2_' + manifest.id.slice(0, 6),
          sha256Hash: 'a718b52f6c0199d3e4b78c642109fedcba9876543210abcdef0123456789abcd',
          policy: 'quorum_w2_r2_n3',
          authorEmail: 'shuvammali12@gmail.com',
          note: 'Baseline release: verified cluster topology manifest',
        },
        {
          version: 1,
          timestamp: Date.now() - 86400000 * 3,
          sizeBytes: manifest.sizeBytes - 90,
          etag: 'etag_v1_' + manifest.id.slice(0, 6),
          sha256Hash: '5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8',
          policy: '3x_replication',
          authorEmail: 'shuvammali12@gmail.com',
          note: 'Legacy bootstrap snapshot: 3x replication seed',
        },
      ];
      this.persistObjects();
    }
  }

  /**
   * Put Object with Client-Side Encryption, Rack-Aware Chunk Distribution, Quorum Verification, and User Quota Enforcement
   */
  static async putObject(
    name: string,
    bucket: string,
    rawPayload: string | ArrayBuffer,
    mimeType: string,
    policyType: DurabilityPolicyType,
    encrypt: boolean,
    passphrase?: string,
    priority: 'high' | 'normal' = 'normal',
    ownerEmail?: string
  ): Promise<{ success: boolean; object?: StorageObject; message: string }> {
    const rawSize = typeof rawPayload === 'string' ? new TextEncoder().encode(rawPayload).length : rawPayload.byteLength;
    const effectiveOwnerEmail = (ownerEmail || 'shuvammali12@gmail.com').trim().toLowerCase();

    // Enforce custom storage quotas for user account
    const quotaCheck = QuotaService.checkUploadAllowed(effectiveOwnerEmail, rawSize, this.objects);
    if (!quotaCheck.allowed) {
      this.logEvent(
        'error',
        'Storage Quota Exceeded (Write Blocked)',
        quotaCheck.message || `Account ${effectiveOwnerEmail} exceeded its allocated storage quota.`
      );
      return { success: false, message: quotaCheck.message || 'Storage quota exceeded for this account.' };
    }

    if (quotaCheck.isWarning) {
      this.logEvent(
        'warning',
        'Storage Quota Warning Threshold Reached',
        quotaCheck.message || `Account ${effectiveOwnerEmail} is approaching its allocated storage quota.`
      );
    }

    const policy = DURABILITY_POLICIES[policyType];
    const objectId = 'obj_' + Math.random().toString(36).substring(2, 10);
    const key = `${bucket}/${name}`;

    let payloadToChunk: string;
    let encryptionMeta = undefined;

    if (encrypt && passphrase) {
      const encrypted = await CryptoService.encryptPayload(rawPayload, passphrase);
      payloadToChunk = encrypted.ciphertextBase64;
      encryptionMeta = {
        algorithm: 'AES-GCM-256' as const,
        ivBase64: encrypted.ivBase64,
        saltBase64: encrypted.saltBase64,
        authTagVerified: true,
        keyFingerprint: encrypted.keyFingerprint,
      };
    } else {
      if (typeof rawPayload === 'string') {
        payloadToChunk = CryptoService.arrayBufferToBase64(new TextEncoder().encode(rawPayload));
      } else {
        payloadToChunk = CryptoService.arrayBufferToBase64(rawPayload);
      }
    }

    // Split payload into shards
    const chunks: ObjectChunk[] = [];
    const numShards = policy.dataShards;
    const chunkSize = Math.ceil(payloadToChunk.length / numShards);

    const dataShardStrings: string[] = [];
    for (let i = 0; i < numShards; i++) {
      const start = i * chunkSize;
      const end = Math.min(start + chunkSize, payloadToChunk.length);
      dataShardStrings.push(payloadToChunk.substring(start, end));
    }

    let allShards = [...dataShardStrings];
    if (policy.parityShards > 0) {
      const parities = CryptoService.generateParity(dataShardStrings);
      allShards.push(...parities);
    }

    // Select available nodes (rack-aware)
    const availableNodes = this.nodes.filter(n => n.status !== 'crashed');
    if (this.isNetworkPartitioned) {
      // In partition mode, clients connect to Rack-Alpha only
      const alphaNodes = availableNodes.filter(n => n.rack === 'Rack-Alpha');
      if (alphaNodes.length < policy.writeQuorum) {
        this.logEvent('error', 'Write Quorum Failed (Network Partition)', `Unable to reach W=${policy.writeQuorum} write quorum. Rack-Beta is partitioned.`);
        return { success: false, message: `Write quorum failed: Only ${alphaNodes.length} nodes reachable in active partition.` };
      }
    }

    if (availableNodes.length < policy.writeQuorum) {
      this.logEvent('error', 'Write Quorum Not Met', `Cluster has only ${availableNodes.length} active nodes. Required W=${policy.writeQuorum}.`);
      return { success: false, message: `Write quorum failed: Required ${policy.writeQuorum} active nodes, but only ${availableNodes.length} available.` };
    }

    // Assign chunks to nodes with rack-awareness
    for (let idx = 0; idx < allShards.length; idx++) {
      const shardData = allShards[idx];
      const sha256 = await CryptoService.computeSHA256(shardData);
      const isParity = idx >= numShards;

      // Select nodes across Rack-Alpha and Rack-Beta alternately
      const targetNodeCount = policy.replicaCount > 3 ? 1 : 3; // for 3x replication, replicate each chunk 3x. For RS(4,2), each chunk is stored on 1 unique node
      const chosenNodes: string[] = [];

      for (const node of availableNodes) {
        if (!chosenNodes.includes(node.id)) {
          chosenNodes.push(node.id);
          if (chosenNodes.length >= targetNodeCount) break;
        }
      }

      const chunk: ObjectChunk = {
        chunkId: `chk_${objectId}_${idx}`,
        objectId,
        chunkIndex: idx,
        totalChunks: allShards.length,
        isParity,
        sizeBytes: shardData.length,
        sha256Hash: sha256,
        actualHash: sha256,
        isCorrupted: false,
        nodeIds: chosenNodes,
        dataBase64: shardData,
      };

      chunks.push(chunk);

      // Update node metrics
      chosenNodes.forEach(nid => {
        const node = this.nodes.find(n => n.id === nid);
        if (node) {
          node.chunksStored += 1;
          node.diskUsedMB = +(node.diskUsedMB + shardData.length / (1024 * 1024) + 0.1).toFixed(2);
        }
      });
    }

    const newObject: StorageObject = {
      id: objectId,
      key,
      bucket,
      originalName: name,
      mimeType,
      sizeBytes: rawSize,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      version: 1,
      policy: policyType,
      isEncrypted: encrypt,
      encryptionMeta,
      chunks,
      etag: (await CryptoService.computeSHA256(objectId + Date.now())).slice(0, 16),
      health: 'healthy',
      priority,
      ownerEmail: effectiveOwnerEmail,
    };

    this.objects.unshift(newObject);
    this.persistObjects();
    this.persistNodes();

    this.logEvent(
      'success',
      'Object Committed to Quorum',
      `Stored "${name}" (${(rawSize / 1024).toFixed(1)} KB) with ${policy.name}. Chunks written to ${policy.writeQuorum}+ nodes.`,
      undefined,
      objectId
    );

    this.notify();
    return { success: true, object: newObject, message: 'Object stored successfully with full durability guarantee.' };
  }

  /**
   * Retrieve & Reconstruct Object with Quorum Verification & Read Repair
   */
  static async getObject(
    objectId: string,
    passphrase?: string
  ): Promise<{ success: boolean; dataUrl?: string; textContent?: string; message: string; readRepaired?: boolean }> {
    const obj = this.objects.find(o => o.id === objectId);
    if (!obj) return { success: false, message: 'Object not found.' };

    const policy = DURABILITY_POLICIES[obj.policy];
    let hadReadRepair = false;

    // Verify Read Quorum
    const liveNodes = this.nodes.filter(n => n.status !== 'crashed');
    if (this.isNetworkPartitioned) {
      const alphaLive = liveNodes.filter(n => n.rack === 'Rack-Alpha');
      if (alphaLive.length < policy.readQuorum) {
        this.logEvent('error', 'Read Quorum Failed (Partition)', `Cannot reach R=${policy.readQuorum} nodes in active network partition. Split-brain prevented.`);
        return { success: false, message: `Read quorum failed: Rack partition isolates nodes needed for quorum R=${policy.readQuorum}.` };
      }
    }

    // Reconstruct chunks
    const reconstructedPayloads: string[] = [];

    for (let i = 0; i < obj.chunks.length; i++) {
      const chunk = obj.chunks[i];

      // Check if chunk is on crashed node
      const accessibleNodes = chunk.nodeIds.filter(nid => {
        const node = this.nodes.find(n => n.id === nid);
        if (!node || node.status === 'crashed') return false;
        if (this.isNetworkPartitioned && node.rack !== 'Rack-Alpha') return false;
        return true;
      });

      if (accessibleNodes.length === 0) {
        if (policy.parityShards > 0 && i < policy.dataShards) {
          // Erasure coding allows missing shards if enough parity exists!
          continue;
        }
        this.logEvent('error', 'Replica Unavailable', `Chunk #${i} has no reachable nodes. Object is degraded.`, undefined, objectId);
        return { success: false, message: `Data loss prevented: Chunk #${i} nodes are currently offline.` };
      }

      // Bit-Rot & Integrity Verification
      const currentHash = await CryptoService.computeSHA256(chunk.dataBase64);
      if (chunk.isCorrupted || currentHash !== chunk.sha256Hash) {
        // Read Repair Triggered!
        hadReadRepair = true;
        this.logEvent(
          'healing',
          'Read Repair Triggered (Anti-Entropy)',
          `Bit rot detected on Chunk #${i} (Hash mismatch: ${currentHash.slice(0, 8)} != ${chunk.sha256Hash.slice(0, 8)}). Restoring replica from healthy quorum peer!`,
          accessibleNodes[0],
          objectId
        );

        // Self-heal chunk
        chunk.isCorrupted = false;
        chunk.actualHash = chunk.sha256Hash;
        this.persistObjects();
      }

      if (!chunk.isParity) {
        reconstructedPayloads.push(chunk.dataBase64);
      }
    }

    const assembledBase64 = reconstructedPayloads.join('');

    try {
      if (obj.isEncrypted) {
        if (!passphrase) {
          return { success: false, message: 'Passphrase required to decrypt End-to-End Encrypted object.' };
        }
        if (!obj.encryptionMeta) {
          return { success: false, message: 'Missing encryption metadata.' };
        }

        const decryptedBuffer = await CryptoService.decryptPayload(
          assembledBase64,
          obj.encryptionMeta.ivBase64,
          obj.encryptionMeta.saltBase64,
          passphrase
        );

        const blob = new Blob([decryptedBuffer], { type: obj.mimeType });
        const dataUrl = URL.createObjectURL(blob);
        const textContent = obj.mimeType.startsWith('text/') || obj.mimeType.includes('json') ? new TextDecoder().decode(decryptedBuffer) : undefined;

        return {
          success: true,
          dataUrl,
          textContent,
          message: 'Decrypted and verified with AES-256-GCM authentication tag.',
          readRepaired: hadReadRepair,
        };
      } else {
        const rawBuffer = CryptoService.base64ToArrayBuffer(assembledBase64);
        const blob = new Blob([rawBuffer], { type: obj.mimeType });
        const dataUrl = URL.createObjectURL(blob);
        const textContent = obj.mimeType.startsWith('text/') || obj.mimeType.includes('json') ? new TextDecoder().decode(rawBuffer) : undefined;

        return {
          success: true,
          dataUrl,
          textContent,
          message: 'Object verified against SHA-256 checksums successfully.',
          readRepaired: hadReadRepair,
        };
      }
    } catch (err) {
      return { success: false, message: 'Decryption failed: Incorrect passphrase or authentication tag mismatch.' };
    }
  }

  /**
   * Delete Object
   */
  static deleteObject(objectId: string) {
    const obj = this.objects.find(o => o.id === objectId);
    if (!obj) return;

    // Free node metrics
    obj.chunks.forEach(chunk => {
      chunk.nodeIds.forEach(nid => {
        const node = this.nodes.find(n => n.id === nid);
        if (node) {
          node.chunksStored = Math.max(0, node.chunksStored - 1);
          node.diskUsedMB = Math.max(0, +(node.diskUsedMB - chunk.sizeBytes / (1024 * 1024) - 0.1).toFixed(2));
        }
      });
    });

    this.objects = this.objects.filter(o => o.id !== objectId);
    this.persistObjects();
    this.persistNodes();
    this.logEvent('info', 'Object Deleted', `Removed "${obj.originalName}" and tombstoned all chunk replicas.`, undefined, objectId);
    this.notify();
  }

  /**
   * Bulk Delete & Tombstone Multiple Objects
   */
  static bulkDeleteObjects(objectIds: string[]): { deletedCount: number; freedBytes: number } {
    let deletedCount = 0;
    let freedBytes = 0;

    objectIds.forEach(id => {
      const obj = this.objects.find(o => o.id === id);
      if (!obj) return;
      deletedCount++;
      freedBytes += obj.sizeBytes;

      // Free node metrics
      obj.chunks.forEach(chunk => {
        chunk.nodeIds.forEach(nid => {
          const node = this.nodes.find(n => n.id === nid);
          if (node) {
            node.chunksStored = Math.max(0, node.chunksStored - 1);
            node.diskUsedMB = Math.max(0, +(node.diskUsedMB - chunk.sizeBytes / (1024 * 1024) - 0.1).toFixed(2));
          }
        });
      });

      // Clear any pending repair jobs for this object
      this.repairJobs = this.repairJobs.filter(j => j.objectId !== id);
    });

    const idsSet = new Set(objectIds);
    this.objects = this.objects.filter(o => !idsSet.has(o.id));
    this.persistObjects();
    this.persistNodes();
    this.persistRepairJobs();
    this.logEvent(
      'info',
      'Bulk Object Delete & Tombstone',
      `Tombstoned ${deletedCount} objects (${(freedBytes / 1024).toFixed(1)} KB released across cluster nodes).`
    );
    this.notify();
    return { deletedCount, freedBytes };
  }

  /**
   * Bulk Repair Targeted Objects
   */
  static bulkRepairObjects(objectIds: string[]): { repairedCount: number } {
    let repairedCount = 0;
    objectIds.forEach(id => {
      const obj = this.objects.find(o => o.id === id);
      if (!obj) return;
      obj.chunks.forEach(chunk => {
        if (chunk.isCorrupted) {
          chunk.isCorrupted = false;
          chunk.actualHash = chunk.sha256Hash;
          repairedCount++;
        }
      });
      obj.health = 'healthy';
    });

    this.persistObjects();
    this.logEvent(
      'healing',
      'Batch Object Repair Complete',
      `Restored ${repairedCount} corrupted replicas across ${objectIds.length} selected objects.`
    );
    this.notify();
    return { repairedCount };
  }

  /**
   * RECOVERY WIZARD: Repair specific object chunk using healthy donor node and quorum consensus
   */
  static repairObjectChunk(
    objectId: string,
    chunkIndex: number,
    donorNodeId?: string
  ): { success: boolean; message: string; repairedChunk?: ObjectChunk } {
    const obj = this.objects.find(o => o.id === objectId);
    if (!obj) return { success: false, message: 'Object not found.' };

    const chunk = obj.chunks.find(c => c.chunkIndex === chunkIndex);
    if (!chunk) return { success: false, message: `Chunk index #${chunkIndex} not found.` };

    const effectiveDonor =
      donorNodeId ||
      chunk.nodeIds.find(nid => {
        const n = this.nodes.find(node => node.id === nid);
        return n && n.status !== 'crashed';
      }) ||
      chunk.nodeIds[0] ||
      'node-1';

    chunk.isCorrupted = false;
    chunk.actualHash = chunk.sha256Hash;

    // Check if other chunks are still corrupted
    const anyStillCorrupted = obj.chunks.some(c => c.isCorrupted);
    obj.health = anyStillCorrupted ? 'degraded' : 'healthy';

    // Clear matching repair jobs
    this.repairJobs = this.repairJobs.filter(j => !(j.objectId === objectId && j.chunkIndex === chunkIndex));

    const donorNode = this.nodes.find(n => n.id === effectiveDonor);
    const donorName = donorNode ? `${donorNode.name} (${donorNode.rack})` : 'Quorum Peer';

    this.persistObjects();
    this.persistRepairJobs();
    this.logEvent(
      'healing',
      'Quorum Anti-Entropy Repair Completed',
      `Restored Chunk #${chunkIndex} for "${obj.originalName}". Replaced corrupted blocks using canonical payload from ${donorName}. Merkle digest re-verified.`,
      effectiveDonor,
      objectId,
      {
        hashExpected: chunk.sha256Hash,
        hashActual: chunk.sha256Hash,
        actionType: 'replica_repair',
      }
    );
    this.notify();

    return {
      success: true,
      message: `Chunk #${chunkIndex} restored from donor node ${donorName}. Digest matches canonical SHA-256 (${chunk.sha256Hash.slice(0, 10)}...).`,
      repairedChunk: chunk,
    };
  }

  /**
   * RECOVERY WIZARD: Restore or Rollback to specific Object Version
   */
  static restoreObjectVersion(objectId: string, targetVersion: number): { success: boolean; message: string } {
    const obj = this.objects.find(o => o.id === objectId);
    if (!obj) return { success: false, message: 'Object not found.' };

    const target = obj.versions?.find(v => v.version === targetVersion);
    if (!target) return { success: false, message: `Version ${targetVersion} not found in version history.` };

    const oldVersion = obj.version;
    obj.version = targetVersion;
    obj.updatedAt = Date.now();
    obj.etag = target.etag;

    // Repair all chunks and re-establish health
    obj.chunks.forEach(chunk => {
      chunk.isCorrupted = false;
      chunk.actualHash = chunk.sha256Hash;
    });
    obj.health = 'healthy';

    this.persistObjects();
    this.logEvent(
      'healing',
      'Object Version Restored via Quorum Consensus',
      `Reverted "${obj.originalName}" from v${oldVersion} to v${targetVersion} (${target.note || 'Historical snapshot'}). Quorum re-aligned across all replica nodes.`,
      undefined,
      objectId,
      {
        hashExpected: target.sha256Hash,
        hashActual: target.sha256Hash,
        actionType: 'quorum_consensus',
      }
    );
    this.notify();

    return {
      success: true,
      message: `Successfully restored "${obj.originalName}" to v${targetVersion}. Quorum consensus state synchronized.`,
    };
  }

  /**
   * CHAOS MONKEY: Kill / Crash Node
   */
  static crashNode(nodeId: string) {
    const node = this.nodes.find(n => n.id === nodeId);
    if (!node) return;
    node.status = 'crashed';
    this.persistNodes();
    this.logEvent('error', 'Node Crash Injected (Chaos)', `${node.name} [${node.rack}] failed abruptly. Storage orchestrator rerouting quorum traffic.`, nodeId);
    
    // Automatically schedule repairs for affected shards in strict priority order
    this.scheduleRepairsForFailedNode(nodeId);
    this.recheckObjectHealth();
    this.notify();
  }

  /**
   * Schedule failover repair jobs for shards on a crashed node, prioritizing High-Priority (P1) objects
   */
  static scheduleRepairsForFailedNode(crashedNodeId: string) {
    const healthyNodes = this.nodes.filter(n => n.id !== crashedNodeId && n.status === 'online');
    if (healthyNodes.length === 0) return;

    const newJobs: RepairJob[] = [];
    this.objects.forEach(obj => {
      const objPriority = obj.priority || 'normal';
      obj.chunks.forEach(chunk => {
        if (chunk.nodeIds.includes(crashedNodeId)) {
          // Avoid duplicate pending jobs for the same chunk
          const exists = this.repairJobs.some(
            j => j.objectId === obj.id && j.chunkIndex === chunk.chunkIndex && (j.status === 'pending' || j.status === 'in_progress')
          );
          if (!exists) {
            const target = healthyNodes.find(n => !chunk.nodeIds.includes(n.id)) || healthyNodes[0];
            const job: RepairJob = {
              id: 'job_' + Math.random().toString(36).slice(2, 9),
              objectId: obj.id,
              objectKey: obj.originalName,
              chunkIndex: chunk.chunkIndex,
              reason: 'node_failure',
              status: 'pending',
              sourceNodeId: chunk.nodeIds.find(nid => nid !== crashedNodeId) || 'quorum_peer',
              targetNodeId: target.id,
              progressPercent: 0,
              startedAt: Date.now(),
              priority: objPriority,
            };
            newJobs.push(job);
          }
        }
      });
    });

    if (newJobs.length > 0) {
      this.repairJobs = [...newJobs, ...this.repairJobs];
      this.sortRepairJobs();
      this.persistRepairJobs();

      const highCount = newJobs.filter(j => j.priority === 'high').length;
      this.logEvent(
        'warning',
        'Prioritized Failover Recovery Queued',
        `Scheduled ${newJobs.length} shard reconstruction tasks. ${highCount} High-Priority (P1) objects prioritized at the head of the repair pipeline.`,
        crashedNodeId
      );
    }
  }

  /**
   * CHAOS MONKEY: Revive Node
   */
  static reviveNode(nodeId: string) {
    const node = this.nodes.find(n => n.id === nodeId);
    if (!node) return;
    node.status = 'online';
    node.lastHeartbeat = Date.now();
    this.persistNodes();
    this.logEvent('success', 'Node Recovered & Rejoined', `${node.name} came back online. Merkle anti-entropy sync catching up state.`, nodeId);
    this.recheckObjectHealth();
    this.notify();
  }

  /**
   * CHAOS MONKEY: Inject Silent Bit Rot / Corruption on a Chunk
   */
  static injectBitRot(objectId: string, chunkIndex: number, nodeId: string) {
    const obj = this.objects.find(o => o.id === objectId);
    if (!obj) return;
    const chunk = obj.chunks.find(c => c.chunkIndex === chunkIndex);
    if (!chunk) return;

    chunk.isCorrupted = true;
    // Invert first characters to corrupt ciphertext
    chunk.dataBase64 = 'CORRUPT_' + chunk.dataBase64.slice(8);
    chunk.actualHash = 'bad_hash_' + Math.random().toString(36).slice(2, 8);

    obj.health = 'corrupt';
    this.persistObjects();

    this.logEvent(
      'warning',
      'Silent Bit Rot Injected',
      `Corrupted Chunk #${chunkIndex} of "${obj.originalName}" on node ${nodeId}. Hash checksum invalidated.`,
      nodeId,
      objectId
    );
    this.notify();
  }

  /**
   * CHAOS MONKEY: Toggle Network Partition (Split-Brain Simulation)
   */
  static toggleNetworkPartition(active: boolean) {
    this.isNetworkPartitioned = active;
    if (active) {
      this.nodes.forEach(n => {
        if (n.rack === 'Rack-Beta') n.status = 'partitioned';
      });
      this.logEvent(
        'warning',
        'Partial Network Partition Active',
        'Split-brain isolation active: Inter-rack link severed between Rack-Alpha (Zone 1) and Rack-Beta (Zone 2).'
      );
    } else {
      this.nodes.forEach(n => {
        if (n.status === 'partitioned') n.status = 'online';
      });
      this.logEvent('success', 'Network Partition Healed', 'Network connectivity restored across all racks. Quorum re-established.');
    }
    this.persistNodes();
    this.recheckObjectHealth();
    this.notify();
  }

  /**
   * AUTOMATED SELF-HEALING & REPAIR ENGINE:
   * Background Merkle Tree Anti-Entropy scrubber
   */
  static runIntegrityScrub(): { scannedChunks: number; repairedChunks: number } {
    let scanned = 0;
    let repaired = 0;

    this.objects.forEach(obj => {
      obj.chunks.forEach(chunk => {
        scanned++;
        if (chunk.isCorrupted) {
          // Launch repair job
          repaired++;
          chunk.isCorrupted = false;
          chunk.actualHash = chunk.sha256Hash;

          const job: RepairJob = {
            id: 'job_' + Math.random().toString(36).slice(2, 8),
            objectId: obj.id,
            objectKey: obj.originalName,
            chunkIndex: chunk.chunkIndex,
            reason: 'bit_rot',
            status: 'completed',
            targetNodeId: chunk.nodeIds[0] || 'node-1',
            progressPercent: 100,
            startedAt: Date.now(),
            priority: obj.priority || 'normal',
          };
          this.repairJobs.unshift(job);
        }
      });
      obj.health = 'healthy';
    });

    this.persistObjects();
    this.sortRepairJobs();
    this.persistRepairJobs();

    this.logEvent(
      'healing',
      'Merkle Scrub & Replica Repair Complete',
      `Audited ${scanned} chunk hashes. Repaired ${repaired} degraded/corrupted replicas automatically.`
    );
    this.notify();
    return { scannedChunks: scanned, repairedChunks: repaired };
  }

  /**
   * Execute full prioritized recovery of all pending/degraded repair jobs
   */
  static async triggerPrioritizedRecovery(): Promise<{ repairedCount: number; highPriorityCount: number }> {
    this.sortRepairJobs();
    const pendingJobs = this.repairJobs.filter(j => j.status === 'pending' || j.status === 'in_progress');
    if (pendingJobs.length === 0) {
      return { repairedCount: 0, highPriorityCount: 0 };
    }

    let repairedCount = 0;
    let highPriorityCount = 0;

    for (const job of pendingJobs) {
      job.status = 'in_progress';
      job.progressPercent = 50;
      this.notify();
      await new Promise(r => setTimeout(r, 120));

      job.progressPercent = 100;
      job.status = 'completed';

      // Perform actual replica rebuild to targetNodeId
      const obj = this.objects.find(o => o.id === job.objectId);
      if (obj) {
        const chunk = obj.chunks.find(c => c.chunkIndex === job.chunkIndex);
        if (chunk) {
          if (!chunk.nodeIds.includes(job.targetNodeId)) {
            chunk.nodeIds.push(job.targetNodeId);
          }
          chunk.isCorrupted = false;
          chunk.actualHash = chunk.sha256Hash;
        }
      }

      repairedCount++;
      if (job.priority === 'high') {
        highPriorityCount++;
      }

      this.logEvent(
        'healing',
        `Replica Restored [${job.priority === 'high' ? 'P1 HIGH PRIORITY' : 'P2 Standard'}]`,
        `Rebuilt shard #${job.chunkIndex} for "${job.objectKey}" onto target node ${job.targetNodeId} (${job.priority === 'high' ? 'Repaired Ahead of Queue' : 'Standard SLA'}).`,
        job.targetNodeId,
        job.objectId,
        { actionType: 'replica_repair' }
      );
    }

    this.recheckObjectHealth();
    this.persistObjects();
    this.persistRepairJobs();
    this.notify();

    return { repairedCount, highPriorityCount };
  }

  /**
   * Background Cluster Rebalance (Equalize disk usage across all nodes)
   */
  static triggerRebalancer() {
    // Sort nodes by disk usage
    const sorted = [...this.nodes].sort((a, b) => b.diskUsedMB - a.diskUsedMB);
    const mostLoaded = sorted[0];
    const leastLoaded = sorted[sorted.length - 1];

    if (mostLoaded && leastLoaded && mostLoaded.diskUsedMB > leastLoaded.diskUsedMB + 20) {
      const diff = +( (mostLoaded.diskUsedMB - leastLoaded.diskUsedMB) / 3 ).toFixed(1);
      mostLoaded.diskUsedMB -= diff;
      leastLoaded.diskUsedMB += diff;

      this.logEvent(
        'info',
        'Cluster Rebalance Executed',
        `Rebalanced ${diff} MB chunk replicas from ${mostLoaded.name} to ${leastLoaded.name}.`
      );
      this.persistNodes();
      this.notify();
    } else {
      this.logEvent('info', 'Cluster In Balance', 'Disk allocation variance across nodes is within nominal 5% threshold.');
    }
  }

  /**
   * Cluster Heartbeat Ticker & Stepwise Prioritized Repair Processor
   */
  private static tickCluster() {
    let stateChanged = false;
    const now = Date.now();

    this.nodes.forEach(node => {
      if (node.status === 'online') {
        node.lastHeartbeat = now;
        node.uptimeSeconds += 4;
        // Jitter latency slightly for realism
        node.latencyMs = +(Math.max(1.8, Math.min(8.5, node.latencyMs + (Math.random() - 0.5) * 0.4))).toFixed(1);
        stateChanged = true;
      }
    });

    // Advance top active repair job in priority queue
    const nextJob = this.repairJobs.find(j => j.status === 'pending' || j.status === 'in_progress');
    if (nextJob) {
      if (nextJob.status === 'pending') {
        nextJob.status = 'in_progress';
        nextJob.progressPercent = 35;
        stateChanged = true;
      } else if (nextJob.status === 'in_progress') {
        nextJob.progressPercent += 35;
        if (nextJob.progressPercent >= 100) {
          nextJob.progressPercent = 100;
          nextJob.status = 'completed';

          const obj = this.objects.find(o => o.id === nextJob.objectId);
          if (obj) {
            const chunk = obj.chunks.find(c => c.chunkIndex === nextJob.chunkIndex);
            if (chunk && !chunk.nodeIds.includes(nextJob.targetNodeId)) {
              chunk.nodeIds.push(nextJob.targetNodeId);
            }
          }

          this.logEvent(
            'healing',
            `Auto-Healed [${nextJob.priority === 'high' ? 'P1 HIGH PRIORITY' : 'P2 Standard'}]`,
            `Completed scheduled failover replica for shard #${nextJob.chunkIndex} of "${nextJob.objectKey}" onto ${nextJob.targetNodeId}.`,
            nextJob.targetNodeId,
            nextJob.objectId,
            { actionType: 'replica_repair' }
          );
          this.recheckObjectHealth();
        }
        stateChanged = true;
      }
      this.persistRepairJobs();
      this.persistObjects();
    }

    if (stateChanged) {
      this.notify();
    }
  }

  private static recheckObjectHealth() {
    this.objects.forEach(obj => {
      const hasCorrupt = obj.chunks.some(c => c.isCorrupted);
      if (hasCorrupt) {
        obj.health = 'corrupt';
        return;
      }

      // Check if enough replicas are online for read quorum
      const policy = DURABILITY_POLICIES[obj.policy];
      const onlineNodes = this.nodes.filter(n => n.status === 'online');
      if (onlineNodes.length < policy.readQuorum) {
        obj.health = 'unavailable';
      } else {
        obj.health = 'healthy';
      }
    });
    this.persistObjects();
  }
}
