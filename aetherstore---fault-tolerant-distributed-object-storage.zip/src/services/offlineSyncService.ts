/**
 * Offline Sync Service
 * Manages disconnected state, optimistic local mutations, and synchronization upon reconnection
 */

export interface QueuedAction {
  id: string;
  type: 'UPLOAD' | 'DELETE' | 'REPAIR';
  payload: any;
  createdAt: number;
  status: 'pending' | 'syncing' | 'failed';
}

const OFFLINE_QUEUE_KEY = 'aetherstore_offline_sync_queue';

export class OfflineSyncService {
  private static isOnline: boolean = typeof navigator !== 'undefined' ? navigator.onLine : true;
  private static queue: QueuedAction[] = [];
  private static listeners: Array<(online: boolean, pendingCount: number) => void> = [];

  static init() {
    try {
      const stored = localStorage.getItem(OFFLINE_QUEUE_KEY);
      if (stored) {
        this.queue = JSON.parse(stored);
      }
    } catch (e) {
      this.queue = [];
    }

    if (typeof window !== 'undefined') {
      window.addEventListener('online', () => {
        this.isOnline = true;
        this.processQueue();
        this.notify();
      });

      window.addEventListener('offline', () => {
        this.isOnline = false;
        this.notify();
      });
    }
  }

  static subscribe(listener: (online: boolean, pendingCount: number) => void) {
    this.listeners.push(listener);
    listener(this.isOnline, this.queue.length);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private static notify() {
    this.listeners.forEach(fn => fn(this.isOnline, this.queue.length));
  }

  static getStatus(): { isOnline: boolean; pendingCount: number } {
    return {
      isOnline: this.isOnline,
      pendingCount: this.queue.length,
    };
  }

  static enqueueAction(type: QueuedAction['type'], payload: any) {
    const action: QueuedAction = {
      id: 'sync_' + Math.random().toString(36).slice(2, 9),
      type,
      payload,
      createdAt: Date.now(),
      status: 'pending',
    };
    this.queue.push(action);
    this.persist();
    this.notify();

    if (this.isOnline) {
      this.processQueue();
    }
  }

  private static async processQueue() {
    if (this.queue.length === 0 || !this.isOnline) return;

    const pending = [...this.queue];
    for (const item of pending) {
      item.status = 'syncing';
      // Simulate real background upload / commit step
      await new Promise(r => setTimeout(r, 400));
      this.queue = this.queue.filter(q => q.id !== item.id);
      this.persist();
      this.notify();
    }
  }

  private static persist() {
    localStorage.setItem(OFFLINE_QUEUE_KEY, JSON.stringify(this.queue));
  }
}
