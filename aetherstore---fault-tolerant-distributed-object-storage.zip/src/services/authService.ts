import { UserAccount } from '../types/storage';
import { WebAuthnService } from './webAuthnService';

const AUTH_USER_KEY = 'aetherstore_current_user_v1';
const ALL_USERS_KEY = 'aetherstore_all_users_v1';

export class AuthService {
  private static currentUser: UserAccount | null = null;
  private static listeners: Array<(user: UserAccount | null) => void> = [];

  static init() {
    try {
      const stored = localStorage.getItem(AUTH_USER_KEY);
      if (stored) {
        this.currentUser = JSON.parse(stored);
      } else {
        // Create default initial demo user
        const defaultUser: UserAccount = {
          id: 'usr_architect_01',
          email: 'shuvammali12@gmail.com',
          name: 'Shuvam Mali (Lead Architect)',
          role: 'admin',
          provider: 'google',
          hasBiometrics: false,
          encryptionSalt: 'aether_salt_seed_2026',
          createdAt: Date.now() - 86400000 * 5,
        };
        this.currentUser = defaultUser;
        this.persistCurrentUser();
      }

      // Seed all users directory if empty
      const existingStr = localStorage.getItem(ALL_USERS_KEY);
      if (!existingStr) {
        const initialDirectory: UserAccount[] = [
          {
            id: 'usr_architect_01',
            email: 'shuvammali12@gmail.com',
            name: 'Shuvam Mali (Lead Architect)',
            role: 'admin',
            provider: 'google',
            hasBiometrics: false,
            encryptionSalt: 'aether_salt_seed_2026',
            createdAt: Date.now() - 86400000 * 5,
          },
          {
            id: 'usr_alex_dev',
            email: 'alex.dev@corp.aether.io',
            name: 'Alex Rivera (Core Infra)',
            role: 'user',
            provider: 'local',
            hasBiometrics: false,
            encryptionSalt: 'salt_alex_99',
            createdAt: Date.now() - 86400000 * 4,
          },
          {
            id: 'usr_sarah_ml',
            email: 'sarah.data@finance.ai',
            name: 'Sarah Chen (Data & Analytics)',
            role: 'user',
            provider: 'google',
            hasBiometrics: false,
            encryptionSalt: 'salt_sarah_77',
            createdAt: Date.now() - 86400000 * 1,
          },
          {
            id: 'usr_backup_bot',
            email: 'backup-daemon@service.internal',
            name: 'Automated DB Backup Daemon',
            role: 'user',
            provider: 'local',
            hasBiometrics: false,
            encryptionSalt: 'salt_daemon_11',
            createdAt: Date.now() - 86400000 * 3,
          },
        ];
        localStorage.setItem(ALL_USERS_KEY, JSON.stringify(initialDirectory));
      }
    } catch (e) {
      console.error('AuthService init error', e);
    }
  }

  static subscribe(listener: (user: UserAccount | null) => void) {
    this.listeners.push(listener);
    listener(this.currentUser);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private static notify() {
    this.listeners.forEach(fn => fn(this.currentUser));
  }

  static getUser(): UserAccount | null {
    return this.currentUser;
  }

  static getAllUsers(): UserAccount[] {
    try {
      const existingStr = localStorage.getItem(ALL_USERS_KEY);
      return existingStr ? JSON.parse(existingStr) : [];
    } catch {
      return [];
    }
  }

  static loginWithOAuth(provider: 'google', email: string, name?: string): UserAccount {
    const trimmedEmail = email.trim().toLowerCase();
    const existingUsers = this.getAllUsers();
    const existing = existingUsers.find(u => u.email.toLowerCase() === trimmedEmail);

    if (existing) {
      existing.provider = provider;
      if (name && name.trim()) existing.name = name.trim();
      this.currentUser = existing;
      this.persistCurrentUser();
      this.saveUserToDirectory(existing);
      this.notify();
      return existing;
    }

    const defaultName = name && name.trim() ? name.trim() : trimmedEmail.split('@')[0];

    const user: UserAccount = {
      id: `usr_${provider}_` + Math.random().toString(36).slice(2, 8),
      email: trimmedEmail,
      name: defaultName,
      provider,
      hasBiometrics: false,
      encryptionSalt: 'salt_' + Math.random().toString(36).slice(2, 10),
      createdAt: Date.now(),
    };

    this.currentUser = user;
    this.persistCurrentUser();
    this.saveUserToDirectory(user);
    this.notify();
    return user;
  }

  static switchUser(email: string): UserAccount | null {
    const trimmedEmail = email.trim().toLowerCase();
    const existing = this.getAllUsers().find(u => u.email.toLowerCase() === trimmedEmail);
    if (existing) {
      this.currentUser = existing;
      this.persistCurrentUser();
      this.notify();
      return existing;
    }
    return null;
  }

  static loginWithEmail(email: string, name: string): UserAccount {
    const user: UserAccount = {
      id: 'usr_local_' + Math.random().toString(36).slice(2, 8),
      email,
      name: name || email.split('@')[0],
      provider: 'local',
      hasBiometrics: false,
      encryptionSalt: 'salt_' + Math.random().toString(36).slice(2, 10),
      createdAt: Date.now(),
    };

    this.currentUser = user;
    this.persistCurrentUser();
    this.saveUserToDirectory(user);
    this.notify();
    return user;
  }

  static async registerBiometricForUser(): Promise<{ success: boolean; credentialId?: string }> {
    if (!this.currentUser) return { success: false };

    try {
      const cred = await WebAuthnService.registerBiometricPasskey(
        this.currentUser.email,
        this.currentUser.name
      );

      this.currentUser.hasBiometrics = true;
      this.currentUser.passkeyCredentialId = cred.credentialId;
      this.persistCurrentUser();
      this.saveUserToDirectory(this.currentUser);
      this.notify();
      return { success: true, credentialId: cred.credentialId };
    } catch (e) {
      console.error('Failed to register passkey', e);
      return { success: false };
    }
  }

  static async loginWithBiometrics(): Promise<boolean> {
    if (!this.currentUser || !this.currentUser.hasBiometrics) {
      return false;
    }
    return WebAuthnService.authenticateWithBiometrics(this.currentUser.passkeyCredentialId);
  }

  static logout() {
    this.currentUser = null;
    localStorage.removeItem(AUTH_USER_KEY);
    this.notify();
  }

  private static persistCurrentUser() {
    if (this.currentUser) {
      localStorage.setItem(AUTH_USER_KEY, JSON.stringify(this.currentUser));
    }
  }

  private static saveUserToDirectory(user: UserAccount) {
    try {
      const existingStr = localStorage.getItem(ALL_USERS_KEY);
      const list: UserAccount[] = existingStr ? JSON.parse(existingStr) : [];
      const filtered = list.filter(u => u.email !== user.email);
      filtered.push(user);
      localStorage.setItem(ALL_USERS_KEY, JSON.stringify(filtered));
    } catch (e) {
      // ignore
    }
  }
}
