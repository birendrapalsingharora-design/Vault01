import { UserQuotaConfig, UserQuotaUsage, QuotaTier, QuotaEnforcementMode, StorageObject } from '../types/storage';

const STORAGE_KEY_QUOTAS = 'aetherstore_user_quotas_v1';

export const QUOTA_TIER_PRESETS: Record<QuotaTier, { storageMB: number; maxObjects: number; description: string }> = {
  Free: {
    storageMB: 25,
    maxObjects: 10,
    description: 'Sandbox tier for transient development testing.',
  },
  Developer: {
    storageMB: 150,
    maxObjects: 30,
    description: 'Standard developer quota with quorum write guarantees.',
  },
  Pro: {
    storageMB: 500,
    maxObjects: 75,
    description: 'High-throughput quota for pipelines and analytics sets.',
  },
  Enterprise: {
    storageMB: 2048,
    maxObjects: 250,
    description: 'Mission-critical tier with dedicated shard balancing priority.',
  },
  Custom: {
    storageMB: 100,
    maxObjects: 20,
    description: 'Custom fine-grained operator quota.',
  },
};

const DEFAULT_QUOTAS: UserQuotaConfig[] = [
  {
    userId: 'usr_architect_01',
    userEmail: 'shuvammali12@gmail.com',
    userName: 'Shuvam Mali (Lead Architect)',
    role: 'admin',
    storageQuotaMB: 1024,
    maxObjectsQuota: 100,
    tier: 'Enterprise',
    enforcementMode: 'hard',
    warningThresholdPercent: 80,
    updatedAt: Date.now() - 86400000 * 2,
    lastUpdatedBy: 'system',
  },
  {
    userId: 'usr_alex_dev',
    userEmail: 'alex.dev@corp.aether.io',
    userName: 'Alex Rivera (Core Infra)',
    role: 'user',
    storageQuotaMB: 150,
    maxObjectsQuota: 30,
    tier: 'Developer',
    enforcementMode: 'hard',
    warningThresholdPercent: 80,
    updatedAt: Date.now() - 86400000 * 4,
    lastUpdatedBy: 'shuvammali12@gmail.com',
  },
  {
    userId: 'usr_sarah_ml',
    userEmail: 'sarah.data@finance.ai',
    userName: 'Sarah Chen (Data & Analytics)',
    role: 'user',
    storageQuotaMB: 300,
    maxObjectsQuota: 50,
    tier: 'Pro',
    enforcementMode: 'hard',
    warningThresholdPercent: 75,
    updatedAt: Date.now() - 86400000 * 1,
    lastUpdatedBy: 'shuvammali12@gmail.com',
  },
  {
    userId: 'usr_backup_bot',
    userEmail: 'backup-daemon@service.internal',
    userName: 'Automated DB Backup Daemon',
    role: 'user',
    storageQuotaMB: 80,
    maxObjectsQuota: 15,
    tier: 'Custom',
    enforcementMode: 'soft',
    warningThresholdPercent: 85,
    updatedAt: Date.now() - 86400000 * 3,
    lastUpdatedBy: 'shuvammali12@gmail.com',
  },
];

export class QuotaService {
  private static quotas: UserQuotaConfig[] = [];
  private static listeners: Array<() => void> = [];

  static init() {
    try {
      const stored = localStorage.getItem(STORAGE_KEY_QUOTAS);
      if (stored) {
        this.quotas = JSON.parse(stored);
      } else {
        this.quotas = [...DEFAULT_QUOTAS];
        this.persist();
      }
    } catch (e) {
      console.error('Failed to init QuotaService', e);
      this.quotas = [...DEFAULT_QUOTAS];
    }
  }

  static subscribe(listener: () => void) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private static notify() {
    this.listeners.forEach(fn => fn());
  }

  private static persist() {
    localStorage.setItem(STORAGE_KEY_QUOTAS, JSON.stringify(this.quotas));
  }

  static getAllQuotas(): UserQuotaConfig[] {
    return [...this.quotas];
  }

  static getQuotaForUser(email: string): UserQuotaConfig {
    const cleanEmail = email.trim().toLowerCase();
    const found = this.quotas.find(q => q.userEmail.toLowerCase() === cleanEmail);
    if (found) return { ...found };

    // Default auto-provisioned standard developer quota
    return {
      userId: 'usr_' + Math.random().toString(36).slice(2, 8),
      userEmail: cleanEmail,
      userName: cleanEmail.split('@')[0],
      role: 'user',
      storageQuotaMB: 150,
      maxObjectsQuota: 30,
      tier: 'Developer',
      enforcementMode: 'hard',
      warningThresholdPercent: 80,
      updatedAt: Date.now(),
      lastUpdatedBy: 'system_auto_provision',
    };
  }

  static saveQuota(config: UserQuotaConfig, adminActor: string = 'admin') {
    const cleanEmail = config.userEmail.trim().toLowerCase();
    const idx = this.quotas.findIndex(q => q.userEmail.toLowerCase() === cleanEmail);

    const updated: UserQuotaConfig = {
      ...config,
      userEmail: cleanEmail,
      updatedAt: Date.now(),
      lastUpdatedBy: adminActor,
    };

    if (idx >= 0) {
      this.quotas[idx] = updated;
    } else {
      this.quotas.push(updated);
    }

    this.persist();
    this.notify();
  }

  static applyTierPreset(email: string, tier: QuotaTier, adminActor: string = 'admin'): UserQuotaConfig {
    const current = this.getQuotaForUser(email);
    const preset = QUOTA_TIER_PRESETS[tier];

    current.tier = tier;
    if (tier !== 'Custom') {
      current.storageQuotaMB = preset.storageMB;
      current.maxObjectsQuota = preset.maxObjects;
    }
    current.updatedAt = Date.now();
    current.lastUpdatedBy = adminActor;

    this.saveQuota(current, adminActor);
    return current;
  }

  static deleteQuota(email: string) {
    const cleanEmail = email.trim().toLowerCase();
    this.quotas = this.quotas.filter(q => q.userEmail.toLowerCase() !== cleanEmail);
    this.persist();
    this.notify();
  }

  static resetToDefaults() {
    this.quotas = [...DEFAULT_QUOTAS];
    this.persist();
    this.notify();
  }

  /**
   * Calculate live usage for all configured accounts by auditing stored objects
   */
  static calculateUsages(objects: StorageObject[]): UserQuotaUsage[] {
    return this.quotas.map(config => {
      const userEmail = config.userEmail.toLowerCase();
      // An object belongs to this user if ownerEmail matches, or if unassigned and matches admin default
      const userObjects = objects.filter(obj => {
        if (obj.ownerEmail) {
          return obj.ownerEmail.toLowerCase() === userEmail;
        }
        // Fallback for default initial objects to lead architect
        return userEmail === 'shuvammali12@gmail.com';
      });

      const usedBytes = userObjects.reduce((acc, obj) => acc + obj.sizeBytes, 0);
      const usedMB = +(usedBytes / (1024 * 1024)).toFixed(2);
      const objectCount = userObjects.length;

      const quotaBytes = config.storageQuotaMB * 1024 * 1024;
      const usedPercent = quotaBytes > 0 ? Math.min(100, +((usedBytes / quotaBytes) * 100).toFixed(1)) : 0;
      const objectsPercent = config.maxObjectsQuota > 0
        ? Math.min(100, +((objectCount / config.maxObjectsQuota) * 100).toFixed(1))
        : 0;

      const isOverStorageQuota = usedBytes > quotaBytes;
      const isOverObjectQuota = config.maxObjectsQuota > 0 && objectCount >= config.maxObjectsQuota;
      const isNearQuotaLimit =
        usedPercent >= config.warningThresholdPercent ||
        (config.maxObjectsQuota > 0 && objectsPercent >= config.warningThresholdPercent);

      return {
        userId: config.userId,
        userEmail: config.userEmail,
        userName: config.userName,
        role: config.role,
        storageQuotaMB: config.storageQuotaMB,
        maxObjectsQuota: config.maxObjectsQuota,
        tier: config.tier,
        enforcementMode: config.enforcementMode,
        warningThresholdPercent: config.warningThresholdPercent,
        usedBytes,
        usedMB,
        objectCount,
        usedPercent,
        objectsPercent,
        isOverStorageQuota,
        isOverObjectQuota,
        isNearQuotaLimit,
        updatedAt: config.updatedAt,
      };
    });
  }

  /**
   * Pre-write check to evaluate if a user upload is within quota constraints
   */
  static checkUploadAllowed(
    userEmail: string,
    newSizeBytes: number,
    currentObjects: StorageObject[]
  ): { allowed: boolean; reason?: string; isWarning?: boolean; message?: string } {
    const quota = this.getQuotaForUser(userEmail);
    const cleanEmail = userEmail.trim().toLowerCase();

    const userObjects = currentObjects.filter(obj => {
      if (obj.ownerEmail) return obj.ownerEmail.toLowerCase() === cleanEmail;
      return cleanEmail === 'shuvammali12@gmail.com';
    });

    const currentUsedBytes = userObjects.reduce((acc, obj) => acc + obj.sizeBytes, 0);
    const quotaBytes = quota.storageQuotaMB * 1024 * 1024;
    const projectedBytes = currentUsedBytes + newSizeBytes;
    const projectedCount = userObjects.length + 1;

    // Check Object Count Quota
    if (quota.maxObjectsQuota > 0 && projectedCount > quota.maxObjectsQuota) {
      if (quota.enforcementMode === 'hard') {
        return {
          allowed: false,
          reason: 'MAX_OBJECTS_EXCEEDED',
          message: `Storage quota rejected: Account ${userEmail} has reached the maximum allowed object count of ${quota.maxObjectsQuota} objects. Current: ${userObjects.length}. Please delete objects or request a quota upgrade.`,
        };
      }
    }

    // Check Storage Volume Quota
    if (projectedBytes > quotaBytes) {
      if (quota.enforcementMode === 'hard') {
        const attemptedMB = (projectedBytes / (1024 * 1024)).toFixed(2);
        return {
          allowed: false,
          reason: 'STORAGE_QUOTA_EXCEEDED',
          message: `Storage quota rejected (Hard Limit): Account ${userEmail} is allocated ${quota.storageQuotaMB} MB. Uploading this file requires ${attemptedMB} MB. Quota limit exceeded by ${((projectedBytes - quotaBytes) / (1024 * 1024)).toFixed(2)} MB.`,
        };
      } else {
        // Soft enforcement mode: allow write but issue warning
        return {
          allowed: true,
          isWarning: true,
          message: `Soft Quota Alert: Account ${userEmail} exceeded allocated storage (${(projectedBytes / (1024 * 1024)).toFixed(2)} MB / ${quota.storageQuotaMB} MB). Write permitted under Soft Enforcement policy.`,
        };
      }
    }

    // Check Warning Threshold
    const projectedPercent = (projectedBytes / quotaBytes) * 100;
    if (projectedPercent >= quota.warningThresholdPercent) {
      return {
        allowed: true,
        isWarning: true,
        message: `Quota Threshold Warning: Account ${userEmail} is currently at ${projectedPercent.toFixed(1)}% of its ${quota.storageQuotaMB} MB quota limit.`,
      };
    }

    return { allowed: true };
  }
}
