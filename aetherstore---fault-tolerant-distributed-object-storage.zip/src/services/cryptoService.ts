/**
 * Real Web Crypto API Service for Client-Side End-to-End Encryption (AES-256-GCM)
 * and Cryptographic Integrity Verification (SHA-256 Checksums)
 */

export class CryptoService {
  /**
   * Compute SHA-256 hash of a string or ArrayBuffer
   */
  static async computeSHA256(data: ArrayBuffer | string): Promise<string> {
    const buffer = typeof data === 'string' ? new TextEncoder().encode(data) : data;
    const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  /**
   * Derive an AES-GCM 256-bit CryptoKey from a user passphrase and salt using PBKDF2
   */
  static async deriveKey(passphrase: string, salt: Uint8Array): Promise<CryptoKey> {
    const enc = new TextEncoder();
    const keyMaterial = await crypto.subtle.importKey(
      'raw',
      enc.encode(passphrase),
      { name: 'PBKDF2' },
      false,
      ['deriveKey']
    );

    return crypto.subtle.deriveKey(
      {
        name: 'PBKDF2',
        salt: salt as unknown as BufferSource,
        iterations: 100000,
        hash: 'SHA-256',
      },
      keyMaterial,
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt', 'decrypt']
    );
  }

  /**
   * Encrypt arbitrary string or ArrayBuffer using AES-256-GCM
   */
  static async encryptPayload(
    payload: string | ArrayBuffer,
    passphrase: string
  ): Promise<{
    ciphertextBase64: string;
    ivBase64: string;
    saltBase64: string;
    keyFingerprint: string;
  }> {
    const salt = crypto.getRandomValues(new Uint8Array(16));
    const iv = crypto.getRandomValues(new Uint8Array(12)); // 96-bit standard for GCM
    const key = await this.deriveKey(passphrase, salt);

    const dataBuffer = typeof payload === 'string' ? new TextEncoder().encode(payload) : payload;
    const ciphertextBuffer = await crypto.subtle.encrypt(
      {
        name: 'AES-GCM',
        iv: iv as unknown as BufferSource,
      },
      key,
      dataBuffer
    );

    const keyFingerprint = (await this.computeSHA256(salt.buffer as ArrayBuffer)).slice(0, 16);

    return {
      ciphertextBase64: this.arrayBufferToBase64(ciphertextBuffer),
      ivBase64: this.arrayBufferToBase64(iv),
      saltBase64: this.arrayBufferToBase64(salt),
      keyFingerprint,
    };
  }

  /**
   * Decrypt AES-256-GCM ciphertext
   */
  static async decryptPayload(
    ciphertextBase64: string,
    ivBase64: string,
    saltBase64: string,
    passphrase: string
  ): Promise<ArrayBuffer> {
    const salt = this.base64ToArrayBuffer(saltBase64);
    const iv = this.base64ToArrayBuffer(ivBase64);
    const ciphertext = this.base64ToArrayBuffer(ciphertextBase64);

    const key = await this.deriveKey(passphrase, new Uint8Array(salt));
    return crypto.subtle.decrypt(
      {
        name: 'AES-GCM',
        iv: iv as unknown as BufferSource,
      },
      key,
      ciphertext as unknown as BufferSource
    );
  }

  /**
   * Utility to convert ArrayBuffer to Base64
   */
  static arrayBufferToBase64(buffer: ArrayBuffer | Uint8Array): string {
    const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
  }

  /**
   * Utility to convert Base64 to ArrayBuffer
   */
  static base64ToArrayBuffer(base64: string): ArrayBuffer {
    const binary = window.atob(base64);
    const len = binary.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return bytes.buffer;
  }

  /**
   * Generate simple parity shard for Erasure Coding demonstration
   * Uses Galois-style byte-wise XOR parity across data chunks
   */
  static generateParity(dataChunksBase64: string[]): string[] {
    if (dataChunksBase64.length === 0) return [];
    
    // Decode all chunks to byte arrays
    const byteArrays = dataChunksBase64.map(b64 => new Uint8Array(this.base64ToArrayBuffer(b64)));
    const maxLen = Math.max(...byteArrays.map(a => a.length));

    // Parity shard 1: Simple XOR summation across all data shards
    const parity1 = new Uint8Array(maxLen);
    for (let i = 0; i < maxLen; i++) {
      let xorVal = 0;
      for (const arr of byteArrays) {
        xorVal ^= i < arr.length ? arr[i] : 0;
      }
      parity1[i] = xorVal;
    }

    // Parity shard 2: Weighted XOR (simulating Reed-Solomon generator matrix row 2)
    const parity2 = new Uint8Array(maxLen);
    for (let i = 0; i < maxLen; i++) {
      let xorVal = 0;
      for (let s = 0; s < byteArrays.length; s++) {
        const val = i < byteArrays[s].length ? byteArrays[s][i] : 0;
        // Simple GF(2^8) scalar multiply approximation: (val * (s + 2)) % 255
        xorVal ^= (val * (s + 2)) % 256;
      }
      parity2[i] = xorVal;
    }

    return [this.arrayBufferToBase64(parity1), this.arrayBufferToBase64(parity2)];
  }
}
