import { BenchmarkMetrics } from '../types/storage';
import { StorageEngine } from './storageEngine';

export class BenchmarkService {
  private static isRunning = false;
  private static metrics: BenchmarkMetrics = {
    totalWrites: 0,
    totalReads: 0,
    successfulWrites: 0,
    successfulReads: 0,
    writeLatencyHistory: [],
    readLatencyHistory: [],
    opsPerSec: 0,
    currentConcurrency: 5,
    conflictsResolved: 0,
  };
  private static listeners: Array<(m: BenchmarkMetrics, running: boolean) => void> = [];

  static subscribe(listener: (m: BenchmarkMetrics, running: boolean) => void) {
    this.listeners.push(listener);
    listener(this.metrics, this.isRunning);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private static notify() {
    this.listeners.forEach(fn => fn({ ...this.metrics }, this.isRunning));
  }

  static getMetrics() {
    return { ...this.metrics };
  }

  static async runBenchmark(concurrency: number = 5, totalOps: number = 30) {
    if (this.isRunning) return;
    this.isRunning = true;
    this.metrics.currentConcurrency = concurrency;
    this.notify();

    const startTime = performance.now();
    let completedOps = 0;

    const worker = async (workerId: number) => {
      while (completedOps < totalOps && this.isRunning) {
        completedOps++;
        const isWrite = Math.random() > 0.4;
        const opStart = performance.now();

        if (isWrite) {
          this.metrics.totalWrites++;
          const dummyPayload = `Benchmark payload data from worker #${workerId} at timestamp ${Date.now()}`;
          const res = await StorageEngine.putObject(
            `bench_worker_${workerId}_${Date.now()}.txt`,
            'benchmark',
            dummyPayload,
            'text/plain',
            'quorum_w2_r2_n3',
            false
          );
          const elapsed = performance.now() - opStart;
          this.metrics.writeLatencyHistory.push(Math.round(elapsed));
          if (this.metrics.writeLatencyHistory.length > 20) this.metrics.writeLatencyHistory.shift();

          if (res.success) {
            this.metrics.successfulWrites++;
          }
        } else {
          this.metrics.totalReads++;
          const objs = StorageEngine.getObjects();
          if (objs.length > 0) {
            const randomObj = objs[Math.floor(Math.random() * objs.length)];
            const res = await StorageEngine.getObject(randomObj.id);
            const elapsed = performance.now() - opStart;
            this.metrics.readLatencyHistory.push(Math.round(elapsed));
            if (this.metrics.readLatencyHistory.length > 20) this.metrics.readLatencyHistory.shift();

            if (res.success) {
              this.metrics.successfulReads++;
              if (res.readRepaired) {
                this.metrics.conflictsResolved++;
              }
            }
          }
        }

        const totalElapsedSec = (performance.now() - startTime) / 1000;
        this.metrics.opsPerSec = totalElapsedSec > 0 ? +(completedOps / totalElapsedSec).toFixed(1) : 0;
        this.notify();
        await new Promise(r => setTimeout(r, 60));
      }
    };

    const workers = Array.from({ length: concurrency }).map((_, i) => worker(i + 1));
    await Promise.all(workers);

    this.isRunning = false;
    this.notify();
  }

  static stopBenchmark() {
    this.isRunning = false;
    this.notify();
  }

  static resetMetrics() {
    this.metrics = {
      totalWrites: 0,
      totalReads: 0,
      successfulWrites: 0,
      successfulReads: 0,
      writeLatencyHistory: [],
      readLatencyHistory: [],
      opsPerSec: 0,
      currentConcurrency: 5,
      conflictsResolved: 0,
    };
    this.notify();
  }
}
