import { useState, useEffect, RefObject } from 'react';

export interface TiltState {
  rotateX: number;
  rotateY: number;
  sheenX: number;
  sheenY: number;
  hasMotion: boolean;
}

export function useDeviceTilt(ref?: RefObject<HTMLElement | null>): TiltState {
  const [tilt, setTilt] = useState<TiltState>({
    rotateX: 0,
    rotateY: 0,
    sheenX: 50,
    sheenY: 50,
    hasMotion: false,
  });

  useEffect(() => {
    // 1. Gyroscope / Device orientation for mobile & tablets
    const handleOrientation = (e: DeviceOrientationEvent) => {
      if (e.beta !== null && e.gamma !== null) {
        // beta: [-180, 180] (front-back tilt)
        // gamma: [-90, 90] (left-right tilt)
        const rotX = Math.max(-15, Math.min(15, (e.beta - 45) * 0.4));
        const rotY = Math.max(-15, Math.min(15, e.gamma * 0.4));
        const sheenX = 50 + (e.gamma / 45) * 40;
        const sheenY = 50 + ((e.beta - 45) / 45) * 40;

        setTilt({
          rotateX: -rotX,
          rotateY: rotY,
          sheenX: Math.max(10, Math.min(90, sheenX)),
          sheenY: Math.max(10, Math.min(90, sheenY)),
          hasMotion: true,
        });
      }
    };

    // 2. Mouse move handler for desktop
    const handleMouseMove = (e: MouseEvent) => {
      if (ref && ref.current) {
        const rect = ref.current.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;

        const rotX = -((y - centerY) / centerY) * 10;
        const rotY = ((x - centerX) / centerX) * 10;
        const sheenX = (x / rect.width) * 100;
        const sheenY = (y / rect.height) * 100;

        setTilt({
          rotateX: rotX,
          rotateY: rotY,
          sheenX,
          sheenY,
          hasMotion: false,
        });
      } else {
        const xRatio = e.clientX / window.innerWidth;
        const yRatio = e.clientY / window.innerHeight;
        setTilt({
          rotateX: (yRatio - 0.5) * -12,
          rotateY: (xRatio - 0.5) * 12,
          sheenX: xRatio * 100,
          sheenY: yRatio * 100,
          hasMotion: false,
        });
      }
    };

    if (typeof window !== 'undefined') {
      window.addEventListener('deviceorientation', handleOrientation, true);
      window.addEventListener('mousemove', handleMouseMove);
    }

    return () => {
      if (typeof window !== 'undefined') {
        window.removeEventListener('deviceorientation', handleOrientation);
        window.removeEventListener('mousemove', handleMouseMove);
      }
    };
  }, [ref]);

  return tilt;
}
