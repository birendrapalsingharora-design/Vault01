import { X, CheckCircle2, AlertTriangle, AlertOctagon, Info, Sparkles } from 'lucide-react';
import { ClusterEvent } from '../types/storage';

interface NotificationCenterProps {
  isOpen: boolean;
  onClose: () => void;
  events: ClusterEvent[];
  isDarkMode: boolean;
  onClear: () => void;
}

export function NotificationCenter({ isOpen, onClose, events, isDarkMode, onClear }: NotificationCenterProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full max-w-sm p-4 sm:p-6 bg-slate-950/70 backdrop-blur-xl animate-fadeIn">
      <div
        className={`h-full flex flex-col rounded-3xl p-5 border shadow-2xl transition-all ${
          isDarkMode ? 'liquid-glass-dark border-slate-800 text-slate-100' : 'bg-white border-slate-300 text-slate-900 shadow-2xl'
        }`}
      >
        <div className={`flex items-center justify-between pb-4 border-b ${
          isDarkMode ? 'border-slate-800/60' : 'border-slate-200'
        }`}>
          <div>
            <h3 className="text-sm font-bold tracking-tight text-slate-900 dark:text-white">Cluster Event Telemetry</h3>
            <p className={`text-[11px] font-mono ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Real-time alerts &amp; self-healing audits</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onClear}
              className={`text-[10px] font-mono font-semibold transition-colors cursor-pointer ${
                isDarkMode ? 'text-slate-400 hover:text-slate-200' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Clear
            </button>
            <button
              onClick={onClose}
              className={`p-1 rounded-lg transition-colors cursor-pointer ${
                isDarkMode
                  ? 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                  : 'text-slate-500 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="flex-1 mt-4 overflow-y-auto space-y-2.5 pr-1 font-mono text-xs">
          {events.length === 0 ? (
            <div className={`text-center py-12 text-xs ${isDarkMode ? 'text-slate-500' : 'text-slate-600 font-medium'}`}>
              No recent alerts or repair events logged.
            </div>
          ) : (
            events.map(evt => {
              const dateStr = new Date(evt.timestamp).toLocaleTimeString();
              const isHealing = evt.type === 'healing';
              const isWarning = evt.type === 'warning';
              const isError = evt.type === 'error';

              return (
                <div
                  key={evt.id}
                  className={`p-3 rounded-2xl border transition-all ${
                    isHealing
                      ? isDarkMode
                        ? 'bg-emerald-950/30 border-emerald-800/70 text-emerald-200'
                        : 'bg-emerald-50 border-emerald-300 text-emerald-950 shadow-sm'
                      : isError
                      ? isDarkMode
                        ? 'bg-rose-950/30 border-rose-800/70 text-rose-200'
                        : 'bg-rose-50 border-rose-300 text-rose-950 shadow-sm'
                      : isWarning
                      ? isDarkMode
                        ? 'bg-amber-950/30 border-amber-800/70 text-amber-200'
                        : 'bg-amber-50 border-amber-300 text-amber-950 shadow-sm'
                      : isDarkMode
                      ? 'bg-slate-900/60 border-slate-800/80 text-slate-300'
                      : 'bg-slate-50 border-slate-300 text-slate-900 shadow-sm'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-1.5 font-bold">
                      {isHealing ? (
                        <Sparkles className="w-3.5 h-3.5 text-emerald-500 dark:text-emerald-400 shrink-0" />
                      ) : isError ? (
                        <AlertOctagon className="w-3.5 h-3.5 text-rose-500 dark:text-rose-400 shrink-0" />
                      ) : isWarning ? (
                        <AlertTriangle className="w-3.5 h-3.5 text-amber-500 dark:text-amber-400 shrink-0" />
                      ) : (
                        <Info className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400 shrink-0" />
                      )}
                      <span className="text-[11px] truncate max-w-[170px]">{evt.title}</span>
                    </div>
                    <span className={`text-[10px] tabular-nums shrink-0 ${isDarkMode ? 'text-slate-500' : 'text-slate-600 font-medium'}`}>{dateStr}</span>
                  </div>
                  <p className={`mt-1 text-[11px] leading-snug break-words ${isDarkMode ? 'text-slate-400' : 'text-slate-700'}`}>
                    {evt.message}
                  </p>
                  {evt.nodeId && (
                    <div className={`mt-1.5 text-[9px] font-semibold ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`}>
                      Node: {evt.nodeId}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
