import { BookOpen, Shield, Cpu, Lock, CheckCircle2, Server, GitFork, Key } from 'lucide-react';

interface ArchitectureDocsProps {
  isDarkMode: boolean;
}

export function ArchitectureDocs({ isDarkMode }: ArchitectureDocsProps) {
  return (
    <div className="space-y-6">
      {/* Hero Banner */}
      <div
        className={`rounded-3xl p-6 sm:p-8 transition-colors ${
          isDarkMode ? 'liquid-glass-dark' : 'liquid-glass-light'
        }`}
      >
        <div className="space-y-2">
          <div className={`flex items-center gap-2 text-xs font-mono font-bold ${isDarkMode ? 'text-cyan-400' : 'text-cyan-800'}`}>
            <BookOpen className="w-3.5 h-3.5" />
            <span>Distributed Systems Engineering Specification</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white">System Architecture &amp; Invariants</h2>
          <p className={`text-xs sm:text-sm max-w-3xl ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
            A comprehensive breakdown of AetherStore&apos;s mathematical proofs, quorum consensus guarantees,
            Reed-Solomon erasure coding, Merkle anti-entropy trees, and client-side cryptographic enclaves.
          </p>
        </div>
      </div>

      {/* Grid of Architectural Pillars */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Pillar 1: Quorum Consensus */}
        <div
          className={`rounded-3xl p-6 sm:p-8 border transition-all ${
            isDarkMode ? 'liquid-glass-dark border-slate-800' : 'liquid-glass-light border-slate-300 shadow-sm'
          }`}
        >
          <div className="flex items-center gap-3 mb-4">
            <div className={`p-3 rounded-2xl border ${
              isDarkMode
                ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20'
                : 'bg-cyan-100 text-cyan-800 border-cyan-300'
            }`}>
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold tracking-tight text-slate-900 dark:text-white">Dynamo-Style Quorum Consensus</h3>
              <p className={`text-xs font-mono ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Pigeonhole Principle Strict Invariant</p>
            </div>
          </div>

          <div className={`space-y-3 text-xs leading-relaxed font-mono ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
            <div className={`p-4 rounded-2xl border font-bold ${
              isDarkMode
                ? 'bg-slate-950/60 border-slate-800 text-cyan-300'
                : 'bg-cyan-50 border-cyan-200 text-cyan-900'
            }`}>
              Formula: W + R &gt; N
            </div>
            <p>
              In our 8-node cluster, objects configured with the Dynamo policy set replica count <code className={`font-bold ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`}>N = 3</code>,
              write quorum <code className={`font-bold ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`}>W = 2</code>, and read quorum <code className={`font-bold ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`}>R = 2</code>.
            </p>
            <p>
              Because <code className={`font-bold ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`}>2 + 2 = 4 &gt; 3</code>, any valid read quorum and any prior write quorum
              must intersect on at least one healthy storage node. This guarantees strict linearizable consistency without
              requiring expensive Paxos two-phase commits.
            </p>
          </div>
        </div>

        {/* Pillar 2: Reed-Solomon Erasure Coding */}
        <div
          className={`rounded-3xl p-6 sm:p-8 border transition-all ${
            isDarkMode ? 'liquid-glass-dark border-slate-800' : 'liquid-glass-light border-slate-300 shadow-sm'
          }`}
        >
          <div className="flex items-center gap-3 mb-4">
            <div className={`p-3 rounded-2xl border ${
              isDarkMode
                ? 'bg-blue-500/10 text-blue-400 border-blue-500/20'
                : 'bg-blue-100 text-blue-800 border-blue-300'
            }`}>
              <GitFork className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold tracking-tight text-slate-900 dark:text-white">Reed-Solomon RS(4,2) Erasure Coding</h3>
              <p className={`text-xs font-mono ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>High Durability with 50% Less Overhead</p>
            </div>
          </div>

          <div className={`space-y-3 text-xs leading-relaxed font-mono ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
            <div className={`p-4 rounded-2xl border font-bold ${
              isDarkMode
                ? 'bg-slate-950/60 border-slate-800 text-blue-300'
                : 'bg-blue-50 border-blue-200 text-blue-900'
            }`}>
              Overhead: 1.5x (vs. 3.0x in 3-Way Replication)
            </div>
            <p>
              Data payloads are sliced into <code className={`font-bold ${isDarkMode ? 'text-blue-400' : 'text-blue-700'}`}>K = 4</code> data shards, and Galois field matrix
              multiplication generates <code className={`font-bold ${isDarkMode ? 'text-blue-400' : 'text-blue-700'}`}>M = 2</code> parity shards (total 6 shards).
            </p>
            <p>
              The storage cluster can withstand any <strong>2 arbitrary simultaneous node failures</strong> or rack outages.
              Any 4 of the 6 shards are sufficient to mathematically reconstruct the original object payload.
            </p>
          </div>
        </div>

        {/* Pillar 3: Merkle Tree Scrubbing & Read Repair */}
        <div
          className={`rounded-3xl p-6 sm:p-8 border transition-all ${
            isDarkMode ? 'liquid-glass-dark border-slate-800' : 'liquid-glass-light border-slate-300 shadow-sm'
          }`}
        >
          <div className="flex items-center gap-3 mb-4">
            <div className={`p-3 rounded-2xl border ${
              isDarkMode
                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                : 'bg-emerald-100 text-emerald-800 border-emerald-300'
            }`}>
              <Server className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold tracking-tight text-slate-900 dark:text-white">Merkle Anti-Entropy &amp; Read Repair</h3>
              <p className={`text-xs font-mono ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Protection Against Silent Bit Rot</p>
            </div>
          </div>

          <div className={`space-y-3 text-xs leading-relaxed font-mono ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
            <p>
              Every shard has an immutable SHA-256 cryptographic digest calculated at ingestion.
            </p>
            <ul className={`space-y-2 list-disc list-inside ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
              <li>
                <strong className={isDarkMode ? 'text-slate-200' : 'text-slate-900'}>Active Read Repair:</strong> When an object is read, every shard&apos;s hash is
                verified against its expected hash. Any corrupted shard triggers an instantaneous background heal from quorum replicas.
              </li>
              <li>
                <strong className={isDarkMode ? 'text-slate-200' : 'text-slate-900'}>Continuous Scrubbing:</strong> Background worker audits node disks, detecting cold
                bit rot before multiple failures compound into data loss.
              </li>
            </ul>
          </div>
        </div>

        {/* Pillar 4: Web Crypto & WebAuthn */}
        <div
          className={`rounded-3xl p-6 sm:p-8 border transition-all ${
            isDarkMode ? 'liquid-glass-dark border-slate-800' : 'liquid-glass-light border-slate-300 shadow-sm'
          }`}
        >
          <div className="flex items-center gap-3 mb-4">
            <div className={`p-3 rounded-2xl border ${
              isDarkMode
                ? 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                : 'bg-amber-100 text-amber-800 border-amber-300'
            }`}>
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold tracking-tight text-slate-900 dark:text-white">Zero-Knowledge Web Crypto &amp; Passkeys</h3>
              <p className={`text-xs font-mono ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>AES-256-GCM + Hardware Secure Enclaves</p>
            </div>
          </div>

          <div className={`space-y-3 text-xs leading-relaxed font-mono ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
            <p>
              All encryption happens exclusively on the client machine before network distribution:
            </p>
            <ul className={`space-y-2 list-disc list-inside ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
              <li>
                <strong className={isDarkMode ? 'text-slate-200' : 'text-slate-900'}>AES-256-GCM:</strong> 256-bit Galois/Counter Mode with 96-bit random IVs and
                128-bit authentication tags providing tamper-evidence.
              </li>
              <li>
                <strong className={isDarkMode ? 'text-slate-200' : 'text-slate-900'}>PBKDF2 Key Derivation:</strong> 100,000 iterations of SHA-256 with cryptographically
                random 16-byte salt prevents rainbow table attacks.
              </li>
              <li>
                <strong className={isDarkMode ? 'text-slate-200' : 'text-slate-900'}>WebAuthn Passkeys:</strong> FIDO2 biometric authentication (Touch ID, Face ID, Windows Hello)
                for master key security.
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
