import { useState, useEffect, useRef, useId } from 'react';
import * as d3 from 'd3';
import {
  Cpu,
  Database,
  Activity,
  Zap,
  Play,
  Pause,
  RotateCcw,
  Server,
  Layers,
  Sparkles,
  Flame,
} from 'lucide-react';
import { StorageNode } from '../types/storage';

interface ResourceDataPoint {
  timestamp: Date;
  cpu: number; // 0 - 100%
  ram: number; // 0 - 100%
  latency: number; // in milliseconds (e.g. 0.5 - 12ms)
  iops: number; // IOPS
}

interface ResourceMonitorProps {
  nodes?: StorageNode[];
  isDarkMode: boolean;
  onNotify?: (type: 'success' | 'warning' | 'error' | 'info', title: string, msg: string) => void;
}

export function ResourceMonitor({ nodes = [], isDarkMode, onNotify }: ResourceMonitorProps) {
  const svgRef = useRef<SVGSVGElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const [activeMetric, setActiveMetric] = useState<'cpu' | 'ram' | 'latency' | 'all'>('cpu');
  const [selectedNodeId, setSelectedNodeId] = useState<string>('all');
  const [isLive, setIsLive] = useState<boolean>(true);
  const [loadMultiplier, setLoadMultiplier] = useState<number>(1.0);
  const [timeWindowSeconds, setTimeWindowSeconds] = useState<number>(45);

  const [history, setHistory] = useState<ResourceDataPoint[]>(() => {
    const points: ResourceDataPoint[] = [];
    const now = Date.now();
    for (let i = 30; i >= 0; i--) {
      const t = new Date(now - i * 1500);
      const baseCpu = 25 + Math.sin(i * 0.4) * 8 + Math.random() * 6;
      const baseRam = 38 + Math.cos(i * 0.2) * 5 + Math.random() * 3;
      const baseLat = 1.2 + Math.sin(i * 0.3) * 0.4 + Math.random() * 0.3;
      points.push({
        timestamp: t,
        cpu: Math.max(5, Math.min(95, baseCpu)),
        ram: Math.max(10, Math.min(95, baseRam)),
        latency: Math.max(0.2, +(baseLat).toFixed(2)),
        iops: Math.round(3200 + Math.sin(i) * 600 + Math.random() * 200),
      });
    }
    return points;
  });

  const latest = history[history.length - 1] || {
    cpu: 28.5,
    ram: 42.0,
    latency: 1.4,
    iops: 3400,
  };

  // Generate live data points
  useEffect(() => {
    if (!isLive) return;

    const interval = setInterval(() => {
      setHistory(prev => {
        const now = new Date();
        const last = prev[prev.length - 1];

        // If load spike is active, ramp up values
        const spike = loadMultiplier > 1;
        const targetCpu = spike
          ? 70 + Math.random() * 25
          : 22 + Math.sin(now.getTime() / 6000) * 12 + Math.random() * 8;
        const targetRam = spike
          ? 65 + Math.random() * 20
          : 36 + Math.cos(now.getTime() / 10000) * 6 + Math.random() * 4;
        const targetLat = spike
          ? 4.5 + Math.random() * 5.2
          : 0.9 + Math.sin(now.getTime() / 4000) * 0.4 + Math.random() * 0.3;

        const smoothedCpu = last ? last.cpu * 0.6 + targetCpu * 0.4 : targetCpu;
        const smoothedRam = last ? last.ram * 0.7 + targetRam * 0.3 : targetRam;
        const smoothedLat = last ? last.latency * 0.5 + targetLat * 0.5 : targetLat;

        const newPoint: ResourceDataPoint = {
          timestamp: now,
          cpu: Math.max(2, Math.min(99, +smoothedCpu.toFixed(1))),
          ram: Math.max(5, Math.min(98, +smoothedRam.toFixed(1))),
          latency: Math.max(0.2, +smoothedLat.toFixed(2)),
          iops: Math.round(
            (spike ? 7500 : 3400) + Math.sin(now.getTime() / 2000) * 400 + Math.random() * 200
          ),
        };

        const cutoff = Date.now() - (timeWindowSeconds + 5) * 1000;
        const filtered = prev.filter(p => p.timestamp.getTime() > cutoff);
        return [...filtered, newPoint];
      });
    }, 1200);

    return () => clearInterval(interval);
  }, [isLive, loadMultiplier, timeWindowSeconds]);

  // Load multiplier decay (auto recovers after 8 seconds)
  useEffect(() => {
    if (loadMultiplier > 1.0) {
      const timer = setTimeout(() => {
        setLoadMultiplier(1.0);
      }, 7000);
      return () => clearTimeout(timer);
    }
  }, [loadMultiplier]);

  // D3 Area Chart Rendering Effect
  useEffect(() => {
    if (!svgRef.current || history.length < 2) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    const width = svgRef.current.clientWidth || 800;
    const height = 280;
    const margin = { top: 20, right: 30, bottom: 35, left: 45 };
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;

    // Root Group
    const g = svg
      .append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    // X Scale (Time)
    const xExtent = d3.extent(history, d => d.timestamp) as [Date, Date];
    const xScale = d3
      .scaleTime()
      .domain(xExtent)
      .range([0, innerWidth]);

    // Y Scale
    let yMax = 100;
    if (activeMetric === 'latency') {
      const maxLat = d3.max(history, d => d.latency) || 5;
      yMax = Math.max(4, Math.ceil(maxLat * 1.25));
    }
    const yScale = d3
      .scaleLinear()
      .domain([0, yMax])
      .nice()
      .range([innerHeight, 0]);

    // Grid lines (Horizontal)
    const yGrid = d3
      .axisLeft(yScale)
      .ticks(5)
      .tickSize(-innerWidth)
      .tickFormat(() => '');

    g.append('g')
      .attr('class', 'grid')
      .call(yGrid)
      .selectAll('line')
      .attr('stroke', isDarkMode ? 'rgba(51, 65, 85, 0.4)' : 'rgba(203, 213, 225, 0.6)')
      .attr('stroke-dasharray', '2,3');

    g.select('.grid .domain').remove();

    // Color definitions
    const defs = svg.append('defs');

    // CPU Gradient (Cyan to Blue)
    const cpuGrad = defs
      .append('linearGradient')
      .attr('id', 'cpu-area-grad')
      .attr('x1', '0%')
      .attr('y1', '0%')
      .attr('x2', '0%')
      .attr('y2', '100%');
    cpuGrad.append('stop').attr('offset', '0%').attr('stop-color', '#06b6d4').attr('stop-opacity', 0.5);
    cpuGrad.append('stop').attr('offset', '100%').attr('stop-color', '#3b82f6').attr('stop-opacity', 0.02);

    // RAM Gradient (Emerald to Teal)
    const ramGrad = defs
      .append('linearGradient')
      .attr('id', 'ram-area-grad')
      .attr('x1', '0%')
      .attr('y1', '0%')
      .attr('x2', '0%')
      .attr('y2', '100%');
    ramGrad.append('stop').attr('offset', '0%').attr('stop-color', '#10b981').attr('stop-opacity', 0.5);
    ramGrad.append('stop').attr('offset', '100%').attr('stop-color', '#14b8a6').attr('stop-opacity', 0.02);

    // Latency Gradient (Amber to Rose)
    const latGrad = defs
      .append('linearGradient')
      .attr('id', 'latency-area-grad')
      .attr('x1', '0%')
      .attr('y1', '0%')
      .attr('x2', '0%')
      .attr('y2', '100%');
    latGrad.append('stop').attr('offset', '0%').attr('stop-color', '#f59e0b').attr('stop-opacity', 0.5);
    latGrad.append('stop').attr('offset', '100%').attr('stop-color', '#ef4444').attr('stop-opacity', 0.02);

    // Render Area & Line Generators
    const drawSeries = (
      getValue: (d: ResourceDataPoint) => number,
      fillGrad: string,
      strokeColor: string,
      label: string
    ) => {
      const areaGen = d3
        .area<ResourceDataPoint>()
        .curve(d3.curveMonotoneX)
        .x(d => xScale(d.timestamp))
        .y0(innerHeight)
        .y1(d => yScale(getValue(d)));

      const lineGen = d3
        .line<ResourceDataPoint>()
        .curve(d3.curveMonotoneX)
        .x(d => xScale(d.timestamp))
        .y(d => yScale(getValue(d)));

      // Render Area
      g.append('path')
        .datum(history)
        .attr('fill', fillGrad)
        .attr('d', areaGen);

      // Render Line
      const path = g
        .append('path')
        .datum(history)
        .attr('fill', 'none')
        .attr('stroke', strokeColor)
        .attr('stroke-width', 2.2)
        .attr('d', lineGen);

      // Latest Value Glowing Pulse Indicator
      const lastPoint = history[history.length - 1];
      if (lastPoint) {
        const lastX = xScale(lastPoint.timestamp);
        const lastY = yScale(getValue(lastPoint));

        g.append('circle')
          .attr('cx', lastX)
          .attr('cy', lastY)
          .attr('r', 7)
          .attr('fill', strokeColor)
          .attr('opacity', 0.3)
          .attr('class', 'animate-ping');

        g.append('circle')
          .attr('cx', lastX)
          .attr('cy', lastY)
          .attr('r', 4)
          .attr('fill', strokeColor)
          .attr('stroke', '#ffffff')
          .attr('stroke-width', 1.5);
      }
    };

    if (activeMetric === 'cpu' || activeMetric === 'all') {
      drawSeries(d => d.cpu, 'url(#cpu-area-grad)', '#06b6d4', 'CPU');
    }
    if (activeMetric === 'ram' || activeMetric === 'all') {
      drawSeries(d => d.ram, 'url(#ram-area-grad)', '#10b981', 'RAM');
    }
    if (activeMetric === 'latency' || activeMetric === 'all') {
      drawSeries(d => d.latency, 'url(#latency-area-grad)', '#f59e0b', 'Latency');
    }

    // X Axis
    const xAxis = d3
      .axisBottom(xScale)
      .ticks(6)
      .tickFormat(d => d3.timeFormat('%H:%M:%S')(d as Date));

    g.append('g')
      .attr('transform', `translate(0,${innerHeight})`)
      .call(xAxis)
      .attr('color', isDarkMode ? '#94a3b8' : '#64748b')
      .selectAll('text')
      .attr('font-size', '10px')
      .attr('font-family', 'ui-monospace, monospace');

    // Y Axis
    const yAxis = d3
      .axisLeft(yScale)
      .ticks(5)
      .tickFormat(d => (activeMetric === 'latency' ? `${d}ms` : `${d}%`));

    g.append('g')
      .call(yAxis)
      .attr('color', isDarkMode ? '#94a3b8' : '#64748b')
      .selectAll('text')
      .attr('font-size', '10px')
      .attr('font-family', 'ui-monospace, monospace');

    // Remove domain lines for clean liquid design
    g.selectAll('.domain').attr('stroke', isDarkMode ? '#334155' : '#cbd5e1');

    // Crosshair Hover Interactivity
    const focus = g.append('g').style('display', 'none');

    focus
      .append('line')
      .attr('class', 'hover-line')
      .attr('y1', 0)
      .attr('y2', innerHeight)
      .attr('stroke', isDarkMode ? '#64748b' : '#94a3b8')
      .attr('stroke-width', 1)
      .attr('stroke-dasharray', '3,3');

    const tooltip = d3.select(containerRef.current).select('.d3-tooltip');

    svg
      .append('rect')
      .attr('transform', `translate(${margin.left},${margin.top})`)
      .attr('width', innerWidth)
      .attr('height', innerHeight)
      .attr('fill', 'transparent')
      .on('mouseover', () => {
        focus.style('display', null);
        tooltip.style('opacity', '1');
      })
      .on('mouseout', () => {
        focus.style('display', 'none');
        tooltip.style('opacity', '0');
      })
      .on('mousemove', function (event) {
        const [xm] = d3.pointer(event);
        const xDate = xScale.invert(xm);

        // Bisect to find closest point
        const bisect = d3.bisector<ResourceDataPoint, Date>(d => d.timestamp).center;
        const index = bisect(history, xDate);
        const d = history[index];
        if (!d) return;

        const px = xScale(d.timestamp);
        focus.select('.hover-line').attr('transform', `translate(${px},0)`);

        tooltip
          .style('opacity', '1')
          .style('left', `${px + margin.left + 15}px`)
          .style('top', `45px`)
          .html(
            `<div class="font-mono text-[11px] space-y-1">
              <div class="text-slate-400 font-bold">${d3.timeFormat('%H:%M:%S')(d.timestamp)}</div>
              <div class="text-cyan-400">CPU Load: <span class="font-bold">${d.cpu}%</span></div>
              <div class="text-emerald-400">RAM Allocated: <span class="font-bold">${d.ram}%</span></div>
              <div class="text-amber-400">Disk I/O Latency: <span class="font-bold">${d.latency} ms</span></div>
              <div class="text-slate-300">Throughput: <span class="font-bold">${d.iops} IOPS</span></div>
            </div>`
          );
      });
  }, [history, activeMetric, isDarkMode, timeWindowSeconds]);

  const handleTriggerSpike = () => {
    setLoadMultiplier(3.0);
    if (onNotify) {
      onNotify(
        'warning',
        'Simulated Load Surge',
        'Injected synthetic concurrent I/O load spike across storage cluster nodes.'
      );
    }
  };

  return (
    <div
      ref={containerRef}
      className={`relative rounded-3xl p-5 sm:p-7 border transition-all ${
        isDarkMode ? 'liquid-glass-dark border-slate-800/80 shadow-2xl' : 'liquid-glass-light border-slate-200 shadow-xl'
      }`}
    >
      {/* Tooltip Floating Box */}
      <div
        className="d3-tooltip pointer-events-none absolute z-20 px-3 py-2 rounded-xl bg-slate-950/90 border border-slate-700 text-white shadow-2xl backdrop-blur-md opacity-0 transition-opacity duration-150"
        style={{ minWidth: '150px' }}
      />

      {/* Header Bar */}
      <div className={`flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-5 border-b ${isDarkMode ? 'border-slate-800/60' : 'border-slate-200'}`}>
        <div>
          <div className={`flex items-center gap-2 text-xs font-mono mb-1 font-bold ${isDarkMode ? 'text-cyan-400' : 'text-cyan-800'}`}>
            <Activity className="w-4 h-4 animate-pulse" />
            <span>Telemetry &amp; Cluster Performance Engine</span>
          </div>
          <h3 className="text-xl font-bold tracking-tight">Real-Time Resource Monitor</h3>
          <p className={`text-xs font-mono mt-0.5 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
            Dynamic D3 area chart tracking multi-core CPU, RAM buffer pool, and NVMe quorum latency
          </p>
        </div>

        {/* Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Node Scope Selector */}
          <div className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-mono ${isDarkMode ? 'bg-slate-900/60 border-slate-700 text-slate-200' : 'bg-white border-slate-300 text-slate-900 shadow-sm'}`}>
            <Server className={`w-3.5 h-3.5 ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`} />
            <select
              value={selectedNodeId}
              onChange={e => setSelectedNodeId(e.target.value)}
              className="bg-transparent outline-none cursor-pointer"
            >
              <option value="all" className={isDarkMode ? 'bg-slate-900 text-slate-100' : 'bg-white text-slate-900'}>
                Cluster Aggregate (All 8 Nodes)
              </option>
              {nodes.map(n => (
                <option key={n.id} value={n.id} className={isDarkMode ? 'bg-slate-900 text-slate-100' : 'bg-white text-slate-900'}>
                  {n.name} ({n.rack})
                </option>
              ))}
            </select>
          </div>

          {/* Time Window */}
          <select
            value={timeWindowSeconds}
            onChange={e => setTimeWindowSeconds(Number(e.target.value))}
            className={`px-2.5 py-1.5 rounded-xl border text-xs font-mono outline-none cursor-pointer ${isDarkMode ? 'bg-slate-900/60 border-slate-700 text-slate-300' : 'bg-white border-slate-300 text-slate-900 shadow-sm'}`}
          >
            <option value={30} className={isDarkMode ? 'bg-slate-900 text-slate-100' : 'bg-white text-slate-900'}>Last 30s</option>
            <option value={45} className={isDarkMode ? 'bg-slate-900 text-slate-100' : 'bg-white text-slate-900'}>Last 45s</option>
            <option value={60} className={isDarkMode ? 'bg-slate-900 text-slate-100' : 'bg-white text-slate-900'}>Last 60s</option>
          </select>

          {/* Play / Pause Toggle */}
          <button
            onClick={() => setIsLive(!isLive)}
            title={isLive ? 'Pause Stream' : 'Resume Live Stream'}
            className={`p-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
              isLive
                ? isDarkMode
                  ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30 hover:bg-cyan-500/20'
                  : 'bg-cyan-100 text-cyan-900 border-cyan-300 shadow-sm hover:bg-cyan-200'
                : isDarkMode
                ? 'bg-slate-800 text-slate-400 border-slate-700 hover:text-slate-200'
                : 'bg-white text-slate-700 border-slate-300 shadow-sm hover:bg-slate-100'
            }`}
          >
            {isLive ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </button>

          {/* Trigger Load Spike */}
          <button
            onClick={handleTriggerSpike}
            disabled={loadMultiplier > 1}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all shadow-sm cursor-pointer ${
              isDarkMode
                ? 'bg-rose-500/15 hover:bg-rose-500/25 text-rose-400 border border-rose-500/30'
                : 'bg-rose-100 hover:bg-rose-200 text-rose-900 border border-rose-300 font-bold'
            }`}
          >
            <Flame className={`w-3.5 h-3.5 ${isDarkMode ? 'text-rose-400' : 'text-rose-700'}`} />
            <span>Simulate Spike</span>
          </button>
        </div>
      </div>

      {/* Telemetry Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 my-5 font-mono">
        {/* CPU Stat Card */}
        <button
          onClick={() => setActiveMetric('cpu')}
          className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
            activeMetric === 'cpu'
              ? isDarkMode
                ? 'bg-cyan-950/40 border-cyan-500 text-cyan-100 shadow-md ring-1 ring-cyan-500/50'
                : 'bg-cyan-50 border-cyan-500 text-cyan-950 ring-2 ring-cyan-400 shadow-md'
              : isDarkMode
              ? 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-300'
              : 'bg-white border-slate-300 hover:border-slate-400 text-slate-800 shadow-sm'
          }`}
        >
          <div className={`flex items-center justify-between text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600 font-medium'}`}>
            <span className="flex items-center gap-1.5">
              <Cpu className={`w-3.5 h-3.5 ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`} />
              <span>CPU Core Load</span>
            </span>
            <span className={`text-[10px] font-bold ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`}>32 vCPUs</span>
          </div>
          <div className={`mt-2 text-2xl font-bold tabular-nums ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`}>
            {latest.cpu}%
          </div>
          <div className={`mt-1 text-[10px] ${isDarkMode ? 'text-slate-500' : 'text-slate-600 font-medium'}`}>Reed-Solomon &amp; AES encryption</div>
        </button>

        {/* RAM Stat Card */}
        <button
          onClick={() => setActiveMetric('ram')}
          className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
            activeMetric === 'ram'
              ? isDarkMode
                ? 'bg-emerald-950/40 border-emerald-500 text-emerald-100 shadow-md ring-1 ring-emerald-500/50'
                : 'bg-emerald-50 border-emerald-500 text-emerald-950 ring-2 ring-emerald-400 shadow-md'
              : isDarkMode
              ? 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-300'
              : 'bg-white border-slate-300 hover:border-slate-400 text-slate-800 shadow-sm'
          }`}
        >
          <div className={`flex items-center justify-between text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600 font-medium'}`}>
            <span className="flex items-center gap-1.5">
              <Database className={`w-3.5 h-3.5 ${isDarkMode ? 'text-emerald-400' : 'text-emerald-700'}`} />
              <span>RAM Buffer Pool</span>
            </span>
            <span className={`text-[10px] font-bold ${isDarkMode ? 'text-emerald-400' : 'text-emerald-700'}`}>64 GB Total</span>
          </div>
          <div className={`mt-2 text-2xl font-bold tabular-nums ${isDarkMode ? 'text-emerald-400' : 'text-emerald-700'}`}>
            {latest.ram}%
          </div>
          <div className={`mt-1 text-[10px] ${isDarkMode ? 'text-slate-500' : 'text-slate-600 font-medium'}`}>Chunk indexing &amp; write cache</div>
        </button>

        {/* Latency Stat Card */}
        <button
          onClick={() => setActiveMetric('latency')}
          className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
            activeMetric === 'latency'
              ? isDarkMode
                ? 'bg-amber-950/40 border-amber-500 text-amber-100 shadow-md ring-1 ring-amber-500/50'
                : 'bg-amber-50 border-amber-500 text-amber-950 ring-2 ring-amber-400 shadow-md'
              : isDarkMode
              ? 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-300'
              : 'bg-white border-slate-300 hover:border-slate-400 text-slate-800 shadow-sm'
          }`}
        >
          <div className={`flex items-center justify-between text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600 font-medium'}`}>
            <span className="flex items-center gap-1.5">
              <Zap className={`w-3.5 h-3.5 ${isDarkMode ? 'text-amber-400' : 'text-amber-700'}`} />
              <span>NVMe Quorum Latency</span>
            </span>
            <span className={`text-[10px] font-bold ${isDarkMode ? 'text-amber-400' : 'text-amber-700'}`}>P99 SLA</span>
          </div>
          <div className={`mt-2 text-2xl font-bold tabular-nums ${isDarkMode ? 'text-amber-400' : 'text-amber-700'}`}>
            {latest.latency} ms
          </div>
          <div className={`mt-1 text-[10px] ${isDarkMode ? 'text-slate-500' : 'text-slate-600 font-medium'}`}>Quorum round-trip consensus</div>
        </button>

        {/* All Combined Metric */}
        <button
          onClick={() => setActiveMetric('all')}
          className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
            activeMetric === 'all'
              ? isDarkMode
                ? 'bg-blue-950/40 border-blue-500 text-blue-100 shadow-md ring-1 ring-blue-500/50'
                : 'bg-blue-50 border-blue-500 text-blue-950 ring-2 ring-blue-400 shadow-md'
              : isDarkMode
              ? 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-300'
              : 'bg-white border-slate-300 hover:border-slate-400 text-slate-800 shadow-sm'
          }`}
        >
          <div className={`flex items-center justify-between text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600 font-medium'}`}>
            <span className="flex items-center gap-1.5">
              <Layers className={`w-3.5 h-3.5 ${isDarkMode ? 'text-blue-400' : 'text-blue-700'}`} />
              <span>Cluster IOPS</span>
            </span>
            <span className={`text-[10px] font-bold ${isDarkMode ? 'text-blue-400' : 'text-blue-700'}`}>Active</span>
          </div>
          <div className={`mt-2 text-2xl font-bold tabular-nums ${isDarkMode ? 'text-blue-400' : 'text-blue-700'}`}>
            {latest.iops}
          </div>
          <div className={`mt-1 text-[10px] ${isDarkMode ? 'text-slate-500' : 'text-slate-600 font-medium'}`}>Multi-metric stacked overview</div>
        </button>
      </div>

      {/* D3 Area Chart Canvas */}
      <div className={`relative w-full overflow-hidden rounded-2xl p-2 sm:p-3 ${isDarkMode ? 'bg-slate-950/40 border border-slate-800/80' : 'bg-slate-50 border border-slate-300 shadow-inner'}`}>
        <div className={`flex items-center justify-between px-2 py-1 text-[11px] font-mono border-b ${isDarkMode ? 'text-slate-400 border-slate-800/40' : 'text-slate-600 border-slate-200 font-semibold'}`}>
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1.5">
              <span className={`w-2.5 h-2.5 rounded-full inline-block ${isDarkMode ? 'bg-cyan-400' : 'bg-cyan-600'}`} />
              <span>CPU %</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className={`w-2.5 h-2.5 rounded-full inline-block ${isDarkMode ? 'bg-emerald-400' : 'bg-emerald-600'}`} />
              <span>RAM %</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className={`w-2.5 h-2.5 rounded-full inline-block ${isDarkMode ? 'bg-amber-400' : 'bg-amber-600'}`} />
              <span>Storage Latency (ms)</span>
            </span>
          </div>
          <span className={`text-[10px] ${isDarkMode ? 'text-slate-500' : 'text-slate-600'}`}>Interactive: Hover to inspect timestamps</span>
        </div>

        <svg
          ref={svgRef}
          className="w-full h-[280px] overflow-visible select-none"
        />
      </div>
    </div>
  );
}
