import { useState, useEffect } from 'react';
import { X, QrCode, Copy, Check, Download, Share2, Lock, ShieldCheck, ExternalLink } from 'lucide-react';
import QRCode from 'qrcode';
import { StorageObject } from '../types/storage';

interface QRCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
  object: StorageObject | null;
  isDarkMode: boolean;
  onNotify: (type: 'success' | 'warning' | 'error' | 'info', title: string, msg: string) => void;
}

export function QRCodeModal({ isOpen, onClose, object, isDarkMode, onNotify }: QRCodeModalProps) {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [hasCopied, setHasCopied] = useState(false);
  const [includePassphraseInLink, setIncludePassphraseInLink] = useState(false);
  const [sharePassphrase, setSharePassphrase] = useState('AetherMasterKey2026!');
  const [isGenerating, setIsGenerating] = useState(false);

  // Compute shareable URL
  const baseUrl = typeof window !== 'undefined' ? window.location.origin + window.location.pathname : 'https://aetherstore.app';
  const shareUrl = object
    ? `${baseUrl}#access=${object.id}&bucket=${object.bucket}&key=${encodeURIComponent(object.originalName)}${
        object.isEncrypted && includePassphraseInLink ? `&pass=${encodeURIComponent(sharePassphrase)}` : ''
      }`
    : '';

  useEffect(() => {
    if (!isOpen || !object) return;

    let isMounted = true;
    setIsGenerating(true);

    QRCode.toDataURL(shareUrl, {
      width: 320,
      margin: 2,
      errorCorrectionLevel: 'M',
      color: {
        dark: '#030712',
        light: '#FFFFFF',
      },
    })
      .then(url => {
        if (isMounted) {
          setQrDataUrl(url);
          setIsGenerating(false);
        }
      })
      .catch(err => {
        console.error('Failed to render QR Code', err);
        if (isMounted) setIsGenerating(false);
      });

    return () => {
      isMounted = false;
    };
  }, [isOpen, object, shareUrl]);

  if (!isOpen || !object) return null;

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setHasCopied(true);
      onNotify('success', 'Link Copied', 'Direct object quorum access URI copied to clipboard.');
      setTimeout(() => setHasCopied(false), 2500);
    } catch {
      onNotify('info', 'Share Link', shareUrl);
    }
  };

  const handleDownloadQR = () => {
    if (!qrDataUrl) return;
    const a = document.createElement('a');
    a.href = qrDataUrl;
    a.download = `AetherStore_QR_${object.originalName.replace(/\.[^/.]+$/, '')}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    onNotify('success', 'QR Code Saved', 'High-res QR image downloaded for offline scanning.');
  };

  const handleNativeShare = async () => {
    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share({
          title: `AetherStore Object: ${object.originalName}`,
          text: `Access distributed object "${object.originalName}" (${(object.sizeBytes / 1024).toFixed(1)} KB) on AetherStore.`,
          url: shareUrl,
        });
        onNotify('success', 'Shared', 'Native share dialog completed.');
      } catch {
        // user cancelled or unsupported
      }
    } else {
      handleCopyLink();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-xl animate-fadeIn overflow-y-auto">
      <div
        className={`relative w-full max-w-md rounded-3xl p-5 sm:p-7 my-auto transition-all shadow-2xl border ${
          isDarkMode
            ? 'liquid-glass-dark border-slate-700/80 text-slate-100 shadow-cyan-950/30'
            : 'bg-white border-slate-300 text-slate-900 shadow-2xl'
        }`}
      >
        {/* Header */}
        <div className={`flex items-center justify-between pb-3.5 border-b ${isDarkMode ? 'border-slate-800/60' : 'border-slate-200'}`}>
          <div className="flex items-center gap-2.5">
            <div className={`p-2 rounded-xl border ${
              isDarkMode
                ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20'
                : 'bg-cyan-100 text-cyan-800 border-cyan-300'
            }`}>
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold tracking-tight text-slate-900 dark:text-white">Share Object via QR Code</h3>
              <p className={`text-[11px] font-mono ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Mobile Camera Scan &amp; Direct Access Link</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
              isDarkMode
                ? 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                : 'text-slate-500 hover:text-slate-900 hover:bg-slate-100'
            }`}
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* QR Code Presentation Box */}
        <div className="mt-4 flex flex-col items-center">
          <div className="p-3.5 rounded-2xl bg-white shadow-xl shadow-cyan-950/20 border border-slate-200 flex items-center justify-center">
            {isGenerating || !qrDataUrl ? (
              <div className="w-56 h-56 flex flex-col items-center justify-center text-slate-500 text-xs font-mono">
                <div className="w-8 h-8 rounded-full border-2 border-cyan-500 border-t-transparent animate-spin mb-2" />
                Generating QR...
              </div>
            ) : (
              <img
                src={qrDataUrl}
                alt={`QR Code for ${object.originalName}`}
                className="w-56 h-56 sm:w-60 sm:h-60 object-contain rounded-lg"
              />
            )}
          </div>
          <p className={`mt-2.5 text-[11px] font-mono text-center ${isDarkMode ? 'text-slate-400' : 'text-slate-600 font-medium'}`}>
            Point smartphone camera at QR code for instant retrieval
          </p>
        </div>

        {/* Object Specs Summary */}
        <div
          className={`mt-4 p-3 rounded-2xl border text-xs font-mono space-y-1.5 ${
            isDarkMode ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-300 text-slate-800 shadow-sm'
          }`}
        >
          <div className="flex justify-between items-center">
            <span className={isDarkMode ? 'text-slate-400' : 'text-slate-600 font-medium'}>Object Key:</span>
            <span className={`font-semibold truncate max-w-[180px] ${isDarkMode ? 'text-slate-200' : 'text-slate-900'}`}>{object.originalName}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className={isDarkMode ? 'text-slate-400' : 'text-slate-600 font-medium'}>Bucket / Size:</span>
            <span className={`font-semibold ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`}>/{object.bucket} · {(object.sizeBytes / 1024).toFixed(1)} KB</span>
          </div>
          <div className="flex justify-between items-center">
            <span className={isDarkMode ? 'text-slate-400' : 'text-slate-600 font-medium'}>Durability Policy:</span>
            <span className={isDarkMode ? 'text-slate-300' : 'text-slate-800 font-medium'}>{object.policy}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className={isDarkMode ? 'text-slate-400' : 'text-slate-600 font-medium'}>Encryption:</span>
            <span className={`font-semibold flex items-center gap-1 ${isDarkMode ? 'text-emerald-400' : 'text-emerald-700'}`}>
              {object.isEncrypted ? <Lock className="w-3 h-3" /> : null}
              {object.isEncrypted ? 'AES-256-GCM' : 'Plaintext'}
            </span>
          </div>
        </div>

        {/* Encrypted Object Passphrase Options */}
        {object.isEncrypted && (
          <div className="mt-3.5 space-y-2">
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="include-passphrase"
                checked={includePassphraseInLink}
                onChange={e => setIncludePassphraseInLink(e.target.checked)}
                className="rounded border-slate-300 accent-cyan-600"
              />
              <label htmlFor="include-passphrase" className={`text-xs cursor-pointer font-medium ${
                isDarkMode ? 'text-slate-300' : 'text-slate-800'
              }`}>
                Embed decryption key in QR code for 1-scan access
              </label>
            </div>
            {includePassphraseInLink && (
              <input
                type="password"
                value={sharePassphrase}
                onChange={e => setSharePassphrase(e.target.value)}
                placeholder="Passphrase"
                className={`w-full p-2 text-xs rounded-xl border outline-none font-mono ${
                  isDarkMode ? 'bg-slate-950 border-slate-800 text-slate-100' : 'bg-white border-slate-300 text-slate-900 shadow-sm'
                }`}
              />
            )}
          </div>
        )}

        {/* Access Link Copy Bar */}
        <div className="mt-3.5 space-y-1.5">
          <label className={`text-[11px] font-mono font-semibold ${isDarkMode ? 'text-slate-400' : 'text-slate-700'}`}>Quorum Access URI</label>
          <div className="flex items-center gap-1.5">
            <input
              type="text"
              readOnly
              value={shareUrl}
              className={`flex-1 min-w-0 px-3 py-2 text-xs rounded-xl border font-mono truncate outline-none select-all ${
                isDarkMode ? 'bg-slate-950 border-slate-800 text-slate-300' : 'bg-white border-slate-300 text-slate-900 shadow-sm'
              }`}
            />
            <button
              onClick={handleCopyLink}
              title="Copy Link"
              className="p-2 rounded-xl text-xs font-semibold bg-cyan-600 hover:bg-cyan-500 text-white shrink-0 shadow-sm transition-colors flex items-center justify-center min-w-[36px] cursor-pointer"
            >
              {hasCopied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Action Buttons for Mobile Accessibility */}
        <div className={`mt-4 pt-3.5 border-t grid grid-cols-2 gap-2.5 ${
          isDarkMode ? 'border-slate-800/60' : 'border-slate-200'
        }`}>
          <button
            onClick={handleDownloadQR}
            className={`w-full flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl text-xs font-semibold border transition-colors cursor-pointer ${
              isDarkMode
                ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-800 border-slate-300 shadow-sm'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download PNG</span>
          </button>

          <button
            onClick={handleNativeShare}
            className="w-full flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl text-xs font-semibold bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white shadow-md shadow-cyan-600/20 transition-all cursor-pointer"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>Share Link</span>
          </button>
        </div>
      </div>
    </div>
  );
}
