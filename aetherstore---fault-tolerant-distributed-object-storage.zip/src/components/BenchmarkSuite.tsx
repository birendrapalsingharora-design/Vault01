import { useState, useEffect } from 'react';
import { Play, Square, RotateCcw, Activity, Zap, CheckCircle2, TrendingUp, Cpu } from 'lucide-react';
import { BenchmarkMetrics } from '../types/storage';
import { BenchmarkService } from '../services/benchmarkService';

interface BenchmarkSuiteProps {
  isDarkMode: boolean;
  onNotify: (type: 'success' | 'warning' | 'error' | 'info', title: string, msg: string) => void;
}

export function BenchmarkSuite({ isDarkMode, onNotify }: BenchmarkSuiteProps) {
  const [metrics, setMetrics] = useState<BenchmarkMetrics>(BenchmarkService.getMetrics());
  const [isRunning, setIsRunning] = useState(false);
  const [concurrency, setConcurrency] = useState(6);
  const [totalOperations, setTotalOperations] = useState(40);

  useEffect(() => {
    const unsub = BenchmarkService.subscribe((m, running) => {
      setMetrics(m);
      setIsRunning(running);
    });
    return unsub;
  }, []);

  const handleStart = () => {
    BenchmarkService.runBenchmark(concurrency, totalOperations);
    onNotify('info', 'Stress Test Started', `Simulating ${concurrency} concurrent client workers reading & writing.`);
  };

  const handleStop = () => {
    BenchmarkService.stopBenchmark();
    onNotify('warning', 'Benchmark Aborted', 'Worker pool halted.');
  };

  const handleReset = () => {
    BenchmarkService.resetMetrics();
    onNotify('info', 'Metrics Reset', 'Counters and latency histograms cleared.');
  };

  const totalOps = metrics.totalWrites + metrics.totalReads;
  const successOps = metrics.successfulWrites + metrics.successfulReads;
  const successRate = totalOps > 0 ? ((successOps / totalOps) * 100).toFixed(1) : '100.0';

  const avgWriteLat =
    metrics.writeLatencyHistory.length > 0
      ? (metrics.writeLatencyHistory.reduce((a, b) => a + b, 0) / metrics.writeLatencyHistory.length).toFixed(1)
      : '0.0';

  const avgReadLat =
    metrics.readLatencyHistory.length > 0
      ? (metrics.readLatencyHistory.reduce((a, b) => a + b, 0) / metrics.readLatencyHistory.length).toFixed(1)
      : '0.0';

  return (
    <div className="space-y-6">
      {/* Header */}
      <div
        className={`rounded-3xl p-6 sm:p-8 transition-colors ${
          isDarkMode ? 'liquid-glass-dark' : 'liquid-glass-light'
        }`}
      >
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className={`flex items-center gap-2 text-xs font-mono font-bold ${isDarkMode ? 'text-cyan-400' : 'text-cyan-800'}`}>
              <Activity className="w-3.5 h-3.5" />
              <span>Concurrent Ingestion &amp; Retrieval Benchmark</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white">Concurrent Read / Write Stress Suite</h2>
            <p className={`text-xs sm:text-sm max-w-2xl ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
              Evaluate storage orchestrator throughput, latency distributions, and quorum contention under high
              concurrency loads.
            </p>
          </div>

          <div className="flex items-center gap-3">
            {isRunning ? (
              <button
                onClick={handleStop}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-semibold bg-rose-600 hover:bg-rose-500 text-white shadow-lg shadow-rose-600/20 transition-all cursor-pointer"
              >
                <Square className="w-4 h-4 fill-current" />
                <span>Halt Workers</span>
              </button>
            ) : (
              <button
                onClick={handleStart}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-semibold bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white shadow-lg shadow-cyan-600/20 transition-all cursor-pointer"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>Launch Testbench</span>
              </button>
            )}

            <button
              onClick={handleReset}
              disabled={isRunning}
              className={`p-2.5 rounded-xl border transition-colors cursor-pointer ${
                isDarkMode
                  ? 'text-slate-400 hover:text-slate-200 border-slate-700/80 hover:bg-slate-800'
                  : 'text-slate-600 hover:text-slate-900 border-slate-300 hover:bg-slate-100 shadow-sm'
              }`}
              title="Reset Counters"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Worker Configuration Parameters */}
        <div className={`mt-6 grid grid-cols-1 sm:grid-cols-2 gap-4 pt-6 border-t ${
          isDarkMode ? 'border-slate-800/40' : 'border-slate-200'
        }`}>
          <div>
            <div className="flex justify-between text-xs font-semibold mb-2 font-mono">
              <span className={isDarkMode ? 'text-slate-300' : 'text-slate-800'}>Concurrent Workers</span>
              <span className={`font-bold ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`}>{concurrency} threads</span>
            </div>
            <input
              type="range"
              min="1"
              max="16"
              disabled={isRunning}
              value={concurrency}
              onChange={e => setConcurrency(Number(e.target.value))}
              className="w-full accent-cyan-600 cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs font-semibold mb-2 font-mono">
              <span className={isDarkMode ? 'text-slate-300' : 'text-slate-800'}>Target Operation Volume</span>
              <span className={`font-bold ${isDarkMode ? 'text-blue-400' : 'text-blue-700'}`}>{totalOperations} operations</span>
            </div>
            <input
              type="range"
              min="10"
              max="100"
              step="10"
              disabled={isRunning}
              value={totalOperations}
              onChange={e => setTotalOperations(Number(e.target.value))}
              className="w-full accent-blue-600 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* Metrics Scoreboard Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div
          className={`p-5 rounded-3xl border transition-all ${
            isDarkMode ? 'liquid-glass-dark border-slate-800' : 'liquid-glass-light border-slate-300 shadow-sm'
          }`}
        >
          <div className={`text-xs font-bold font-mono ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Effective Throughput</div>
          <div className={`mt-2 text-2xl sm:text-3xl font-bold font-mono tabular-nums ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`}>
            {metrics.opsPerSec} <span className={`text-xs font-normal ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>ops/sec</span>
          </div>
          <div className={`mt-1 text-[11px] font-mono ${isDarkMode ? 'text-slate-500' : 'text-slate-600 font-medium'}`}>Real-time IOPS rate</div>
        </div>

        <div
          className={`p-5 rounded-3xl border transition-all ${
            isDarkMode ? 'liquid-glass-dark border-slate-800' : 'liquid-glass-light border-slate-300 shadow-sm'
          }`}
        >
          <div className={`text-xs font-bold font-mono ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Avg Write Latency</div>
          <div className={`mt-2 text-2xl sm:text-3xl font-bold font-mono tabular-nums ${isDarkMode ? 'text-emerald-400' : 'text-emerald-700'}`}>
            {avgWriteLat} <span className={`text-xs font-normal ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>ms</span>
          </div>
          <div className={`mt-1 text-[11px] font-mono ${isDarkMode ? 'text-slate-500' : 'text-slate-600 font-medium'}`}>Includes SHA-256 chunking</div>
        </div>

        <div
          className={`p-5 rounded-3xl border transition-all ${
            isDarkMode ? 'liquid-glass-dark border-slate-800' : 'liquid-glass-light border-slate-300 shadow-sm'
          }`}
        >
          <div className={`text-xs font-bold font-mono ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Avg Read Latency</div>
          <div className={`mt-2 text-2xl sm:text-3xl font-bold font-mono tabular-nums ${isDarkMode ? 'text-blue-400' : 'text-blue-700'}`}>
            {avgReadLat} <span className={`text-xs font-normal ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`}>ms</span>
          </div>
          <div className={`mt-1 text-[11px] font-mono ${isDarkMode ? 'text-slate-500' : 'text-slate-600 font-medium'}`}>Quorum verification &amp; decode</div>
        </div>

        <div
          className={`p-5 rounded-3xl border transition-all ${
            isDarkMode ? 'liquid-glass-dark border-slate-800' : 'liquid-glass-light border-slate-300 shadow-sm'
          }`}
        >
          <div className={`text-xs font-bold font-mono ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Quorum Success Rate</div>
          <div className={`mt-2 text-2xl sm:text-3xl font-bold font-mono tabular-nums ${isDarkMode ? 'text-emerald-400' : 'text-emerald-700'}`}>
            {successRate}%
          </div>
          <div className={`mt-1 text-[11px] font-mono ${isDarkMode ? 'text-slate-500' : 'text-slate-600 font-medium'}`}>
            {metrics.conflictsResolved} conflicts auto-repaired
          </div>
        </div>
      </div>

      {/* Latency History Graph & Execution Feed */}
      <div
        className={`rounded-3xl p-6 sm:p-8 transition-colors ${
          isDarkMode ? 'liquid-glass-dark' : 'liquid-glass-light'
        }`}
      >
        <h3 className="text-base font-bold tracking-tight mb-4 flex items-center gap-2 text-slate-900 dark:text-white">
          <TrendingUp className={`w-4 h-4 ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`} />
          <span>Real-time Operation Latency Samples (ms)</span>
        </h3>

        <div className={`h-40 flex items-end gap-1.5 pt-4 pb-2 border-b overflow-hidden ${
          isDarkMode ? 'border-slate-800/60' : 'border-slate-200'
        }`}>
          {metrics.writeLatencyHistory.length === 0 && metrics.readLatencyHistory.length === 0 ? (
            <div className={`w-full text-center text-xs font-mono my-auto ${isDarkMode ? 'text-slate-500' : 'text-slate-600'}`}>
              Launch the stress benchmark to generate live IOPS latency distribution charts.
            </div>
          ) : (
            metrics.writeLatencyHistory.map((lat, idx) => {
              const height = Math.min(100, Math.max(10, lat * 2.5));
              return (
                <div key={idx} className="flex-1 flex flex-col items-center gap-1 group relative">
                  <div
                    className="w-full rounded-t-lg bg-gradient-to-t from-cyan-600 to-blue-500 group-hover:brightness-125 transition-all"
                    style={{ height: `${height}%` }}
                  />
                  <span className={`text-[9px] font-mono tabular-nums ${isDarkMode ? 'text-slate-500' : 'text-slate-600'}`}>{lat}</span>
                </div>
              );
            })
          )}
        </div>

        <div className={`mt-4 flex items-center justify-between text-xs font-mono ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
          <span className="font-medium">Total Operations: {totalOps}</span>
          <span className={`font-semibold ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`}>
            Writes: {metrics.successfulWrites} · Reads: {metrics.successfulReads}
          </span>
        </div>
      </div>
    </div>
  );
}
