import { useState, useRef } from 'react';
import {
  Server,
  HardDrive,
  Activity,
  AlertTriangle,
  RotateCcw,
  ZapOff,
  Split,
  Layers,
  Database,
  Info,
} from 'lucide-react';
import { StorageNode, StorageObject } from '../types/storage';
import { StorageEngine } from '../services/storageEngine';
import { useDeviceTilt } from '../hooks/useDeviceTilt';
import { ResourceMonitor } from './ResourceMonitor';

interface ClusterVisualizerProps {
  nodes: StorageNode[];
  objects: StorageObject[];
  isDarkMode: boolean;
  onNotify: (type: 'success' | 'warning' | 'error' | 'info', title: string, msg: string) => void;
}

export function ClusterVisualizer({ nodes, objects, isDarkMode, onNotify }: ClusterVisualizerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const tilt = useDeviceTilt(containerRef);
  const [selectedNode, setSelectedNode] = useState<StorageNode | null>(null);

  const rackAlphaNodes = nodes.filter(n => n.rack === 'Rack-Alpha');
  const rackBetaNodes = nodes.filter(n => n.rack === 'Rack-Beta');

  const totalCapacityMB = nodes.reduce((acc, n) => acc + n.diskCapacityMB, 0);
  const totalUsedMB = nodes.reduce((acc, n) => acc + n.diskUsedMB, 0);
  const onlineCount = nodes.filter(n => n.status === 'online').length;
  const isPartitionActive = StorageEngine.isPartitionActive();

  const handleCrashNode = (node: StorageNode) => {
    StorageEngine.crashNode(node.id);
    onNotify('warning', 'Node Crashed', `${node.name} forced offline via Chaos injection.`);
  };

  const handleReviveNode = (node: StorageNode) => {
    StorageEngine.reviveNode(node.id);
    onNotify('success', 'Node Revived', `${node.name} reconnected and synced with quorum.`);
  };

  // Find chunks stored on selected node
  const chunksOnSelectedNode = selectedNode
    ? objects.flatMap(obj =>
        obj.chunks
          .filter(c => c.nodeIds.includes(selectedNode.id))
          .map(c => ({
            ...c,
            objectKey: obj.originalName,
            isEncrypted: obj.isEncrypted,
            policy: obj.policy,
          }))
      )
    : [];

  return (
    <div ref={containerRef} className="space-y-6 perspective-1000">
      {/* Cluster Overview Header - Liquid Glass with 3D Tilt */}
      <div
        style={{
          transform: `rotateX(${tilt.rotateX * 0.4}deg) rotateY(${tilt.rotateY * 0.4}deg)`,
          transition: 'transform 0.15s ease-out',
        }}
        className={`relative overflow-hidden rounded-3xl p-6 sm:p-8 transition-colors ${
          isDarkMode ? 'liquid-glass-dark' : 'liquid-glass-light'
        }`}
      >
        {/* Dynamic Specular Sheen responding to device motion / cursor */}
        <div
          className="absolute inset-0 pointer-events-none opacity-40 transition-opacity duration-300"
          style={{
            background: `radial-gradient(circle 400px at ${tilt.sheenX}% ${tilt.sheenY}%, rgba(56, 189, 248, 0.25), transparent 70%)`,
          }}
        />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className={`flex items-center gap-2 text-xs font-mono font-bold ${isDarkMode ? 'text-cyan-400' : 'text-cyan-800'}`}>
              <span className={`w-2 h-2 rounded-full animate-ping ${isDarkMode ? 'bg-cyan-400' : 'bg-cyan-600'}`} />
              <span>Multi-AZ Distributed Storage Topology</span>
              <span>·</span>
              <span>Quorum W+R &gt; N Guaranteed</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight">
              Fault-Tolerant Node Cluster
            </h2>
            <p className={`text-xs sm:text-sm max-w-2xl ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
              8 independent storage nodes distributed across 2 isolated availability zones (Rack-Alpha &amp; Rack-Beta).
              Resilient to hardware crash, silent bit rot, and partial network partitions.
            </p>
          </div>

          {/* Quick Metrics Bar */}
          <div className="flex flex-wrap items-center gap-3">
            <div
              className={`p-3 rounded-2xl border text-xs font-mono ${
                isDarkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white border-slate-300 shadow-sm'
              }`}
            >
              <div className={isDarkMode ? 'text-slate-400' : 'text-slate-600 font-semibold'}>Cluster Health</div>
              <div className={`text-sm font-semibold tabular-nums ${isDarkMode ? 'text-emerald-400' : 'text-emerald-700'}`}>
                {onlineCount} / {nodes.length} Nodes Active
              </div>
            </div>

            <div
              className={`p-3 rounded-2xl border text-xs font-mono ${
                isDarkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white border-slate-300 shadow-sm'
              }`}
            >
              <div className={isDarkMode ? 'text-slate-400' : 'text-slate-600 font-semibold'}>Storage Allocated</div>
              <div className={`text-sm font-semibold tabular-nums ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`}>
                {totalUsedMB.toFixed(1)} MB / {(totalCapacityMB / 1024).toFixed(0)} GB
              </div>
            </div>

            <div
              className={`p-3 rounded-2xl border text-xs font-mono ${
                isDarkMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white border-slate-300 shadow-sm'
              }`}
            >
              <div className={isDarkMode ? 'text-slate-400' : 'text-slate-600 font-semibold'}>Partition Status</div>
              <div
                className={`text-sm font-semibold tabular-nums ${
                  isPartitionActive
                    ? isDarkMode
                      ? 'text-amber-400'
                      : 'text-amber-700'
                    : isDarkMode
                    ? 'text-emerald-400'
                    : 'text-emerald-700'
                }`}
              >
                {isPartitionActive ? 'Isolated (Split-Brain Guard)' : 'Unified Inter-Rack'}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Rack Alpha & Rack Beta Visual Racks */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Rack Alpha */}
        <div
          className={`rounded-3xl p-5 sm:p-6 transition-all border ${
            isDarkMode ? 'liquid-glass-dark border-slate-800/80' : 'liquid-glass-light border-slate-300 shadow-sm'
          }`}
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 sm:gap-4 mb-5">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-3 h-3 rounded-full bg-cyan-500 shadow-sm shadow-cyan-500/50 shrink-0" />
              <div className="min-w-0">
                <h3 className={`text-sm font-bold tracking-tight truncate sm:whitespace-normal ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                  Rack-Alpha (Zone: us-east-1a)
                </h3>
                <p className={`text-[11px] font-mono truncate sm:whitespace-normal ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  Independent Power &amp; Top-of-Rack Switch
                </p>
              </div>
            </div>
            <span
              className={`text-xs font-mono tabular-nums shrink-0 self-start sm:self-auto px-2.5 py-0.5 rounded-lg border ${
                isDarkMode
                  ? 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20'
                  : 'text-cyan-900 bg-cyan-100 border-cyan-300 font-bold'
              }`}
            >
              {rackAlphaNodes.filter(n => n.status === 'online').length} / 4 Online
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {rackAlphaNodes.map(node => (
              <NodeCard
                key={node.id}
                node={node}
                isDarkMode={isDarkMode}
                isSelected={selectedNode?.id === node.id}
                onSelect={() => setSelectedNode(node)}
                onCrash={() => handleCrashNode(node)}
                onRevive={() => handleReviveNode(node)}
              />
            ))}
          </div>
        </div>

        {/* Rack Beta */}
        <div
          className={`rounded-3xl p-5 sm:p-6 transition-all border ${
            isDarkMode ? 'liquid-glass-dark border-slate-800/80' : 'liquid-glass-light border-slate-300 shadow-sm'
          }`}
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 sm:gap-4 mb-5">
            <div className="flex items-center gap-2.5 min-w-0">
              <div
                className={`w-3 h-3 rounded-full shadow-sm shrink-0 ${
                  isPartitionActive
                    ? 'bg-amber-500 shadow-amber-500/50 animate-pulse'
                    : 'bg-blue-600 shadow-blue-600/50'
                }`}
              />
              <div className="min-w-0">
                <h3 className={`text-sm font-bold tracking-tight truncate sm:whitespace-normal ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                  Rack-Beta (Zone: us-east-1b)
                </h3>
                <p className={`text-[11px] font-mono truncate sm:whitespace-normal ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  Secondary Failure Domain &amp; Redundancy
                </p>
              </div>
            </div>
            <span
              className={`text-xs font-mono tabular-nums shrink-0 self-start sm:self-auto px-2.5 py-0.5 rounded-lg border ${
                isDarkMode
                  ? 'text-blue-400 bg-blue-500/10 border-blue-500/20'
                  : 'text-blue-900 bg-blue-100 border-blue-300 font-bold'
              }`}
            >
              {rackBetaNodes.filter(n => n.status === 'online').length} / 4 Online
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {rackBetaNodes.map(node => (
              <NodeCard
                key={node.id}
                node={node}
                isDarkMode={isDarkMode}
                isSelected={selectedNode?.id === node.id}
                onSelect={() => setSelectedNode(node)}
                onCrash={() => handleCrashNode(node)}
                onRevive={() => handleReviveNode(node)}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Real-Time Resource Monitor with Animated D3 Area Chart */}
      <ResourceMonitor nodes={nodes} isDarkMode={isDarkMode} onNotify={onNotify} />

      {/* Selected Node Detailed Inspector */}
      {selectedNode && (
        <div
          className={`rounded-3xl p-6 border transition-all animate-fadeIn ${
            isDarkMode ? 'liquid-glass-dark border-cyan-500/30' : 'liquid-glass-light border-cyan-400/70 shadow-md'
          }`}
        >
          <div className={`flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b ${isDarkMode ? 'border-slate-800/60' : 'border-slate-200'}`}>
            <div className="flex items-center gap-3">
              <div className={`p-3 rounded-2xl border ${isDarkMode ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20' : 'bg-cyan-100 text-cyan-800 border-cyan-300'}`}>
                <Server className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className={`text-base font-bold tracking-tight ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>{selectedNode.name}</h3>
                  <span
                    className={`text-[11px] font-mono px-2 py-0.5 rounded-md font-semibold ${
                      selectedNode.status === 'online'
                        ? isDarkMode
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                        : selectedNode.status === 'crashed'
                        ? isDarkMode
                          ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                          : 'bg-rose-100 text-rose-900 border border-rose-300'
                        : isDarkMode
                        ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                        : 'bg-amber-100 text-amber-900 border border-amber-300'
                    }`}
                  >
                    {selectedNode.status.toUpperCase()}
                  </span>
                </div>
                <p className={`text-xs font-mono mt-0.5 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  {selectedNode.id} · {selectedNode.rack} · Zone: {selectedNode.zone} · Latency: {selectedNode.latencyMs}ms
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {selectedNode.status === 'crashed' ? (
                <button
                  onClick={() => handleReviveNode(selectedNode)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white transition-colors cursor-pointer shadow-sm"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  Revive Node
                </button>
              ) : (
                <button
                  onClick={() => handleCrashNode(selectedNode)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-rose-600 hover:bg-rose-500 text-white transition-colors cursor-pointer shadow-sm"
                >
                  <ZapOff className="w-3.5 h-3.5" />
                  Crash Node (Chaos)
                </button>
              )}
              <button
                onClick={() => setSelectedNode(null)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                  isDarkMode
                    ? 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    : 'bg-slate-200 text-slate-800 hover:bg-slate-300 shadow-sm'
                }`}
              >
                Close Inspector
              </button>
            </div>
          </div>

          {/* Stored Replicas & Chunks */}
          <div className="mt-4 space-y-3">
            <div className={`flex items-center justify-between text-xs font-mono ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
              <span className="font-semibold">Resident Object Chunks ({chunksOnSelectedNode.length})</span>
              <span>SHA-256 Block Digest Verification</span>
            </div>

            {chunksOnSelectedNode.length === 0 ? (
              <div className={`p-8 text-center text-xs font-mono ${isDarkMode ? 'text-slate-500' : 'text-slate-600'}`}>
                No active object chunks mapped to this node yet.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-60 overflow-y-auto pr-1">
                {chunksOnSelectedNode.map((c, idx) => (
                  <div
                    key={idx}
                    className={`p-3 rounded-xl border text-xs font-mono transition-all ${
                      c.isCorrupted
                        ? isDarkMode
                          ? 'bg-rose-950/30 border-rose-800/80 text-rose-300'
                          : 'bg-rose-50 border-rose-300 text-rose-950 shadow-sm'
                        : isDarkMode
                        ? 'bg-slate-950/60 border-slate-800/80 text-slate-300'
                        : 'bg-white border-slate-300 text-slate-900 shadow-sm'
                    }`}
                  >
                    <div className="flex items-center justify-between font-semibold">
                      <span className="truncate max-w-[180px]">{c.objectKey}</span>
                      <span className={`text-[10px] font-bold ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`}>
                        {c.isParity ? 'PARITY SHARD' : `CHUNK #${c.chunkIndex}`}
                      </span>
                    </div>
                    <div className={`mt-1 text-[11px] truncate ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                      SHA: {c.sha256Hash.slice(0, 16)}...
                    </div>
                    <div className="mt-1 flex items-center justify-between text-[10px]">
                      <span>Size: {c.sizeBytes} bytes</span>
                      <span className={c.isCorrupted ? (isDarkMode ? 'text-rose-400 font-bold' : 'text-rose-700 font-bold') : (isDarkMode ? 'text-emerald-400 font-bold' : 'text-emerald-700 font-bold')}>
                        {c.isCorrupted ? 'CORRUPT (BIT ROT)' : 'VALID CHECKSUM'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

interface NodeCardProps {
  node: StorageNode;
  isDarkMode: boolean;
  isSelected: boolean;
  onSelect: () => void;
  onCrash: () => void;
  onRevive: () => void;
}

function NodeCard({ node, isDarkMode, isSelected, onSelect, onCrash, onRevive }: NodeCardProps) {
  const isCrashed = node.status === 'crashed';
  const isPartitioned = node.status === 'partitioned';
  const usagePercent = Math.min(100, Math.round((node.diskUsedMB / node.diskCapacityMB) * 100));

  return (
    <div
      onClick={onSelect}
      className={`group relative p-4 rounded-2xl cursor-pointer border transition-all duration-200 select-none ${
        isSelected
          ? isDarkMode
            ? 'border-cyan-400 ring-2 ring-cyan-500/20 shadow-lg shadow-cyan-500/10'
            : 'border-cyan-600 ring-2 ring-cyan-400/40 shadow-md bg-cyan-50/50'
          : isDarkMode
          ? 'bg-slate-900/60 hover:bg-slate-850/80 border-slate-800/80 hover:border-slate-700'
          : 'bg-white hover:bg-slate-50 border-slate-300 hover:border-slate-400 shadow-sm'
      } ${isCrashed ? 'opacity-65 grayscale-[30%]' : ''}`}
    >
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-2.5">
          <div
            className={`p-2 rounded-xl border transition-colors ${
              isCrashed
                ? isDarkMode
                  ? 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                  : 'bg-rose-100 text-rose-800 border-rose-300'
                : isPartitioned
                ? isDarkMode
                  ? 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                  : 'bg-amber-100 text-amber-800 border-amber-300'
                : isDarkMode
                ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20'
                : 'bg-cyan-100 text-cyan-800 border-cyan-300'
            }`}
          >
            <Server className="w-4 h-4" />
          </div>
          <div>
            <div className={`text-xs font-bold tracking-tight flex items-center gap-1.5 ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
              <span>{node.name}</span>
            </div>
            <div className={`text-[10px] font-mono tabular-nums ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
              Ping: {node.latencyMs}ms · {node.chunksStored} Chunks
            </div>
          </div>
        </div>

        {/* Status Dot */}
        <span
          className={`w-2.5 h-2.5 rounded-full shadow-sm ${
            isCrashed
              ? 'bg-rose-500 shadow-rose-500/50'
              : isPartitioned
              ? 'bg-amber-500 shadow-amber-500/50 animate-pulse'
              : 'bg-emerald-500 shadow-emerald-500/50'
          }`}
          title={`Status: ${node.status}`}
        />
      </div>

      {/* Disk Usage Gauge */}
      <div className="mt-3.5 space-y-1">
        <div className={`flex justify-between text-[10px] font-mono tabular-nums ${isDarkMode ? 'text-slate-400' : 'text-slate-600 font-medium'}`}>
          <span>NVMe Storage</span>
          <span>
            {node.diskUsedMB} MB ({usagePercent}%)
          </span>
        </div>
        <div className={`w-full h-1.5 rounded-full overflow-hidden ${isDarkMode ? 'bg-slate-800' : 'bg-slate-200'}`}>
          <div
            className={`h-full transition-all duration-300 ${
              isCrashed
                ? 'bg-rose-500'
                : usagePercent > 80
                ? 'bg-amber-500'
                : 'bg-gradient-to-r from-cyan-500 to-blue-600'
            }`}
            style={{ width: `${Math.max(4, usagePercent)}%` }}
          />
        </div>
      </div>

      {/* Quick Action Overlay on Hover */}
      <div className={`mt-3 pt-2.5 border-t flex items-center justify-between text-[11px] ${isDarkMode ? 'border-slate-800/40' : 'border-slate-200'}`}>
        <span className={`text-[10px] font-mono ${isDarkMode ? 'text-slate-500' : 'text-slate-600 font-medium'}`}>{node.id}</span>
        {isCrashed ? (
          <button
            onClick={e => {
              e.stopPropagation();
              onRevive();
            }}
            className={`text-[10px] font-semibold hover:underline cursor-pointer ${isDarkMode ? 'text-emerald-400' : 'text-emerald-700'}`}
          >
            Revive
          </button>
        ) : (
          <button
            onClick={e => {
              e.stopPropagation();
              onCrash();
            }}
            className={`text-[10px] font-semibold hover:underline cursor-pointer ${isDarkMode ? 'text-rose-400' : 'text-rose-700'}`}
          >
            Inject Crash
          </button>
        )}
      </div>
    </div>
  );
}
