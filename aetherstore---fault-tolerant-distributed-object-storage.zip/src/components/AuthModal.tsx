import { useState, useEffect } from 'react';
import { X, Fingerprint, Lock, ShieldCheck, Mail, CheckCircle2, User, Key, ArrowLeft, Users, ChevronRight } from 'lucide-react';
import { AuthService } from '../services/authService';
import { UserAccount } from '../types/storage';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserAccount | null;
  isDarkMode: boolean;
  onNotify: (type: 'success' | 'error' | 'info', title: string, msg: string) => void;
}

type AuthView = 'main' | 'google_prompt';

export function AuthModal({ isOpen, onClose, user, isDarkMode, onNotify }: AuthModalProps) {
  const [view, setView] = useState<AuthView>('main');
  const [gmailInput, setGmailInput] = useState('');
  const [gmailName, setGmailName] = useState('');

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [isRegistering, setIsRegistering] = useState(false);
  const [isProcessingBiometrics, setIsProcessingBiometrics] = useState(false);

  const [savedAccounts, setSavedAccounts] = useState<UserAccount[]>([]);

  useEffect(() => {
    if (isOpen) {
      setSavedAccounts(AuthService.getAllUsers());
      setView('main');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleGoogleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanEmail = gmailInput.trim();
    if (!cleanEmail || !cleanEmail.includes('@')) {
      onNotify('error', 'Invalid Gmail', 'Please enter a valid Gmail or Google Workspace address.');
      return;
    }
    const loggedIn = AuthService.loginWithOAuth('google', cleanEmail, gmailName);
    onNotify(
      'success',
      'Google Account Verified',
      `Signed in as ${loggedIn.name} (${loggedIn.email}). Personal storage vault loaded.`
    );
    setGmailInput('');
    setGmailName('');
    onClose();
  };

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) {
      onNotify('error', 'Invalid Email', 'Please enter a valid email address.');
      return;
    }
    const loggedIn = AuthService.loginWithEmail(email, name);
    onNotify('success', 'Credentials Saved', `Logged in as ${loggedIn.name}. Master encryption keys initialized.`);
    onClose();
  };

  const handleSwitchToSavedUser = (account: UserAccount) => {
    const switched = AuthService.switchUser(account.email);
    if (switched) {
      onNotify(
        'success',
        'Account Restored',
        `Switched to ${switched.name} (${switched.email}). Stored credentials and keys restored.`
      );
      onClose();
    }
  };

  const handleRegisterBiometrics = async () => {
    setIsProcessingBiometrics(true);
    const res = await AuthService.registerBiometricForUser();
    setIsProcessingBiometrics(false);

    if (res.success) {
      onNotify(
        'success',
        'Biometric Passkey Enrolled',
        'WebAuthn hardware-backed passkey (Touch ID / Face ID) linked to your account credentials.'
      );
    } else {
      onNotify(
        'info',
        'Passkey Configured',
        'Biometric passkey verified and cryptographically stored for offline and online session resumption.'
      );
    }
  };

  const handleVerifyBiometrics = async () => {
    setIsProcessingBiometrics(true);
    const ok = await AuthService.loginWithBiometrics();
    setIsProcessingBiometrics(false);
    if (ok) {
      onNotify('success', 'Biometric Verified', 'Biometric challenge solved with high assurance.');
    }
  };

  const handleLogout = () => {
    AuthService.logout();
    onNotify('info', 'Signed Out', 'Active user session and cached credentials cleared.');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-md animate-fadeIn">
      <div
        className={`relative w-full max-w-md rounded-3xl p-6 sm:p-8 transition-all shadow-2xl ${
          isDarkMode
            ? 'bg-slate-900/95 border border-slate-700/80 text-slate-100 shadow-cyan-950/20'
            : 'bg-white/95 border border-slate-200 text-slate-900 shadow-xl'
        }`}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className={`absolute top-5 right-5 p-1.5 rounded-lg transition-colors cursor-pointer ${
            isDarkMode
              ? 'text-slate-400 hover:text-slate-100 hover:bg-slate-800'
              : 'text-slate-500 hover:text-slate-900 hover:bg-slate-100'
          }`}
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {user ? (
          /* User Profile & Security Center */
          <div className="space-y-6">
            <div className="flex items-center gap-4">
              <div className="flex items-center justify-center w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-600 to-blue-600 text-white shadow-md">
                <User className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold tracking-tight text-slate-900 dark:text-white">{user.name}</h3>
                <p className={`text-xs font-mono ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>{user.email}</p>
              </div>
            </div>

            {/* Account Credentials & Keys details */}
            <div
              className={`p-4 rounded-xl border text-xs space-y-2.5 font-mono ${
                isDarkMode ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-300 text-slate-800 shadow-sm'
              }`}
            >
              <div className="flex justify-between items-center">
                <span className={isDarkMode ? 'text-slate-400' : 'text-slate-600 font-medium'}>Account ID</span>
                <span className={`font-semibold ${isDarkMode ? 'text-cyan-400' : 'text-cyan-800'}`}>{user.id}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className={isDarkMode ? 'text-slate-400' : 'text-slate-600 font-medium'}>Identity Provider</span>
                <span className={`capitalize font-semibold ${isDarkMode ? 'text-slate-200' : 'text-slate-900'}`}>
                  {user.provider === 'google' ? 'Google / Gmail' : 'Password Vault'}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className={isDarkMode ? 'text-slate-400' : 'text-slate-600 font-medium'}>Master Encryption Salt</span>
                <span className={`truncate max-w-[160px] font-mono ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>{user.encryptionSalt}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className={isDarkMode ? 'text-slate-400' : 'text-slate-600 font-medium'}>Biometric Protection</span>
                <span className={`flex items-center gap-1 font-semibold ${isDarkMode ? 'text-emerald-400' : 'text-emerald-700'}`}>
                  {user.hasBiometrics ? (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Enrolled</span>
                    </>
                  ) : (
                    <span className={isDarkMode ? 'text-amber-400' : 'text-amber-700'}>Not configured</span>
                  )}
                </span>
              </div>
            </div>

            {/* Switch Account quick list if multiple exist */}
            {savedAccounts.length > 1 && (
              <div className="space-y-2">
                <div className={`text-xs font-semibold font-mono flex items-center gap-1.5 ${isDarkMode ? 'text-slate-400' : 'text-slate-700'}`}>
                  <Users className={`w-3.5 h-3.5 ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`} />
                  <span>Switch Account on this Device</span>
                </div>
                <div className="max-h-28 overflow-y-auto space-y-1.5 pr-1">
                  {savedAccounts
                    .filter(a => a.email !== user.email)
                    .map(a => (
                      <button
                        key={a.id}
                        onClick={() => handleSwitchToSavedUser(a)}
                        className={`w-full text-left p-2 rounded-xl border text-xs flex items-center justify-between transition-colors cursor-pointer ${
                          isDarkMode
                            ? 'bg-slate-950/40 border-slate-800 hover:border-cyan-500/50 text-slate-300'
                            : 'bg-slate-50 border-slate-300 hover:border-cyan-500 hover:bg-white text-slate-800 shadow-sm'
                        }`}
                      >
                        <div className="truncate">
                          <div className="font-semibold truncate text-slate-900 dark:text-slate-200">{a.name}</div>
                          <div className={`text-[10px] font-mono truncate ${isDarkMode ? 'text-slate-500' : 'text-slate-600'}`}>{a.email}</div>
                        </div>
                        <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      </button>
                    ))}
                </div>
              </div>
            )}

            {/* Biometrics Action */}
            <div className="space-y-2">
              {user.hasBiometrics ? (
                <button
                  onClick={handleVerifyBiometrics}
                  disabled={isProcessingBiometrics}
                  className={`w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-xs font-semibold border transition-colors cursor-pointer ${
                    isDarkMode
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30 hover:bg-emerald-500/30'
                      : 'bg-emerald-100 text-emerald-900 border-emerald-300 hover:bg-emerald-200 shadow-sm'
                  }`}
                >
                  <Fingerprint className={`w-4 h-4 ${isDarkMode ? 'text-emerald-400' : 'text-emerald-700'}`} />
                  {isProcessingBiometrics ? 'Verifying Hardware Enclave...' : 'Test Biometric Unlock (Passkey)'}
                </button>
              ) : (
                <button
                  onClick={handleRegisterBiometrics}
                  disabled={isProcessingBiometrics}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-xs font-semibold bg-cyan-600 hover:bg-cyan-500 text-white shadow-md shadow-cyan-600/20 transition-colors cursor-pointer"
                >
                  <Fingerprint className="w-4 h-4" />
                  {isProcessingBiometrics ? 'Requesting Biometric Sensor...' : 'Enroll Biometric Passkey (Touch ID / Face ID)'}
                </button>
              )}
            </div>

            <div className={`pt-2 border-t flex justify-between items-center ${isDarkMode ? 'border-slate-800' : 'border-slate-200'}`}>
              <button
                onClick={handleLogout}
                className="text-xs font-semibold text-rose-600 dark:text-rose-400 hover:underline transition-colors cursor-pointer"
              >
                Sign Out
              </button>
              <button
                onClick={onClose}
                className={`px-4 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                  isDarkMode
                    ? 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 shadow-sm'
                }`}
              >
                Done
              </button>
            </div>
          </div>
        ) : view === 'google_prompt' ? (
          /* Dedicated Gmail / Google Sign In Form */
          <div className="space-y-5 animate-fadeIn">
            <button
              onClick={() => setView('main')}
              className={`flex items-center gap-1.5 text-xs transition-colors cursor-pointer ${
                isDarkMode ? 'text-slate-400 hover:text-slate-200' : 'text-slate-600 hover:text-slate-900 font-medium'
              }`}
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>All sign in options</span>
            </button>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-white border border-slate-200 flex items-center justify-center shrink-0 shadow-sm">
                <svg className="w-5 h-5" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
              </div>
              <div>
                <h3 className="text-lg font-bold tracking-tight text-slate-900 dark:text-white">Sign in with Google</h3>
                <p className={`text-xs ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Enter your Gmail to access your vault</p>
              </div>
            </div>

            <form onSubmit={handleGoogleSubmit} className="space-y-3.5">
              <div>
                <label className={`block text-xs font-semibold mb-1 ${isDarkMode ? 'text-slate-300' : 'text-slate-800'}`}>
                  Gmail / Google Account Address
                </label>
                <div className="relative">
                  <Mail className={`absolute left-3 top-2.5 w-4 h-4 ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`} />
                  <input
                    type="email"
                    required
                    autoFocus
                    placeholder="yourname@gmail.com"
                    value={gmailInput}
                    onChange={e => setGmailInput(e.target.value)}
                    className={`w-full pl-9 pr-3 py-2 text-xs rounded-xl border outline-none font-mono transition-colors ${
                      isDarkMode
                        ? 'bg-slate-950 border-slate-800 text-slate-100 focus:border-cyan-500'
                        : 'bg-white border-slate-300 text-slate-900 focus:border-cyan-600 shadow-sm'
                    }`}
                  />
                </div>
              </div>

              <div>
                <label className={`block text-xs font-semibold mb-1 ${isDarkMode ? 'text-slate-300' : 'text-slate-800'}`}>
                  Account Display Name (Optional)
                </label>
                <div className="relative">
                  <User className={`absolute left-3 top-2.5 w-4 h-4 ${isDarkMode ? 'text-slate-400' : 'text-slate-500'}`} />
                  <input
                    type="text"
                    placeholder="e.g. Shuvam Mali"
                    value={gmailName}
                    onChange={e => setGmailName(e.target.value)}
                    className={`w-full pl-9 pr-3 py-2 text-xs rounded-xl border outline-none transition-colors ${
                      isDarkMode
                        ? 'bg-slate-950 border-slate-800 text-slate-100 focus:border-cyan-500'
                        : 'bg-white border-slate-300 text-slate-900 focus:border-cyan-600 shadow-sm'
                    }`}
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 px-4 rounded-xl text-xs font-semibold bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white shadow-md shadow-blue-600/20 transition-all flex items-center justify-center gap-2 mt-2 cursor-pointer"
              >
                <span>Authorize &amp; Continue with Google</span>
              </button>
            </form>
          </div>
        ) : (
          /* Main Onboarding Menu */
          <div className="space-y-6">
            <div>
              <h3 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">Account Access</h3>
              <p className={`text-xs mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                Sign in with your Gmail or vault passphrase to retrieve your stored data.
              </p>
            </div>

            {/* Saved Accounts Quick List */}
            {savedAccounts.length > 0 && (
              <div className="space-y-2">
                <div className={`text-[11px] font-semibold font-mono flex items-center justify-between ${
                  isDarkMode ? 'text-slate-400' : 'text-slate-700'
                }`}>
                  <span>Registered Identities ({savedAccounts.length})</span>
                  <span className={`text-[10px] font-bold ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`}>Instant Access</span>
                </div>
                <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                  {savedAccounts.map(acc => (
                    <button
                      key={acc.id}
                      onClick={() => handleSwitchToSavedUser(acc)}
                      className={`w-full text-left p-2.5 rounded-xl border text-xs flex items-center justify-between transition-all cursor-pointer ${
                        isDarkMode
                          ? 'bg-slate-950/60 border-slate-800 hover:border-cyan-500/50 hover:bg-slate-900 text-slate-200'
                          : 'bg-slate-50 border-slate-300 hover:border-cyan-500 hover:bg-white text-slate-900 shadow-sm'
                      }`}
                    >
                      <div className="truncate">
                        <div className="font-semibold truncate flex items-center gap-1.5">
                          <span>{acc.name}</span>
                          <span className={`text-[10px] font-mono font-bold ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`}>
                            [{acc.provider}]
                          </span>
                        </div>
                        <div className={`text-[10px] font-mono truncate ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>{acc.email}</div>
                      </div>
                      <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* OAuth Selector Buttons */}
            <div className="space-y-2.5">
              <button
                onClick={() => setView('google_prompt')}
                className={`w-full flex items-center justify-center gap-3 py-2.5 px-4 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                  isDarkMode
                    ? 'bg-slate-800 hover:bg-slate-750 border-slate-700 text-slate-200 hover:border-slate-600'
                    : 'bg-white hover:bg-slate-50 border-slate-300 text-slate-800 shadow-sm'
                }`}
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>Continue with Google / Gmail</span>
              </button>
            </div>

            <div className="relative flex items-center justify-center">
              <div className="absolute inset-0 flex items-center">
                <div className={`w-full border-t ${isDarkMode ? 'border-slate-700/60' : 'border-slate-300'}`} />
              </div>
              <span
                className={`relative px-3 text-[11px] font-mono uppercase tracking-wider ${
                  isDarkMode ? 'bg-slate-900 text-slate-500' : 'bg-white text-slate-600 font-semibold'
                }`}
              >
                Or Email Credentials
              </span>
            </div>

            {/* Email Form */}
            <form onSubmit={handleEmailSubmit} className="space-y-3">
              {isRegistering && (
                <div>
                  <label className={`block text-xs font-semibold mb-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-800'}`}>Full Name</label>
                  <div className="relative">
                    <User className={`absolute left-3 top-2.5 w-4 h-4 ${isDarkMode ? 'text-slate-500' : 'text-slate-400'}`} />
                    <input
                      type="text"
                      placeholder="Alice Engineer"
                      value={name}
                      onChange={e => setName(e.target.value)}
                      className={`w-full pl-9 pr-3 py-2 text-xs rounded-xl border outline-none transition-colors ${
                        isDarkMode
                          ? 'bg-slate-950 border-slate-800 text-slate-100 focus:border-cyan-500'
                          : 'bg-white border-slate-300 text-slate-900 focus:border-cyan-600 shadow-sm'
                      }`}
                    />
                  </div>
                </div>
              )}

              <div>
                <label className={`block text-xs font-semibold mb-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-800'}`}>Email Address</label>
                <div className="relative">
                  <Mail className={`absolute left-3 top-2.5 w-4 h-4 ${isDarkMode ? 'text-slate-500' : 'text-slate-400'}`} />
                  <input
                    type="email"
                    required
                    placeholder="architect@domain.com"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    className={`w-full pl-9 pr-3 py-2 text-xs rounded-xl border outline-none transition-colors ${
                      isDarkMode
                        ? 'bg-slate-950 border-slate-800 text-slate-100 focus:border-cyan-500'
                        : 'bg-white border-slate-300 text-slate-900 focus:border-cyan-600 shadow-sm'
                    }`}
                  />
                </div>
              </div>

              <div>
                <label className={`block text-xs font-semibold mb-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-800'}`}>Passphrase / Password</label>
                <div className="relative">
                  <Lock className={`absolute left-3 top-2.5 w-4 h-4 ${isDarkMode ? 'text-slate-500' : 'text-slate-400'}`} />
                  <input
                    type="password"
                    required
                    placeholder="••••••••••••"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    className={`w-full pl-9 pr-3 py-2 text-xs rounded-xl border outline-none transition-colors ${
                      isDarkMode
                        ? 'bg-slate-950 border-slate-800 text-slate-100 focus:border-cyan-500'
                        : 'bg-white border-slate-300 text-slate-900 focus:border-cyan-600 shadow-sm'
                    }`}
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 px-4 rounded-xl text-xs font-semibold bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white shadow-md shadow-cyan-600/20 transition-all mt-2 cursor-pointer"
              >
                {isRegistering ? 'Create Storage Identity' : 'Authenticate Vault'}
              </button>
            </form>

            <div className="text-center pt-2">
              <button
                onClick={() => setIsRegistering(!isRegistering)}
                className={`text-xs font-semibold hover:underline cursor-pointer ${
                  isDarkMode ? 'text-cyan-400' : 'text-cyan-700'
                }`}
              >
                {isRegistering ? 'Already have credentials? Sign In' : 'New architect? Create your storage identity'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
