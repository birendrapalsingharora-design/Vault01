import { useState, useMemo } from 'react';
import {
  FileText,
  Search,
  Filter,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  AlertOctagon,
  Sparkles,
  Wrench,
  Download,
  Trash2,
  RefreshCw,
  Hash,
  Server,
  Layers,
  Info,
  Clock,
  ExternalLink,
} from 'lucide-react';
import { ClusterEvent, StorageNode, StorageObject, RepairJob } from '../types/storage';
import { StorageEngine } from '../services/storageEngine';

interface AuditLogsProps {
  events: ClusterEvent[];
  repairJobs: RepairJob[];
  nodes: StorageNode[];
  objects: StorageObject[];
  isDarkMode: boolean;
  onNotify: (type: 'success' | 'warning' | 'error' | 'info', title: string, msg: string) => void;
}

export function AuditLogs({ events, repairJobs, nodes, objects, isDarkMode, onNotify }: AuditLogsProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedSeverity, setSelectedSeverity] = useState<string>('all');
  const [selectedNode, setSelectedNode] = useState<string>('all');
  const [isAuditing, setIsAuditing] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<ClusterEvent | null>(null);

  // Filtered event history
  const filteredEvents = useMemo(() => {
    return events.filter(evt => {
      // Search match
      const query = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !query ||
        evt.title.toLowerCase().includes(query) ||
        evt.message.toLowerCase().includes(query) ||
        (evt.nodeId && evt.nodeId.toLowerCase().includes(query)) ||
        (evt.objectId && evt.objectId.toLowerCase().includes(query)) ||
        (evt.hashExpected && evt.hashExpected.toLowerCase().includes(query)) ||
        (evt.hashActual && evt.hashActual.toLowerCase().includes(query));

      // Action type match
      const matchesType =
        selectedType === 'all' ||
        evt.actionType === selectedType ||
        (selectedType === 'hash_verification' && (evt.title.toLowerCase().includes('hash') || evt.title.toLowerCase().includes('checksum'))) ||
        (selectedType === 'replica_repair' && (evt.title.toLowerCase().includes('repair') || evt.type === 'healing')) ||
        (selectedType === 'bit_rot_detection' && (evt.title.toLowerCase().includes('rot') || evt.title.toLowerCase().includes('corrupt')));

      // Severity match
      const matchesSeverity =
        selectedSeverity === 'all' ||
        (selectedSeverity === 'success' && (evt.type === 'success' || evt.type === 'healing')) ||
        (selectedSeverity === 'warning' && evt.type === 'warning') ||
        (selectedSeverity === 'error' && evt.type === 'error');

      // Node match
      const matchesNode = selectedNode === 'all' || evt.nodeId === selectedNode;

      return matchesSearch && matchesType && matchesSeverity && matchesNode;
    });
  }, [events, searchQuery, selectedType, selectedSeverity, selectedNode]);

  // Aggregate metrics
  const verifiedCount = events.filter(e => e.actionType === 'hash_verification' || e.title.includes('Checksum') || e.title.includes('Hash')).length;
  const repairCount = events.filter(e => e.type === 'healing' || e.actionType === 'replica_repair' || e.title.includes('Repair')).length;
  const bitRotCount = events.filter(e => e.actionType === 'bit_rot_detection' || e.title.includes('Rot') || e.title.includes('Corrupt')).length;

  const handleAuditAll = async () => {
    setIsAuditing(true);
    const res = await StorageEngine.auditAllHashes();
    setIsAuditing(false);
    onNotify(
      'success',
      'Merkle Hash Audit Complete',
      `Audited all resident object shards. Verified ${res.verified} checksums (${res.corrupted} bit rot anomalies detected).`
    );
  };

  const handleExportJSON = () => {
    const exportPayload = {
      system: 'AetherStore Distributed Object Storage Engine',
      ledgerType: 'Cryptographic Hash & Cluster Event Audit Trail',
      exportedAt: new Date().toISOString(),
      clusterStatus: 'Operational',
      totalRecordedEvents: events.length,
      exportedEventsCount: filteredEvents.length,
      activeFilter: {
        searchQuery: searchQuery || null,
        actionType: selectedType,
        severity: selectedSeverity,
        node: selectedNode,
      },
      clusterSummary: {
        totalNodes: nodes.length,
        objectsStored: objects.length,
        reconciliationJobs: repairJobs.length,
      },
      events: filteredEvents,
    };

    const jsonString = JSON.stringify(exportPayload, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    a.download = `aetherstore_audit_log_${timestamp}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    onNotify('success', 'Audit Logs Downloaded', `Successfully exported ${filteredEvents.length} formatted log events as a JSON file.`);
  };

  const handleClearLogs = () => {
    localStorage.removeItem('aetherstore_events_v1');
    StorageEngine.logEvent('info', 'Audit Log Reset', 'Audit history cleared by storage operator.');
    onNotify('info', 'Audit Trail Cleared', 'Historical event buffers purged.');
  };

  return (
    <div className="space-y-6">
      {/* Hero Header */}
      <div
        className={`rounded-3xl p-6 sm:p-8 transition-colors ${
          isDarkMode ? 'liquid-glass-dark' : 'liquid-glass-light'
        }`}
      >
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className={`flex items-center gap-2 text-xs font-mono font-bold ${isDarkMode ? 'text-cyan-400' : 'text-cyan-800'}`}>
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Immutable Ledger &amp; Integrity Verification Trail</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white">Audit Logs &amp; Repair Operations</h2>
            <p className={`text-xs sm:text-sm max-w-2xl ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
              Chronological log of all SHA-256 block hash audits, anti-entropy read repairs, background scrubbing,
              and quorum consensus events across cluster nodes.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={handleAuditAll}
              disabled={isAuditing}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white shadow-lg shadow-cyan-600/20 transition-all cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${isAuditing ? 'animate-spin' : ''}`} />
              <span>{isAuditing ? 'Auditing Digests...' : 'Audit All Hashes'}</span>
            </button>

            {/* Download JSON Log Button */}
            <button
              onClick={handleExportJSON}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-600/20 transition-all cursor-pointer"
              title="Download current log history as a formatted JSON file"
            >
              <Download className="w-4 h-4" />
              <span>Download JSON Log</span>
            </button>

            <button
              onClick={handleClearLogs}
              className={`p-2.5 rounded-xl border transition-colors cursor-pointer ${
                isDarkMode
                  ? 'text-slate-400 hover:text-rose-400 border-slate-800 hover:bg-slate-800'
                  : 'text-slate-600 hover:text-rose-600 border-slate-300 hover:bg-slate-100 shadow-sm'
              }`}
              title="Clear Event History"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Metrics Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 font-mono">
        <div
          className={`p-4 sm:p-5 rounded-2xl border transition-all ${
            isDarkMode ? 'liquid-glass-dark border-slate-800' : 'liquid-glass-light border-slate-300 shadow-sm'
          }`}
        >
          <div className={`text-xs font-bold ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Total Audit Events</div>
          <div className={`mt-2 text-2xl sm:text-3xl font-bold tabular-nums ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`}>
            {events.length}
          </div>
          <div className={`mt-1 text-[11px] ${isDarkMode ? 'text-slate-500' : 'text-slate-600 font-medium'}`}>Live ledger entries</div>
        </div>

        <div
          className={`p-4 sm:p-5 rounded-2xl border transition-all ${
            isDarkMode ? 'liquid-glass-dark border-slate-800' : 'liquid-glass-light border-slate-300 shadow-sm'
          }`}
        >
          <div className={`text-xs font-bold ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Hash Checksums Verified</div>
          <div className={`mt-2 text-2xl sm:text-3xl font-bold tabular-nums ${isDarkMode ? 'text-emerald-400' : 'text-emerald-700'}`}>
            {verifiedCount}
          </div>
          <div className={`mt-1 text-[11px] ${isDarkMode ? 'text-slate-500' : 'text-slate-600 font-medium'}`}>SHA-256 block matches</div>
        </div>

        <div
          className={`p-4 sm:p-5 rounded-2xl border transition-all ${
            isDarkMode ? 'liquid-glass-dark border-slate-800' : 'liquid-glass-light border-slate-300 shadow-sm'
          }`}
        >
          <div className={`text-xs font-bold ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Auto-Healed Repairs</div>
          <div className={`mt-2 text-2xl sm:text-3xl font-bold tabular-nums ${isDarkMode ? 'text-blue-400' : 'text-blue-700'}`}>
            {repairCount}
          </div>
          <div className={`mt-1 text-[11px] ${isDarkMode ? 'text-slate-500' : 'text-slate-600 font-medium'}`}>Anti-entropy recovered</div>
        </div>

        <div
          className={`p-4 sm:p-5 rounded-2xl border transition-all ${
            isDarkMode ? 'liquid-glass-dark border-slate-800' : 'liquid-glass-light border-slate-300 shadow-sm'
          }`}
        >
          <div className={`text-xs font-bold ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Bit Rot Anomalies</div>
          <div className={`mt-2 text-2xl sm:text-3xl font-bold tabular-nums ${isDarkMode ? 'text-amber-400' : 'text-amber-700'}`}>
            {bitRotCount}
          </div>
          <div className={`mt-1 text-[11px] ${isDarkMode ? 'text-slate-500' : 'text-slate-600 font-medium'}`}>Flagged &amp; quarantined</div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div
        className={`rounded-3xl p-5 sm:p-6 transition-colors ${
          isDarkMode ? 'liquid-glass-dark' : 'liquid-glass-light'
        }`}
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Search Input */}
          <div className="relative">
            <Search className={`absolute left-3 top-2.5 w-4 h-4 ${isDarkMode ? 'text-slate-500' : 'text-slate-400'}`} />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search title, hash, object, node..."
              className={`w-full pl-9 pr-3 py-2 text-xs rounded-xl border outline-none font-mono ${
                isDarkMode ? 'bg-slate-900 border-slate-700 text-slate-100 placeholder:text-slate-500' : 'bg-white border-slate-300 text-slate-900 placeholder:text-slate-400 shadow-sm'
              }`}
            />
          </div>

          {/* Action Type Filter */}
          <select
            value={selectedType}
            onChange={e => setSelectedType(e.target.value)}
            className={`w-full p-2 text-xs rounded-xl border outline-none font-mono ${
              isDarkMode ? 'bg-slate-900 border-slate-700 text-slate-100' : 'bg-white border-slate-300 text-slate-900 shadow-sm'
            }`}
          >
            <option value="all">All Action Types</option>
            <option value="hash_verification">SHA-256 Hash Verification</option>
            <option value="replica_repair">Replica Repair (Anti-Entropy)</option>
            <option value="bit_rot_detection">Bit Rot &amp; Checksum Mismatch</option>
            <option value="quorum_consensus">Quorum Consensus</option>
            <option value="scrub">Merkle Scrubbing</option>
          </select>

          {/* Severity Filter */}
          <select
            value={selectedSeverity}
            onChange={e => setSelectedSeverity(e.target.value)}
            className={`w-full p-2 text-xs rounded-xl border outline-none font-mono ${
              isDarkMode ? 'bg-slate-900 border-slate-700 text-slate-100' : 'bg-white border-slate-300 text-slate-900 shadow-sm'
            }`}
          >
            <option value="all">All Severities</option>
            <option value="success">Success &amp; Healed</option>
            <option value="warning">Warnings</option>
            <option value="error">Errors &amp; Outages</option>
          </select>

          {/* Storage Node Filter */}
          <select
            value={selectedNode}
            onChange={e => setSelectedNode(e.target.value)}
            className={`w-full p-2 text-xs rounded-xl border outline-none font-mono ${
              isDarkMode ? 'bg-slate-900 border-slate-700 text-slate-100' : 'bg-white border-slate-300 text-slate-900 shadow-sm'
            }`}
          >
            <option value="all">All Nodes (8 Nodes)</option>
            {nodes.map(n => (
              <option key={n.id} value={n.id}>
                {n.name} ({n.rack})
              </option>
            ))}
          </select>
        </div>

        {/* Event List Header Toolbar */}
        <div className={`mt-5 flex items-center justify-between pb-3 border-b text-xs font-mono ${
          isDarkMode ? 'border-slate-800/60' : 'border-slate-200'
        }`}>
          <div className="flex items-center gap-2">
            <span className={`font-semibold ${isDarkMode ? 'text-slate-200' : 'text-slate-900'}`}>Audit Ledger Stream</span>
            <span className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>({filteredEvents.length} {filteredEvents.length === 1 ? 'record' : 'records'})</span>
          </div>

          <button
            onClick={handleExportJSON}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all cursor-pointer shadow-sm ${
              isDarkMode
                ? 'bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border-emerald-500/30'
                : 'bg-emerald-100 hover:bg-emerald-200 text-emerald-800 border-emerald-300'
            }`}
            title="Download current log history as formatted JSON"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download JSON</span>
          </button>
        </div>

        {/* Scrollable Event List */}
        <div className="mt-4 space-y-2.5 max-h-[550px] overflow-y-auto pr-1">
          {filteredEvents.length === 0 ? (
            <div className={`py-14 text-center text-xs font-mono ${isDarkMode ? 'text-slate-500' : 'text-slate-600'}`}>
              No audit log entries found matching the filter criteria.
            </div>
          ) : (
            filteredEvents.map(evt => {
              const dateStr = new Date(evt.timestamp).toLocaleString();
              const isHealing = evt.type === 'healing';
              const isError = evt.type === 'error';
              const isWarning = evt.type === 'warning';
              const isSuccess = evt.type === 'success';

              return (
                <div
                  key={evt.id}
                  onClick={() => setSelectedEvent(evt)}
                  className={`p-3.5 sm:p-4 rounded-2xl border text-xs font-mono transition-all cursor-pointer ${
                    isHealing
                      ? isDarkMode
                        ? 'bg-emerald-950/20 border-emerald-800/70 hover:bg-emerald-950/30'
                        : 'bg-emerald-50 border-emerald-300 hover:bg-emerald-100/60 shadow-sm'
                      : isError
                      ? isDarkMode
                        ? 'bg-rose-950/20 border-rose-800/70 hover:bg-rose-950/30'
                        : 'bg-rose-50 border-rose-300 hover:bg-rose-100/60 shadow-sm'
                      : isWarning
                      ? isDarkMode
                        ? 'bg-amber-950/20 border-amber-800/70 hover:bg-amber-950/30'
                        : 'bg-amber-50 border-amber-300 hover:bg-amber-100/60 shadow-sm'
                      : isDarkMode
                      ? 'bg-slate-950/60 border-slate-800/80 hover:bg-slate-900/60'
                      : 'bg-white border-slate-300 hover:bg-slate-50 shadow-sm'
                  }`}
                >
                  <div className={`flex flex-col sm:flex-row sm:items-center justify-between gap-1.5 pb-2 border-b ${
                    isDarkMode ? 'border-slate-800/40' : 'border-slate-200'
                  }`}>
                    <div className="flex items-center gap-2">
                      {isHealing ? (
                        <Sparkles className="w-4 h-4 text-emerald-500 dark:text-emerald-400 shrink-0" />
                      ) : isError ? (
                        <AlertOctagon className="w-4 h-4 text-rose-500 dark:text-rose-400 shrink-0" />
                      ) : isWarning ? (
                        <AlertTriangle className="w-4 h-4 text-amber-500 dark:text-amber-400 shrink-0" />
                      ) : isSuccess ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 dark:text-emerald-400 shrink-0" />
                      ) : (
                        <Info className="w-4 h-4 text-cyan-600 dark:text-cyan-400 shrink-0" />
                      )}
                      <span className={`font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>{evt.title}</span>
                    </div>

                    <div className={`flex items-center gap-2 text-[10px] tabular-nums ${isDarkMode ? 'text-slate-400' : 'text-slate-600 font-medium'}`}>
                      <Clock className="w-3 h-3 text-slate-400" />
                      <span>{dateStr}</span>
                    </div>
                  </div>

                  <p className={`mt-2 text-[11px] leading-relaxed break-words ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                    {evt.message}
                  </p>

                  {/* Hash & Node Meta tags */}
                  <div className="mt-2.5 flex flex-wrap items-center gap-2 text-[10px]">
                    {evt.nodeId && (
                      <span className={`px-2 py-0.5 rounded-md border flex items-center gap-1 font-medium ${
                        isDarkMode
                          ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20'
                          : 'bg-cyan-100 text-cyan-900 border-cyan-300'
                      }`}>
                        <Server className="w-3 h-3" />
                        <span>Node: {evt.nodeId}</span>
                      </span>
                    )}

                    {evt.objectId && (
                      <span className={`px-2 py-0.5 rounded-md border flex items-center gap-1 font-medium ${
                        isDarkMode
                          ? 'bg-blue-500/10 text-blue-400 border-blue-500/20'
                          : 'bg-blue-100 text-blue-900 border-blue-300'
                      }`}>
                        <Layers className="w-3 h-3" />
                        <span>Object: {evt.objectId}</span>
                      </span>
                    )}

                    {evt.hashExpected && (
                      <span className={`px-2 py-0.5 rounded-md border font-mono truncate max-w-[200px] ${
                        isDarkMode
                          ? 'bg-slate-800 text-slate-300 border-slate-700'
                          : 'bg-slate-100 text-slate-800 border-slate-300'
                      }`}>
                        Expected SHA: {evt.hashExpected.slice(0, 16)}...
                      </span>
                    )}

                    {evt.hashActual && (
                      <span
                        className={`px-2 py-0.5 rounded-md border font-mono truncate max-w-[200px] font-semibold ${
                          evt.hashActual === evt.hashExpected
                            ? isDarkMode
                              ? 'bg-emerald-950/40 text-emerald-300 border-emerald-800'
                              : 'bg-emerald-100 text-emerald-900 border-emerald-300'
                            : isDarkMode
                            ? 'bg-rose-950/40 text-rose-300 border-rose-800'
                            : 'bg-rose-100 text-rose-900 border-rose-300'
                        }`}
                      >
                        Actual SHA: {evt.hashActual.slice(0, 16)}...
                      </span>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Selected Event Detail Modal */}
      {selectedEvent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div
            className={`w-full max-w-lg rounded-3xl p-6 border shadow-2xl transition-all ${
              isDarkMode ? 'liquid-glass-dark border-slate-700' : 'bg-white border-slate-300 text-slate-900 shadow-2xl'
            }`}
          >
            <div className={`flex items-center justify-between pb-4 border-b ${isDarkMode ? 'border-slate-800/60' : 'border-slate-200'}`}>
              <h4 className="text-base font-bold tracking-tight flex items-center gap-2">
                <Hash className={`w-4 h-4 ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`} />
                <span className={isDarkMode ? 'text-white' : 'text-slate-900'}>Cryptographic Audit Proof</span>
              </h4>
              <button
                onClick={() => setSelectedEvent(null)}
                className={`px-3 py-1 text-xs rounded-lg transition-colors ${
                  isDarkMode
                    ? 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-300'
                }`}
              >
                Close
              </button>
            </div>

            <div className="mt-4 space-y-3 font-mono text-xs">
              <div className={`p-3 rounded-xl border space-y-1.5 ${
                isDarkMode ? 'bg-slate-950/80 border-slate-800' : 'bg-slate-50 border-slate-200 text-slate-800'
              }`}>
                <div className="flex justify-between">
                  <span className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>Event ID:</span>
                  <span className={`font-semibold ${isDarkMode ? 'text-cyan-400' : 'text-cyan-800'}`}>{selectedEvent.id}</span>
                </div>
                <div className="flex justify-between">
                  <span className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>Timestamp:</span>
                  <span className={isDarkMode ? 'text-slate-200' : 'text-slate-900'}>{new Date(selectedEvent.timestamp).toISOString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>Category:</span>
                  <span className={`capitalize font-semibold ${isDarkMode ? 'text-slate-200' : 'text-slate-900'}`}>{selectedEvent.actionType || selectedEvent.type}</span>
                </div>
                {selectedEvent.nodeId && (
                  <div className="flex justify-between">
                    <span className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>Target Node:</span>
                    <span className={`font-semibold ${isDarkMode ? 'text-cyan-300' : 'text-cyan-800'}`}>{selectedEvent.nodeId}</span>
                  </div>
                )}
              </div>

              <div className={`p-3 rounded-xl border ${
                isDarkMode ? 'bg-slate-950/80 border-slate-800' : 'bg-slate-50 border-slate-200'
              }`}>
                <div className={`mb-1 font-semibold ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Message:</div>
                <div className={`leading-relaxed ${isDarkMode ? 'text-slate-200' : 'text-slate-900'}`}>{selectedEvent.message}</div>
              </div>

              {selectedEvent.hashExpected && (
                <div className={`p-3 rounded-xl border space-y-2 ${
                  isDarkMode ? 'bg-slate-950/80 border-slate-800' : 'bg-slate-50 border-slate-200'
                }`}>
                  <div>
                    <div className={`text-[10px] font-semibold ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>EXPECTED SHA-256 DIGEST:</div>
                    <div className={`break-all select-all font-mono text-[11px] font-semibold ${
                      isDarkMode ? 'text-emerald-400' : 'text-emerald-700'
                    }`}>
                      {selectedEvent.hashExpected}
                    </div>
                  </div>
                  {selectedEvent.hashActual && (
                    <div>
                      <div className={`text-[10px] font-semibold ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>ACTUAL COMPUTED DIGEST:</div>
                      <div
                        className={`break-all select-all font-mono text-[11px] font-bold ${
                          selectedEvent.hashActual === selectedEvent.hashExpected
                            ? isDarkMode ? 'text-emerald-400' : 'text-emerald-700'
                            : isDarkMode ? 'text-rose-400' : 'text-rose-700'
                        }`}
                      >
                        {selectedEvent.hashActual}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
