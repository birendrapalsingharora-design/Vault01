import { Sun, Moon, Shield, Bell, User, KeyRound, Wrench } from 'lucide-react';
import { UserAccount } from '../types/storage';

interface NavbarProps {
  activeTab: 'cluster' | 'objects' | 'quotas' | 'chaos' | 'benchmark' | 'audit' | 'architecture';
  setActiveTab: (tab: 'cluster' | 'objects' | 'quotas' | 'chaos' | 'benchmark' | 'audit' | 'architecture') => void;
  isDarkMode: boolean;
  setIsDarkMode: (val: boolean) => void;
  user: UserAccount | null;
  onOpenAuth: () => void;
  isOnline: boolean;
  pendingSyncCount: number;
  unreadAlertCount: number;
  onOpenNotifications: () => void;
  onOpenRecoveryWizard?: () => void;
}

export function Navbar({
  activeTab,
  setActiveTab,
  isDarkMode,
  setIsDarkMode,
  user,
  onOpenAuth,
  isOnline,
  pendingSyncCount,
  unreadAlertCount,
  onOpenNotifications,
  onOpenRecoveryWizard,
}: NavbarProps) {
  const tabs = [
    { id: 'cluster', label: 'Cluster Topology' },
    { id: 'objects', label: 'Object Explorer' },
    { id: 'quotas', label: 'Storage Quotas' },
    { id: 'chaos', label: 'Chaos & Durability' },
    { id: 'benchmark', label: 'Concurrent Stress' },
    { id: 'audit', label: 'Audit Logs' },
    { id: 'architecture', label: 'Architecture & Specs' },
  ] as const;

  return (
    <header
      className={`sticky top-0 z-40 w-full transition-colors duration-200 border-b ${
        isDarkMode
          ? 'bg-slate-950/80 border-slate-800/80 text-slate-100 backdrop-blur-xl'
          : 'bg-white/80 border-slate-200 text-slate-900 backdrop-blur-xl'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Zone 1: Single text element Brand Zone */}
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-600 to-blue-600 text-white shadow-lg shadow-cyan-600/25">
            <Shield className="w-5 h-5 text-white" />
            <div className="absolute inset-0 rounded-xl bg-white/20 opacity-0 hover:opacity-100 transition-opacity" />
          </div>
          <a
            href="#home"
            onClick={e => {
              e.preventDefault();
              setActiveTab('cluster');
            }}
            className={`text-lg font-bold tracking-tight bg-gradient-to-r ${
              isDarkMode
                ? 'from-cyan-400 via-sky-300 to-blue-400'
                : 'from-cyan-800 via-blue-800 to-indigo-900'
            } bg-clip-text text-transparent hover:opacity-90 transition-opacity`}
          >
            AetherStore
          </a>
        </div>

        {/* Zone 2: Clean 4-6 text navigation links */}
        <nav className="hidden md:flex items-center gap-1 p-1 rounded-xl bg-slate-200/70 dark:bg-slate-900/60 border border-slate-300 dark:border-slate-800/80">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
                activeTab === tab.id
                  ? isDarkMode
                    ? 'bg-gradient-to-r from-cyan-500/20 to-blue-500/20 text-cyan-300 border border-cyan-500/30 shadow-sm'
                    : 'bg-white text-slate-950 font-bold shadow-sm border border-slate-300/80'
                  : isDarkMode
                  ? 'text-slate-400 hover:text-slate-200'
                  : 'text-slate-700 hover:text-slate-950 hover:bg-white/60'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </nav>

        {/* Zone 3: Primary Actions & User Status */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Recovery Wizard Quick Action */}
          {onOpenRecoveryWizard && (
            <button
              onClick={onOpenRecoveryWizard}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                isDarkMode
                  ? 'bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 shadow-sm'
                  : 'bg-cyan-50 hover:bg-cyan-100 text-cyan-900 border border-cyan-300 font-bold shadow-sm'
              }`}
              title="Launch Quorum Anti-Entropy Recovery Wizard"
            >
              <Wrench className={`w-3.5 h-3.5 ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`} />
              <span className="hidden lg:inline">Recovery Wizard</span>
            </button>
          )}

          {/* Real-time Notifications Bell */}
          <button
            onClick={onOpenNotifications}
            className={`relative p-2 rounded-xl transition-colors ${
              isDarkMode
                ? 'text-slate-300 hover:bg-slate-800 border border-slate-800'
                : 'text-slate-800 hover:bg-slate-100 border border-slate-300 shadow-sm'
            }`}
            aria-label="Toggle cluster event alerts"
          >
            <Bell className="w-4 h-4" />
            {unreadAlertCount > 0 && (
              <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-cyan-600 text-[10px] font-bold text-white shadow-sm animate-pulse">
                {unreadAlertCount > 9 ? '9+' : unreadAlertCount}
              </span>
            )}
          </button>

          {/* Dark / Light Toggle */}
          <button
            onClick={() => setIsDarkMode(!isDarkMode)}
            className={`p-2 rounded-xl transition-colors ${
              isDarkMode
                ? 'text-slate-300 hover:bg-slate-800 border border-slate-800'
                : 'text-slate-800 hover:bg-slate-100 border border-slate-300 shadow-sm'
            }`}
            aria-label="Toggle Theme"
          >
            {isDarkMode ? <Sun className="w-4 h-4 text-amber-300" /> : <Moon className="w-4 h-4 text-slate-800" />}
          </button>

          {/* User Account & Biometric Status */}
          <button
            onClick={onOpenAuth}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              isDarkMode
                ? 'bg-slate-900 border border-slate-800 text-slate-200 hover:border-cyan-500/40'
                : 'bg-slate-100 border border-slate-300 text-slate-900 hover:bg-slate-200 shadow-sm'
            }`}
          >
            {user?.hasBiometrics ? (
              <KeyRound className={`w-3.5 h-3.5 ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`} />
            ) : (
              <User className={`w-3.5 h-3.5 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`} />
            )}
            <span className="hidden sm:inline max-w-[110px] truncate font-medium">
              {user ? user.name.split(' ')[0] : 'Sign In'}
            </span>
          </button>
        </div>
      </div>

      {/* Mobile navigation tab row */}
      <div className="flex md:hidden overflow-x-auto px-4 py-2 gap-1 border-t border-slate-200 dark:border-slate-800/60 bg-slate-100/50 dark:bg-slate-950/40">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-3 py-1 text-xs font-semibold rounded-lg whitespace-nowrap shrink-0 transition-colors ${
              activeTab === tab.id
                ? isDarkMode
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                  : 'bg-slate-900 text-white font-bold'
                : isDarkMode
                ? 'text-slate-400'
                : 'text-slate-700 hover:text-slate-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>
    </header>
  );
}
