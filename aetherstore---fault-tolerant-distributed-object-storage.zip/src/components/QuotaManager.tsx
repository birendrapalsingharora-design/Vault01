import { useState, useMemo, useEffect } from 'react';
import {
  HardDrive,
  Users,
  ShieldAlert,
  AlertTriangle,
  CheckCircle2,
  Sliders,
  Plus,
  Edit2,
  Trash2,
  RefreshCw,
  Search,
  Filter,
  ArrowRight,
  Shield,
  Zap,
  Lock,
  Unlock,
  UserCheck,
  TrendingUp,
  Download,
  RotateCcw,
  Sparkles,
} from 'lucide-react';
import { StorageObject, UserAccount, UserQuotaConfig, UserQuotaUsage, QuotaTier, QuotaEnforcementMode } from '../types/storage';
import { QuotaService, QUOTA_TIER_PRESETS } from '../services/quotaService';
import { AuthService } from '../services/authService';

interface QuotaManagerProps {
  objects: StorageObject[];
  currentUser: UserAccount | null;
  isDarkMode: boolean;
  onNotify: (type: 'success' | 'warning' | 'error' | 'info', title: string, msg: string) => void;
}

export function QuotaManager({ objects, currentUser, isDarkMode, onNotify }: QuotaManagerProps) {
  const [quotas, setQuotas] = useState<UserQuotaConfig[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [tierFilter, setTierFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'healthy' | 'warning' | 'exceeded'>('all');
  const [enforcementFilter, setEnforcementFilter] = useState<string>('all');

  // Modal State for Edit / Add
  const [editingConfig, setEditingConfig] = useState<UserQuotaConfig | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    userEmail: '',
    userName: '',
    role: 'user' as 'admin' | 'user',
    storageQuotaMB: 150,
    maxObjectsQuota: 30,
    tier: 'Developer' as QuotaTier,
    enforcementMode: 'hard' as QuotaEnforcementMode,
    warningThresholdPercent: 80,
  });

  const refreshQuotas = () => {
    setQuotas(QuotaService.getAllQuotas());
  };

  useEffect(() => {
    refreshQuotas();
    const unsub = QuotaService.subscribe(() => {
      refreshQuotas();
    });
    return unsub;
  }, []);

  // Compute live usages
  const usages: UserQuotaUsage[] = useMemo(() => {
    return QuotaService.calculateUsages(objects);
  }, [quotas, objects]);

  // Cluster aggregate quota stats
  const aggregateStats = useMemo(() => {
    const totalAllocatedMB = usages.reduce((sum, u) => sum + u.storageQuotaMB, 0);
    const totalUsedBytes = usages.reduce((sum, u) => sum + u.usedBytes, 0);
    const totalUsedMB = +(totalUsedBytes / (1024 * 1024)).toFixed(2);
    const warningCount = usages.filter(u => u.isNearQuotaLimit && !u.isOverStorageQuota).length;
    const exceededCount = usages.filter(u => u.isOverStorageQuota).length;
    const totalTenants = usages.length;

    return {
      totalAllocatedMB,
      totalUsedMB,
      warningCount,
      exceededCount,
      totalTenants,
      utilizationPercent: totalAllocatedMB > 0 ? Math.min(100, +((totalUsedMB / totalAllocatedMB) * 100).toFixed(1)) : 0,
    };
  }, [usages]);

  // Filtered accounts list
  const filteredUsages = useMemo(() => {
    return usages.filter(item => {
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        item.userEmail.toLowerCase().includes(q) ||
        item.userName.toLowerCase().includes(q);

      const matchesTier = tierFilter === 'all' || item.tier === tierFilter;
      const matchesEnforcement = enforcementFilter === 'all' || item.enforcementMode === enforcementFilter;

      let matchesStatus = true;
      if (statusFilter === 'healthy') {
        matchesStatus = !item.isNearQuotaLimit && !item.isOverStorageQuota;
      } else if (statusFilter === 'warning') {
        matchesStatus = item.isNearQuotaLimit && !item.isOverStorageQuota;
      } else if (statusFilter === 'exceeded') {
        matchesStatus = item.isOverStorageQuota;
      }

      return matchesSearch && matchesTier && matchesEnforcement && matchesStatus;
    });
  }, [usages, searchQuery, tierFilter, enforcementFilter, statusFilter]);

  // Handlers
  const handleOpenEdit = (usage: UserQuotaUsage) => {
    setEditingConfig({
      userId: usage.userId,
      userEmail: usage.userEmail,
      userName: usage.userName,
      role: usage.role,
      storageQuotaMB: usage.storageQuotaMB,
      maxObjectsQuota: usage.maxObjectsQuota,
      tier: usage.tier,
      enforcementMode: usage.enforcementMode,
      warningThresholdPercent: usage.warningThresholdPercent,
      updatedAt: usage.updatedAt,
    });
    setFormData({
      userEmail: usage.userEmail,
      userName: usage.userName,
      role: usage.role,
      storageQuotaMB: usage.storageQuotaMB,
      maxObjectsQuota: usage.maxObjectsQuota,
      tier: usage.tier,
      enforcementMode: usage.enforcementMode,
      warningThresholdPercent: usage.warningThresholdPercent,
    });
  };

  const handleOpenAdd = () => {
    setEditingConfig(null);
    setFormData({
      userEmail: '',
      userName: '',
      role: 'user',
      storageQuotaMB: 150,
      maxObjectsQuota: 30,
      tier: 'Developer',
      enforcementMode: 'hard',
      warningThresholdPercent: 80,
    });
    setIsAddModalOpen(true);
  };

  const handleTierSelect = (tier: QuotaTier) => {
    const preset = QUOTA_TIER_PRESETS[tier];
    setFormData(prev => ({
      ...prev,
      tier,
      storageQuotaMB: tier === 'Custom' ? prev.storageQuotaMB : preset.storageMB,
      maxObjectsQuota: tier === 'Custom' ? prev.maxObjectsQuota : preset.maxObjects,
    }));
  };

  const handleSaveForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.userEmail || !formData.userEmail.includes('@')) {
      onNotify('error', 'Invalid Email', 'Please enter a valid user email address.');
      return;
    }

    const adminActor = currentUser?.email || 'admin';
    const configToSave: UserQuotaConfig = {
      userId: editingConfig?.userId || `usr_${Math.random().toString(36).slice(2, 8)}`,
      userEmail: formData.userEmail.trim().toLowerCase(),
      userName: formData.userName.trim() || formData.userEmail.split('@')[0],
      role: formData.role,
      storageQuotaMB: Math.max(5, Number(formData.storageQuotaMB)),
      maxObjectsQuota: Math.max(0, Number(formData.maxObjectsQuota)),
      tier: formData.tier,
      enforcementMode: formData.enforcementMode,
      warningThresholdPercent: Math.min(95, Math.max(40, Number(formData.warningThresholdPercent))),
      updatedAt: Date.now(),
      lastUpdatedBy: adminActor,
    };

    QuotaService.saveQuota(configToSave, adminActor);
    setEditingConfig(null);
    setIsAddModalOpen(false);

    onNotify(
      'success',
      'Quota Policy Committed',
      `Allocated ${configToSave.storageQuotaMB} MB (${configToSave.tier} Tier, ${configToSave.enforcementMode.toUpperCase()} mode) for ${configToSave.userEmail}.`
    );
  };

  const handleQuickAdjust = (email: string, deltaMB: number) => {
    const current = QuotaService.getQuotaForUser(email);
    const newStorage = Math.max(10, current.storageQuotaMB + deltaMB);
    current.storageQuotaMB = newStorage;
    current.tier = 'Custom';
    QuotaService.saveQuota(current, currentUser?.email || 'admin');
    onNotify(
      'info',
      'Quota Adjusted',
      `Updated ${email} storage capacity to ${newStorage} MB.`
    );
  };

  const handleSwitchToUser = (email: string) => {
    const switched = AuthService.switchUser(email);
    if (switched) {
      onNotify(
        'success',
        'Account Switched',
        `Switched session to ${switched.name} (${switched.email}). Active quota applied to uploads.`
      );
    } else {
      // Auto register local session
      const created = AuthService.loginWithEmail(email, email.split('@')[0]);
      onNotify('success', 'Session Active', `Logged in as ${created.name}.`);
    }
  };

  const handleResetDefaults = () => {
    QuotaService.resetToDefaults();
    onNotify('info', 'Quotas Reset', 'Restored default multi-tenant tier quotas for demo accounts.');
  };

  const handleExportQuotaReport = () => {
    const report = {
      system: 'AetherStore Distributed Storage Quota Audit',
      generatedAt: new Date().toISOString(),
      generatedBy: currentUser?.email || 'admin',
      clusterSummary: aggregateStats,
      tenants: usages,
    };

    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `aetherstore_quota_report_${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    onNotify('success', 'Report Exported', 'Downloaded complete storage quota ledger as formatted JSON.');
  };

  return (
    <div className="space-y-6">
      {/* Hero Header */}
      <div
        className={`rounded-3xl p-6 sm:p-8 transition-colors ${
          isDarkMode ? 'liquid-glass-dark' : 'liquid-glass-light'
        }`}
      >
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className={`flex items-center gap-2 text-xs font-mono font-bold ${isDarkMode ? 'text-cyan-400' : 'text-cyan-800'}`}>
              <Shield className="w-3.5 h-3.5" />
              <span>Multi-Tenant Resource Allocation &amp; Access Controls</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white">User Storage Quotas &amp; Monitoring</h2>
            <p className={`text-xs sm:text-sm max-w-2xl ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
              Configure fine-grained storage limits (MB/GB), maximum object constraints, and hard vs. soft write
              enforcement policies for all tenant accounts across the distributed storage cluster.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={handleOpenAdd}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white shadow-lg shadow-cyan-600/25 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Provision User Quota</span>
            </button>

            <button
              onClick={handleExportQuotaReport}
              className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-xs font-semibold border transition-colors cursor-pointer ${
                isDarkMode
                  ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
                  : 'bg-white hover:bg-slate-100 text-slate-800 border-slate-300 shadow-sm'
              }`}
              title="Export formatted JSON report of all tenant quotas and utilization"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Export Report</span>
            </button>

            <button
              onClick={handleResetDefaults}
              className={`p-2.5 rounded-xl border transition-colors cursor-pointer ${
                isDarkMode
                  ? 'text-slate-400 hover:text-slate-200 border-slate-800 hover:bg-slate-800'
                  : 'text-slate-600 hover:text-slate-900 border-slate-300 hover:bg-slate-100 shadow-sm'
              }`}
              title="Reset Quotas to Default"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Aggregate KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 font-mono">
        {/* Total Allocated */}
        <div
          className={`p-4 sm:p-5 rounded-2xl border transition-all ${
            isDarkMode ? 'liquid-glass-dark border-slate-800' : 'liquid-glass-light border-slate-300 shadow-sm'
          }`}
        >
          <div className={`flex items-center justify-between text-xs font-bold ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
            <span>Total Allocated</span>
            <HardDrive className={`w-4 h-4 ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`} />
          </div>
          <div className={`mt-2 text-2xl sm:text-3xl font-bold tabular-nums ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`}>
            {aggregateStats.totalAllocatedMB >= 1024
              ? `${(aggregateStats.totalAllocatedMB / 1024).toFixed(2)} GB`
              : `${aggregateStats.totalAllocatedMB} MB`}
          </div>
          <div className={`mt-1 text-[11px] ${isDarkMode ? 'text-slate-500' : 'text-slate-600 font-medium'}`}>
            Across {aggregateStats.totalTenants} tenant accounts
          </div>
        </div>

        {/* Current Cluster Utilization */}
        <div
          className={`p-4 sm:p-5 rounded-2xl border transition-all ${
            isDarkMode ? 'liquid-glass-dark border-slate-800' : 'liquid-glass-light border-slate-300 shadow-sm'
          }`}
        >
          <div className={`flex items-center justify-between text-xs font-bold ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
            <span>Active Usage</span>
            <TrendingUp className={`w-4 h-4 ${isDarkMode ? 'text-emerald-400' : 'text-emerald-700'}`} />
          </div>
          <div className={`mt-2 text-2xl sm:text-3xl font-bold tabular-nums ${isDarkMode ? 'text-emerald-400' : 'text-emerald-700'}`}>
            {aggregateStats.totalUsedMB} MB
          </div>
          <div className={`mt-1 text-[11px] ${isDarkMode ? 'text-slate-500' : 'text-slate-600 font-medium'}`}>
            {aggregateStats.utilizationPercent}% of allocated pool
          </div>
        </div>

        {/* Warning Threshold Accounts */}
        <div
          className={`p-4 sm:p-5 rounded-2xl border transition-all ${
            isDarkMode ? 'liquid-glass-dark border-slate-800' : 'liquid-glass-light border-slate-300 shadow-sm'
          }`}
        >
          <div className={`flex items-center justify-between text-xs font-bold ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
            <span>Warning (≥ 80%)</span>
            <AlertTriangle className={`w-4 h-4 ${isDarkMode ? 'text-amber-400' : 'text-amber-600'}`} />
          </div>
          <div className={`mt-2 text-2xl sm:text-3xl font-bold tabular-nums ${isDarkMode ? 'text-amber-400' : 'text-amber-600'}`}>
            {aggregateStats.warningCount}
          </div>
          <div className={`mt-1 text-[11px] ${isDarkMode ? 'text-slate-500' : 'text-slate-600 font-medium'}`}>
            Approaching capacity limit
          </div>
        </div>

        {/* Exceeded Accounts */}
        <div
          className={`p-4 sm:p-5 rounded-2xl border transition-all ${
            isDarkMode ? 'liquid-glass-dark border-slate-800' : 'liquid-glass-light border-slate-300 shadow-sm'
          }`}
        >
          <div className={`flex items-center justify-between text-xs font-bold ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
            <span>Quota Exceeded</span>
            <ShieldAlert className={`w-4 h-4 ${isDarkMode ? 'text-rose-400' : 'text-rose-600'}`} />
          </div>
          <div className={`mt-2 text-2xl sm:text-3xl font-bold tabular-nums ${isDarkMode ? 'text-rose-400' : 'text-rose-600'}`}>
            {aggregateStats.exceededCount}
          </div>
          <div className={`mt-1 text-[11px] ${isDarkMode ? 'text-slate-500' : 'text-slate-600 font-medium'}`}>
            Hard writes blocked
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div
        className={`rounded-3xl p-5 sm:p-6 transition-colors ${
          isDarkMode ? 'liquid-glass-dark' : 'liquid-glass-light'
        }`}
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Search Input */}
          <div className="relative">
            <Search className={`absolute left-3 top-2.5 w-4 h-4 ${isDarkMode ? 'text-slate-500' : 'text-slate-400'}`} />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search user name or email..."
              className={`w-full pl-9 pr-3 py-2 text-xs rounded-xl border outline-none font-mono ${
                isDarkMode
                  ? 'bg-slate-900 border-slate-700 text-slate-100 placeholder:text-slate-500'
                  : 'bg-white border-slate-300 text-slate-900 placeholder:text-slate-400 shadow-sm'
              }`}
            />
          </div>

          {/* Tier Filter */}
          <select
            value={tierFilter}
            onChange={e => setTierFilter(e.target.value)}
            className={`w-full p-2 text-xs rounded-xl border outline-none font-mono ${
              isDarkMode
                ? 'bg-slate-900 border-slate-700 text-slate-100'
                : 'bg-white border-slate-300 text-slate-900 shadow-sm'
            }`}
          >
            <option value="all">All Quota Tiers</option>
            <option value="Free">Free Tier (25 MB)</option>
            <option value="Developer">Developer Tier (150 MB)</option>
            <option value="Pro">Pro Tier (500 MB)</option>
            <option value="Enterprise">Enterprise Tier (2 GB)</option>
            <option value="Custom">Custom Quotas</option>
          </select>

          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value as any)}
            className={`w-full p-2 text-xs rounded-xl border outline-none font-mono ${
              isDarkMode
                ? 'bg-slate-900 border-slate-700 text-slate-100'
                : 'bg-white border-slate-300 text-slate-900 shadow-sm'
            }`}
          >
            <option value="all">All Utilization States</option>
            <option value="healthy">Healthy (&lt; 80%)</option>
            <option value="warning">Warning (80% - 99%)</option>
            <option value="exceeded">Exceeded (≥ 100%)</option>
          </select>

          {/* Enforcement Filter */}
          <select
            value={enforcementFilter}
            onChange={e => setEnforcementFilter(e.target.value)}
            className={`w-full p-2 text-xs rounded-xl border outline-none font-mono ${
              isDarkMode
                ? 'bg-slate-900 border-slate-700 text-slate-100'
                : 'bg-white border-slate-300 text-slate-900 shadow-sm'
            }`}
          >
            <option value="all">All Enforcement Modes</option>
            <option value="hard">Hard Quorum Block (Strict)</option>
            <option value="soft">Soft Notification (Permissive)</option>
          </select>
        </div>

        {/* Quota Accounts List / Table */}
        <div className={`mt-6 overflow-x-auto rounded-2xl border ${isDarkMode ? 'border-slate-800' : 'border-slate-300 shadow-sm'}`}>
          <table className="w-full text-left text-xs">
            <thead>
              <tr
                className={`font-mono uppercase text-[10px] font-bold border-b ${
                  isDarkMode
                    ? 'border-slate-800 text-slate-400 bg-slate-900/50'
                    : 'border-slate-200 text-slate-700 bg-slate-100'
                }`}
              >
                <th className="py-3 px-3">Account &amp; Role</th>
                <th className="py-3 px-3">Tier</th>
                <th className="py-3 px-3 min-w-[200px]">Storage Quota &amp; Usage</th>
                <th className="py-3 px-3">Object Limit</th>
                <th className="py-3 px-3">Enforcement</th>
                <th className="py-3 px-3">Warning At</th>
                <th className="py-3 px-3 text-right">Admin Actions</th>
              </tr>
            </thead>
            <tbody className={`divide-y font-mono ${isDarkMode ? 'divide-slate-800' : 'divide-slate-200'}`}>
              {filteredUsages.length === 0 ? (
                <tr>
                  <td colSpan={7} className={`py-12 text-center text-xs ${isDarkMode ? 'text-slate-500' : 'text-slate-600 font-medium'}`}>
                    No accounts match the current filter criteria.
                  </td>
                </tr>
              ) : (
                filteredUsages.map(item => {
                  const isCurrent = currentUser?.email.toLowerCase() === item.userEmail.toLowerCase();
                  const isExceeded = item.isOverStorageQuota;
                  const isWarning = item.isNearQuotaLimit && !isExceeded;

                  return (
                    <tr
                      key={item.userId}
                      className={`transition-colors ${
                        isCurrent
                          ? isDarkMode
                            ? 'bg-cyan-950/20'
                            : 'bg-cyan-50/80'
                          : isDarkMode
                          ? 'hover:bg-slate-900/30'
                          : 'hover:bg-slate-50'
                      }`}
                    >
                      {/* Account & Role */}
                      <td className="py-4 px-3">
                        <div className="flex items-center gap-2.5">
                          <div
                            className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 border ${
                              isDarkMode
                                ? 'bg-gradient-to-tr from-cyan-500/20 to-blue-500/20 text-cyan-300 border-cyan-500/30'
                                : 'bg-gradient-to-tr from-cyan-100 to-blue-100 text-cyan-900 border-cyan-300 shadow-sm'
                            }`}
                          >
                            {item.userName.slice(0, 1).toUpperCase()}
                          </div>
                          <div>
                            <div className="font-semibold flex items-center gap-1.5">
                              <span className={isDarkMode ? 'text-slate-200' : 'text-slate-900'}>{item.userName}</span>
                              {item.role === 'admin' ? (
                                <span
                                  className={`px-1.5 py-0.2 rounded text-[9px] font-bold border ${
                                    isDarkMode
                                      ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30'
                                      : 'bg-cyan-100 text-cyan-800 border-cyan-300'
                                  }`}
                                >
                                  ADMIN
                                </span>
                              ) : (
                                <span
                                  className={`px-1.5 py-0.2 rounded text-[9px] font-bold border ${
                                    isDarkMode
                                      ? 'bg-slate-800 text-slate-400 border-slate-700'
                                      : 'bg-slate-100 text-slate-700 border-slate-300'
                                  }`}
                                >
                                  TENANT
                                </span>
                              )}
                              {isCurrent && (
                                <span
                                  className={`px-1.5 py-0.2 rounded text-[9px] font-bold border ${
                                    isDarkMode
                                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                                      : 'bg-emerald-100 text-emerald-800 border-emerald-300'
                                  }`}
                                >
                                  YOU
                                </span>
                              )}
                            </div>
                            <div className={`text-[11px] font-mono mt-0.5 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                              {item.userEmail}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Tier */}
                      <td className="py-4 px-3">
                        <span
                          className={`px-2 py-0.5 rounded-md text-[10px] font-bold border ${
                            item.tier === 'Enterprise'
                              ? isDarkMode
                                ? 'bg-purple-500/20 text-purple-300 border-purple-500/30'
                                : 'bg-purple-100 text-purple-800 border-purple-300'
                              : item.tier === 'Pro'
                              ? isDarkMode
                                ? 'bg-blue-500/20 text-blue-300 border-blue-500/30'
                                : 'bg-blue-100 text-blue-800 border-blue-300'
                              : item.tier === 'Developer'
                              ? isDarkMode
                                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                                : 'bg-emerald-100 text-emerald-800 border-emerald-300'
                              : item.tier === 'Custom'
                              ? isDarkMode
                                ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                                : 'bg-amber-100 text-amber-800 border-amber-300'
                              : isDarkMode
                              ? 'bg-slate-800 text-slate-400 border-slate-700'
                              : 'bg-slate-100 text-slate-700 border-slate-300'
                          }`}
                        >
                          {item.tier}
                        </span>
                      </td>

                      {/* Storage Usage Progress Bar */}
                      <td className="py-4 px-3">
                        <div className="space-y-1.5">
                          <div className="flex items-center justify-between text-[11px]">
                            <span className={`font-semibold ${isDarkMode ? 'text-slate-200' : 'text-slate-900'}`}>
                              {item.usedMB} MB / {item.storageQuotaMB} MB
                            </span>
                            <span
                              className={`font-bold ${
                                isExceeded
                                  ? isDarkMode
                                    ? 'text-rose-400 animate-pulse'
                                    : 'text-rose-700 animate-pulse'
                                  : isWarning
                                  ? isDarkMode
                                    ? 'text-amber-400'
                                    : 'text-amber-700'
                                  : isDarkMode
                                  ? 'text-emerald-400'
                                  : 'text-emerald-700'
                              }`}
                            >
                              {item.usedPercent}%
                            </span>
                          </div>

                          <div className={`w-full h-2 rounded-full overflow-hidden ${isDarkMode ? 'bg-slate-800' : 'bg-slate-200'}`}>
                            <div
                              className={`h-full transition-all duration-300 ${
                                isExceeded
                                  ? 'bg-rose-500'
                                  : isWarning
                                  ? 'bg-amber-500'
                                  : isDarkMode
                                  ? 'bg-emerald-500'
                                  : 'bg-emerald-600'
                              }`}
                              style={{ width: `${Math.min(100, item.usedPercent)}%` }}
                            />
                          </div>

                          <div className={`text-[10px] flex justify-between ${isDarkMode ? 'text-slate-500' : 'text-slate-600'}`}>
                            <span>
                              Remaining: {Math.max(0, +(item.storageQuotaMB - item.usedMB).toFixed(2))} MB
                            </span>
                            {isExceeded && (
                              <span className={`font-bold ${isDarkMode ? 'text-rose-400' : 'text-rose-700'}`}>
                                WRITES BLOCKED
                              </span>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Object Limit */}
                      <td className="py-4 px-3">
                        <div>
                          <div className={`font-semibold ${isDarkMode ? 'text-slate-200' : 'text-slate-900'}`}>
                            {item.objectCount}{' '}
                            <span className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>
                              / {item.maxObjectsQuota > 0 ? `${item.maxObjectsQuota} objs` : '∞'}
                            </span>
                          </div>
                          {item.maxObjectsQuota > 0 && (
                            <div className={`text-[10px] mt-0.5 ${isDarkMode ? 'text-slate-500' : 'text-slate-600'}`}>
                              {item.objectsPercent}% cap
                            </div>
                          )}
                        </div>
                      </td>

                      {/* Enforcement Mode */}
                      <td className="py-4 px-3">
                        {item.enforcementMode === 'hard' ? (
                          <span
                            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold border ${
                              isDarkMode
                                ? 'bg-rose-500/15 text-rose-300 border-rose-500/30'
                                : 'bg-rose-100 text-rose-800 border-rose-300'
                            }`}
                            title="Hard limit: Cluster strictly rejects writes exceeding quota"
                          >
                            <Lock className="w-3 h-3" />
                            <span>HARD BLOCK</span>
                          </span>
                        ) : (
                          <span
                            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold border ${
                              isDarkMode
                                ? 'bg-blue-500/15 text-blue-300 border-blue-500/30'
                                : 'bg-blue-100 text-blue-800 border-blue-300'
                            }`}
                            title="Soft limit: Emits audit warnings but permits writes"
                          >
                            <Unlock className="w-3 h-3" />
                            <span>SOFT NOTIFY</span>
                          </span>
                        )}
                      </td>

                      {/* Warning Threshold */}
                      <td className={`py-4 px-3 ${isDarkMode ? 'text-slate-400' : 'text-slate-700 font-semibold'}`}>
                        <span>≥ {item.warningThresholdPercent}%</span>
                      </td>

                      {/* Admin Actions */}
                      <td className="py-4 px-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Quick Adjust -50MB */}
                          <button
                            onClick={() => handleQuickAdjust(item.userEmail, -50)}
                            className={`px-2 py-1 rounded-lg text-[10px] font-bold border transition-colors cursor-pointer ${
                              isDarkMode
                                ? 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
                                : 'bg-white hover:bg-slate-100 text-slate-800 border-slate-300 shadow-sm'
                            }`}
                            title="Reduce quota by 50MB"
                          >
                            -50MB
                          </button>

                          {/* Quick Adjust +50MB */}
                          <button
                            onClick={() => handleQuickAdjust(item.userEmail, 50)}
                            className={`px-2 py-1 rounded-lg text-[10px] font-bold border transition-colors cursor-pointer ${
                              isDarkMode
                                ? 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
                                : 'bg-white hover:bg-slate-100 text-slate-800 border-slate-300 shadow-sm'
                            }`}
                            title="Increase quota by 50MB"
                          >
                            +50MB
                          </button>

                          {/* Edit Quota Button */}
                          <button
                            onClick={() => handleOpenEdit(item)}
                            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                              isDarkMode
                                ? 'text-slate-400 hover:text-cyan-400 hover:bg-slate-800'
                                : 'text-slate-600 hover:text-cyan-700 hover:bg-slate-100'
                            }`}
                            title="Edit Custom Storage Quota"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          {/* Switch User Session Button */}
                          {!isCurrent && (
                            <button
                              onClick={() => handleSwitchToUser(item.userEmail)}
                              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                                isDarkMode
                                  ? 'text-slate-400 hover:text-emerald-400 hover:bg-slate-800'
                                  : 'text-slate-600 hover:text-emerald-700 hover:bg-slate-100'
                              }`}
                              title={`Switch active session to ${item.userName}`}
                            >
                              <UserCheck className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Preset Tier Comparison Showcase */}
      <div
        className={`rounded-3xl p-6 sm:p-7 border transition-all ${
          isDarkMode ? 'liquid-glass-dark border-slate-800' : 'liquid-glass-light border-slate-300 shadow-sm'
        }`}
      >
        <div className="flex items-center gap-3 mb-4">
          <div
            className={`p-2 rounded-xl border ${
              isDarkMode
                ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20'
                : 'bg-cyan-100 text-cyan-800 border-cyan-300'
            }`}
          >
            <Sliders className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold tracking-tight text-slate-900 dark:text-white">Standard Cluster Quota Tiers</h3>
            <p className={`text-[11px] font-mono ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
              Apply pre-defined service tiers or configure granular custom limits per tenant account
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs font-mono">
          {(['Free', 'Developer', 'Pro', 'Enterprise'] as QuotaTier[]).map(tier => {
            const preset = QUOTA_TIER_PRESETS[tier];
            return (
              <div
                key={tier}
                className={`p-4 rounded-2xl border transition-all ${
                  isDarkMode ? 'bg-slate-950/60 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
                }`}
              >
                <div className={`flex items-center justify-between pb-2 border-b ${isDarkMode ? 'border-slate-800/40' : 'border-slate-200'}`}>
                  <span className={`font-bold ${isDarkMode ? 'text-slate-200' : 'text-slate-900'}`}>{tier} Tier</span>
                  <span className={`font-bold ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`}>{preset.storageMB} MB</span>
                </div>
                <div className="mt-2.5 space-y-1 text-[11px]">
                  <div className={isDarkMode ? 'text-slate-300' : 'text-slate-700 font-medium'}>Max Objects: {preset.maxObjects} objs</div>
                  <div className={`text-[10px] leading-relaxed mt-1 ${isDarkMode ? 'text-slate-500' : 'text-slate-600'}`}>
                    {preset.description}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Modal: Edit or Provision Quota */}
      {(editingConfig || isAddModalOpen) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-in fade-in duration-200">
          <div
            className={`w-full max-w-lg rounded-3xl p-6 sm:p-7 border shadow-2xl transition-all ${
              isDarkMode ? 'bg-slate-950 border-slate-800 text-slate-100' : 'bg-white border-slate-300 text-slate-900'
            }`}
          >
            <div className={`flex items-center justify-between pb-4 border-b ${isDarkMode ? 'border-slate-800/60' : 'border-slate-200'}`}>
              <div className="flex items-center gap-2.5">
                <Sliders className={`w-5 h-5 ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`} />
                <h3 className="text-base font-bold tracking-tight">
                  {editingConfig ? 'Edit Storage Quota Policy' : 'Provision Custom Storage Quota'}
                </h3>
              </div>
              <button
                onClick={() => {
                  setEditingConfig(null);
                  setIsAddModalOpen(false);
                }}
                className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                  isDarkMode
                    ? 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                    : 'text-slate-500 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveForm} className="mt-5 space-y-4 text-xs font-mono">
              {/* User Email & Display Name */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className={`block font-semibold mb-1 ${isDarkMode ? 'text-slate-300' : 'text-slate-800'}`}>
                    User Email Address
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.userEmail}
                    disabled={!!editingConfig}
                    onChange={e => setFormData({ ...formData, userEmail: e.target.value })}
                    placeholder="engineer@corp.io"
                    className={`w-full p-2.5 rounded-xl border outline-none ${
                      isDarkMode
                        ? 'bg-slate-900 border-slate-700 text-slate-100'
                        : 'bg-white border-slate-300 text-slate-900'
                    } ${editingConfig ? 'opacity-60 cursor-not-allowed' : ''}`}
                  />
                </div>

                <div>
                  <label className={`block font-semibold mb-1 ${isDarkMode ? 'text-slate-300' : 'text-slate-800'}`}>
                    Account Display Name
                  </label>
                  <input
                    type="text"
                    value={formData.userName}
                    onChange={e => setFormData({ ...formData, userName: e.target.value })}
                    placeholder="Full Name"
                    className={`w-full p-2.5 rounded-xl border outline-none ${
                      isDarkMode
                        ? 'bg-slate-900 border-slate-700 text-slate-100'
                        : 'bg-white border-slate-300 text-slate-900'
                    }`}
                  />
                </div>
              </div>

              {/* Tier Presets Selector */}
              <div>
                <label className={`block font-semibold mb-1.5 ${isDarkMode ? 'text-slate-300' : 'text-slate-800'}`}>
                  Preset Quota Tier
                </label>
                <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5">
                  {(['Free', 'Developer', 'Pro', 'Enterprise', 'Custom'] as QuotaTier[]).map(t => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => handleTierSelect(t)}
                      className={`py-1.5 px-2 rounded-lg text-[11px] font-semibold border transition-all text-center cursor-pointer ${
                        formData.tier === t
                          ? isDarkMode
                            ? 'bg-cyan-500/25 text-cyan-300 border-cyan-500/50 shadow-sm'
                            : 'bg-cyan-100 text-cyan-900 border-cyan-400 font-bold shadow-sm'
                          : isDarkMode
                          ? 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                          : 'bg-slate-100 border-slate-300 text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              {/* Storage Quota (MB) & Object Limit */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className={`block font-semibold mb-1 ${isDarkMode ? 'text-slate-300' : 'text-slate-800'}`}>
                    Storage Quota Limit (MB)
                  </label>
                  <input
                    type="number"
                    min={5}
                    max={100000}
                    required
                    value={formData.storageQuotaMB}
                    onChange={e =>
                      setFormData({
                        ...formData,
                        storageQuotaMB: Number(e.target.value),
                        tier: 'Custom',
                      })
                    }
                    className={`w-full p-2.5 rounded-xl border outline-none font-bold ${
                      isDarkMode
                        ? 'bg-slate-900 border-slate-700 text-cyan-400'
                        : 'bg-white border-slate-300 text-cyan-700'
                    }`}
                  />
                  <span className={`text-[10px] mt-1 block ${isDarkMode ? 'text-slate-500' : 'text-slate-600'}`}>
                    {(formData.storageQuotaMB / 1024).toFixed(2)} GB capacity
                  </span>
                </div>

                <div>
                  <label className={`block font-semibold mb-1 ${isDarkMode ? 'text-slate-300' : 'text-slate-800'}`}>
                    Max Object Limit (0 = ∞)
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={50000}
                    required
                    value={formData.maxObjectsQuota}
                    onChange={e =>
                      setFormData({
                        ...formData,
                        maxObjectsQuota: Number(e.target.value),
                        tier: 'Custom',
                      })
                    }
                    className={`w-full p-2.5 rounded-xl border outline-none ${
                      isDarkMode
                        ? 'bg-slate-900 border-slate-700 text-slate-100'
                        : 'bg-white border-slate-300 text-slate-900'
                    }`}
                  />
                  <span className={`text-[10px] mt-1 block ${isDarkMode ? 'text-slate-500' : 'text-slate-600'}`}>
                    Max resident object count
                  </span>
                </div>
              </div>

              {/* Enforcement Mode & Role */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className={`block font-semibold mb-1 ${isDarkMode ? 'text-slate-300' : 'text-slate-800'}`}>
                    Enforcement Policy
                  </label>
                  <select
                    value={formData.enforcementMode}
                    onChange={e => setFormData({ ...formData, enforcementMode: e.target.value as any })}
                    className={`w-full p-2.5 rounded-xl border outline-none ${
                      isDarkMode
                        ? 'bg-slate-900 border-slate-700 text-slate-100'
                        : 'bg-white border-slate-300 text-slate-900'
                    }`}
                  >
                    <option value="hard">Hard Limit (Block writes if full)</option>
                    <option value="soft">Soft Limit (Audit log warning only)</option>
                  </select>
                </div>

                <div>
                  <label className={`block font-semibold mb-1 ${isDarkMode ? 'text-slate-300' : 'text-slate-800'}`}>
                    Account Role
                  </label>
                  <select
                    value={formData.role}
                    onChange={e => setFormData({ ...formData, role: e.target.value as any })}
                    className={`w-full p-2.5 rounded-xl border outline-none ${
                      isDarkMode
                        ? 'bg-slate-900 border-slate-700 text-slate-100'
                        : 'bg-white border-slate-300 text-slate-900'
                    }`}
                  >
                    <option value="user">Tenant User</option>
                    <option value="admin">Cluster Administrator</option>
                  </select>
                </div>
              </div>

              {/* Warning Threshold Slider */}
              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className={`font-semibold ${isDarkMode ? 'text-slate-300' : 'text-slate-800'}`}>
                    Warning Alert Threshold
                  </label>
                  <span className={`font-bold ${isDarkMode ? 'text-amber-400' : 'text-amber-700'}`}>
                    {formData.warningThresholdPercent}%
                  </span>
                </div>
                <input
                  type="range"
                  min={50}
                  max={95}
                  step={5}
                  value={formData.warningThresholdPercent}
                  onChange={e => setFormData({ ...formData, warningThresholdPercent: Number(e.target.value) })}
                  className="w-full accent-cyan-600 cursor-pointer"
                />
                <span className={`text-[10px] block mt-0.5 ${isDarkMode ? 'text-slate-500' : 'text-slate-600'}`}>
                  Cluster audit ledger logs warnings when tenant usage exceeds this percentage.
                </span>
              </div>

              {/* Form Buttons */}
              <div className={`pt-3 border-t flex items-center justify-end gap-2.5 ${isDarkMode ? 'border-slate-800/60' : 'border-slate-200'}`}>
                <button
                  type="button"
                  onClick={() => {
                    setEditingConfig(null);
                    setIsAddModalOpen(false);
                  }}
                  className={`px-4 py-2 rounded-xl border transition-colors cursor-pointer ${
                    isDarkMode
                      ? 'text-slate-400 hover:text-slate-200 border-slate-700/60 hover:bg-slate-800'
                      : 'text-slate-700 hover:text-slate-900 border-slate-300 hover:bg-slate-100'
                  }`}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl font-semibold bg-cyan-600 hover:bg-cyan-700 text-white shadow-md shadow-cyan-600/20 transition-all cursor-pointer"
                >
                  Save Quota Policy
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
