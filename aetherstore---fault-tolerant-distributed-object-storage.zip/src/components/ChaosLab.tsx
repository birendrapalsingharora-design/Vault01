import { useState } from 'react';
import {
  Zap,
  Activity,
  ShieldAlert,
  Split,
  RefreshCw,
  Scale,
  CheckCircle2,
  AlertOctagon,
  ArrowRight,
  Server,
  Layers,
  Wrench,
  Flame,
  Star,
  Play,
  RotateCcw,
  Check,
  Clock,
  Radio,
} from 'lucide-react';
import { StorageNode, StorageObject, RepairJob } from '../types/storage';
import { StorageEngine } from '../services/storageEngine';

interface ChaosLabProps {
  nodes: StorageNode[];
  objects: StorageObject[];
  repairJobs: RepairJob[];
  isDarkMode: boolean;
  onNotify: (type: 'success' | 'warning' | 'error' | 'info', title: string, msg: string) => void;
  onOpenRecoveryWizard?: (objectId?: string) => void;
}

export function ChaosLab({
  nodes,
  objects,
  repairJobs,
  isDarkMode,
  onNotify,
  onOpenRecoveryWizard,
}: ChaosLabProps) {
  const [selectedObjectId, setSelectedObjectId] = useState<string>(objects[0]?.id || '');
  const [selectedChunkIndex, setSelectedChunkIndex] = useState<number>(0);
  const [selectedNodeToCrash, setSelectedNodeToCrash] = useState<string>('node-1');
  const [isScrubbing, setIsScrubbing] = useState(false);
  const [isRebalancing, setIsRebalancing] = useState(false);
  const [isRecovering, setIsRecovering] = useState(false);

  const isPartitionActive = StorageEngine.isPartitionActive();

  const handleTogglePriority = (obj: StorageObject) => {
    const nextPriority = obj.priority === 'high' ? 'normal' : 'high';
    StorageEngine.setObjectPriority(obj.id, nextPriority);
    onNotify(
      'info',
      `SLA Priority: ${nextPriority.toUpperCase()}`,
      `"${obj.originalName}" is now marked as ${
        nextPriority === 'high' ? 'High-Priority (P1 Emergency Recovery SLA)' : 'Standard (P2)'
      }. It will be restored first if a node fails.`
    );
  };

  const handleCrashNode = () => {
    const node = nodes.find(n => n.id === selectedNodeToCrash);
    if (!node) return;
    if (node.status === 'crashed') {
      onNotify('info', 'Node Already Crashed', `${node.name} is already in a failed state.`);
      return;
    }

    StorageEngine.crashNode(selectedNodeToCrash);
    onNotify(
      'error',
      'Node Crash Injected (Chaos)',
      `${node.name} [${node.rack}] failed abruptly. Storage scheduler queued prioritized failover repairs.`
    );
  };

  const handleReviveAllNodes = () => {
    nodes.filter(n => n.status === 'crashed').forEach(n => {
      StorageEngine.reviveNode(n.id);
    });
    onNotify('success', 'Nodes Restored', 'All crashed storage nodes revived and re-joined the cluster quorum.');
  };

  const handleTriggerPrioritizedRecovery = async () => {
    setIsRecovering(true);
    const res = await StorageEngine.triggerPrioritizedRecovery();
    setIsRecovering(false);

    if (res.repairedCount === 0) {
      onNotify('info', 'Queue Nominal', 'No degraded shards or pending repair jobs in the queue.');
    } else {
      onNotify(
        'success',
        'Prioritized Recovery Complete',
        `Restored ${res.repairedCount} degraded shards. ${res.highPriorityCount} High-Priority (P1) objects healed first ahead of standard objects!`
      );
    }
  };

  const handleInjectBitRot = () => {
    const obj = objects.find(o => o.id === selectedObjectId);
    if (!obj || !obj.chunks[selectedChunkIndex]) {
      onNotify('error', 'Select Chunk', 'Please select an existing object and shard index.');
      return;
    }
    const chunk = obj.chunks[selectedChunkIndex];
    const targetNodeId = chunk.nodeIds[0] || 'node-1';

    StorageEngine.injectBitRot(obj.id, selectedChunkIndex, targetNodeId);
    onNotify(
      'warning',
      'Bit Rot Injected (Silent Corruption)',
      `Inverted payload bits on Shard #${selectedChunkIndex} (${obj.originalName}) on node ${targetNodeId}. Checksum mismatch created.`
    );
  };

  const handleTogglePartition = () => {
    const nextState = !isPartitionActive;
    StorageEngine.toggleNetworkPartition(nextState);
    if (nextState) {
      onNotify(
        'warning',
        'Inter-Rack Partition Created',
        'Rack-Alpha and Rack-Beta isolated. Quorum W+R > N guarantees split-brain immunity.'
      );
    } else {
      onNotify('success', 'Partition Restored', 'Inter-rack link re-established. Sync completed.');
    }
  };

  const handleRunIntegrityScrub = async () => {
    setIsScrubbing(true);
    await new Promise(r => setTimeout(r, 600));
    const result = StorageEngine.runIntegrityScrub();
    setIsScrubbing(false);

    onNotify(
      'success',
      'Merkle Scrub & Self-Healing Finished',
      `Audited ${result.scannedChunks} shards across 8 nodes. Automatically repaired ${result.repairedChunks} corrupted replicas from healthy quorum peers!`
    );
  };

  const handleRebalance = async () => {
    setIsRebalancing(true);
    await new Promise(r => setTimeout(r, 500));
    StorageEngine.triggerRebalancer();
    setIsRebalancing(false);
    onNotify('info', 'Rebalance Evaluation', 'Disk utilization evaluated across racks. Chunks rebalanced.');
  };

  const currentSelectedObject = objects.find(o => o.id === selectedObjectId);
  const pendingJobs = repairJobs.filter(j => j.status === 'pending' || j.status === 'in_progress');
  const completedJobs = repairJobs.filter(j => j.status === 'completed');

  return (
    <div className="space-y-6">
      {/* Chaos Control Center Hero */}
      <div
        className={`rounded-3xl p-6 sm:p-8 transition-colors ${
          isDarkMode ? 'liquid-glass-dark' : 'liquid-glass-light'
        }`}
      >
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className={`flex items-center gap-2 text-xs font-mono font-bold ${isDarkMode ? 'text-amber-400' : 'text-amber-800'}`}>
              <Zap className="w-3.5 h-3.5" />
              <span>Chaos Engineering &amp; Durability Testbed</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight">Fault Injection &amp; Prioritized Repair</h2>
            <p className={`text-xs sm:text-sm max-w-2xl ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
              Validate system invariants under harsh real-world distributed failures: silent bit rot,
              catastrophic node crashes, split-brain network partitions, and observe prioritized recovery scheduling.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={handleRunIntegrityScrub}
              disabled={isScrubbing}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-600/20 transition-all cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${isScrubbing ? 'animate-spin' : ''}`} />
              <span>{isScrubbing ? 'Scrubbing Hashes...' : 'Run Merkle Scrub'}</span>
            </button>

            <button
              onClick={handleRebalance}
              disabled={isRebalancing}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold bg-cyan-600 hover:bg-cyan-500 text-white shadow-md shadow-cyan-600/20 transition-all cursor-pointer"
            >
              <Scale className={`w-4 h-4 ${isRebalancing ? 'animate-spin' : ''}`} />
              <span>{isRebalancing ? 'Equalizing Load...' : 'Trigger Rebalance'}</span>
            </button>

            {onOpenRecoveryWizard && (
              <button
                onClick={() => onOpenRecoveryWizard(selectedObjectId)}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white shadow-lg shadow-cyan-600/25 transition-all cursor-pointer"
                title="Launch Guided Quorum Anti-Entropy Recovery Wizard"
              >
                <Wrench className="w-4 h-4 text-white" />
                <span>Recovery Wizard</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* FEATURE: High-Priority Object SLA & Policy Manager */}
      <div
        className={`rounded-3xl p-6 sm:p-7 border transition-all ${
          isDarkMode ? 'liquid-glass-dark border-amber-500/30' : 'liquid-glass-light border-amber-400/50 shadow-sm'
        }`}
      >
        <div className={`flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b ${isDarkMode ? 'border-slate-800/60' : 'border-slate-200'}`}>
          <div className="flex items-center gap-3">
            <div className={`p-2.5 rounded-xl border ${isDarkMode ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' : 'bg-amber-100 text-amber-900 border-amber-300'}`}>
              <Flame className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold tracking-tight">High-Priority Object SLA Configuration</h3>
                <span className={`px-2 py-0.5 rounded-md text-[10px] font-mono border font-semibold ${
                  isDarkMode ? 'bg-amber-500/20 text-amber-300 border-amber-500/30' : 'bg-amber-100 text-amber-900 border-amber-300'
                }`}>
                  SLA Priority Queue
                </span>
              </div>
              <p className={`text-xs font-mono mt-0.5 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                Designate mission-critical objects. When nodes crash, high-priority objects are queued and rebuilt first.
              </p>
            </div>
          </div>
        </div>

        {/* Object Priority Grid */}
        <div className="mt-5 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {objects.map(obj => {
            const isHigh = obj.priority === 'high';
            return (
              <div
                key={obj.id}
                className={`p-4 rounded-2xl border text-xs font-mono transition-all flex flex-col justify-between ${
                  isHigh
                    ? isDarkMode
                      ? 'bg-amber-950/30 border-amber-500/50 shadow-md shadow-amber-950/20 ring-1 ring-amber-500/30'
                      : 'bg-amber-50/90 border-amber-400 shadow-sm text-slate-950 ring-1 ring-amber-400/40'
                    : isDarkMode
                    ? 'bg-slate-950/60 border-slate-800 text-slate-300'
                    : 'bg-white border-slate-300 text-slate-900 shadow-sm'
                }`}
              >
                <div>
                  <div className={`flex items-center justify-between pb-2 border-b ${isDarkMode ? 'border-slate-800/40' : 'border-slate-200'}`}>
                    <span className={`font-bold truncate max-w-[180px] ${isDarkMode ? 'text-slate-200' : 'text-slate-900'}`}>{obj.originalName}</span>
                    <span
                      className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                        isHigh
                          ? 'bg-amber-500 text-black shadow-sm font-bold'
                          : isDarkMode
                          ? 'bg-slate-800 text-slate-400 border border-slate-700'
                          : 'bg-slate-100 text-slate-700 border border-slate-300 font-semibold'
                      }`}
                    >
                      {isHigh ? 'P1 HIGH PRIORITY' : 'P2 STANDARD'}
                    </span>
                  </div>

                  <div className={`mt-2.5 space-y-1 text-[11px] ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                    <div className="flex justify-between">
                      <span>Bucket / Size:</span>
                      <span className={isDarkMode ? 'text-slate-300' : 'text-slate-800 font-medium'}>/{obj.bucket} · {(obj.sizeBytes / 1024).toFixed(1)} KB</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Resident Shards:</span>
                      <span className={isDarkMode ? 'text-slate-300' : 'text-slate-800 font-medium'}>{obj.chunks.length} Shards</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Failover SLA:</span>
                      <span className={isHigh ? (isDarkMode ? 'text-amber-400 font-semibold' : 'text-amber-800 font-bold') : isDarkMode ? 'text-slate-500' : 'text-slate-600'}>
                        {isHigh ? 'Immediate (< 5s)' : 'Standard FIFO'}
                      </span>
                    </div>
                  </div>
                </div>

                <div className={`mt-4 pt-3 border-t flex items-center justify-between ${isDarkMode ? 'border-slate-800/40' : 'border-slate-200'}`}>
                  <span className={`text-[10px] ${isDarkMode ? 'text-slate-500' : 'text-slate-600 font-medium'}`}>
                    {isHigh ? 'Repair order: #1 (Head)' : 'Repair order: Standard'}
                  </span>
                  <button
                    onClick={() => handleTogglePriority(obj)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                      isHigh
                        ? isDarkMode
                          ? 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 shadow-sm'
                        : 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-black shadow-md font-bold'
                    }`}
                  >
                    {isHigh ? (
                      <>
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>Downgrade to P2</span>
                      </>
                    ) : (
                      <>
                        <Flame className="w-3.5 h-3.5" />
                        <span>Promote to P1</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Node Crash Simulator & Partition Controls */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Module 1: Node Failure Simulation with Prioritized Failover */}
        <div
          className={`rounded-3xl p-6 border transition-all ${
            isDarkMode ? 'liquid-glass-dark border-rose-500/30' : 'liquid-glass-light border-rose-300 shadow-sm'
          }`}
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2.5 rounded-xl bg-rose-500/10 text-rose-500 dark:text-rose-400 border border-rose-500/20">
              <Server className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold tracking-tight text-slate-900 dark:text-white">Catastrophic Node Crash Simulation</h3>
              <p className="text-[11px] text-slate-600 dark:text-slate-400 font-mono">Kill a storage node to test priority failover repair</p>
            </div>
          </div>

          <div className="space-y-4 text-xs font-mono">
            <div>
              <label className="block text-slate-800 dark:text-slate-300 font-semibold mb-1">Target Storage Node</label>
              <select
                value={selectedNodeToCrash}
                onChange={e => setSelectedNodeToCrash(e.target.value)}
                className={`w-full p-2.5 rounded-xl border outline-none font-medium ${
                  isDarkMode ? 'bg-slate-900 border-slate-700 text-slate-200' : 'bg-white border-slate-300 text-slate-900 shadow-sm'
                }`}
              >
                {nodes.map(n => (
                  <option key={n.id} value={n.id}>
                    {n.name} [{n.rack}] ({n.status.toUpperCase()})
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                onClick={handleCrashNode}
                className="py-2.5 px-3 rounded-xl font-semibold bg-rose-600 hover:bg-rose-500 text-white shadow-md shadow-rose-600/20 transition-all flex items-center justify-center gap-2"
              >
                <Zap className="w-4 h-4" />
                <span>Crash Node</span>
              </button>

              <button
                onClick={handleReviveAllNodes}
                className={`py-2.5 px-3 rounded-xl font-semibold transition-all flex items-center justify-center gap-2 border ${
                  isDarkMode
                    ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-800 border-slate-300 shadow-sm'
                }`}
              >
                <RotateCcw className="w-4 h-4" />
                <span>Revive All Nodes</span>
              </button>
            </div>

            <div className={`p-3 rounded-xl border text-[11px] ${
              isDarkMode
                ? 'bg-slate-950/60 border-slate-800 text-slate-400'
                : 'bg-slate-100 border-slate-200 text-slate-700'
            }`}>
              When a node crashes, affected shards are instantly scheduled into the repair pipeline.
              Objects with <span className="text-amber-600 dark:text-amber-400 font-bold">P1 High-Priority</span> jump to the front and repair first.
            </div>
          </div>
        </div>

        {/* Module 2: Silent Bit Rot Injection */}
        <div
          className={`rounded-3xl p-6 border transition-all ${
            isDarkMode ? 'liquid-glass-dark border-amber-500/30' : 'liquid-glass-light border-amber-300 shadow-sm'
          }`}
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20">
              <AlertOctagon className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold tracking-tight text-slate-900 dark:text-white">Silent Bit Rot Injection</h3>
              <p className="text-[11px] text-slate-600 dark:text-slate-400 font-mono">Invert storage blocks without updating metadata</p>
            </div>
          </div>

          <div className="space-y-4 text-xs font-mono">
            <div>
              <label className="block text-slate-800 dark:text-slate-300 font-semibold mb-1">Target Object</label>
              <select
                value={selectedObjectId}
                onChange={e => setSelectedObjectId(e.target.value)}
                className={`w-full p-2.5 rounded-xl border outline-none font-medium ${
                  isDarkMode ? 'bg-slate-900 border-slate-700 text-slate-200' : 'bg-white border-slate-300 text-slate-900 shadow-sm'
                }`}
              >
                {objects.map(o => (
                  <option key={o.id} value={o.id}>
                    {o.originalName} ({o.priority === 'high' ? 'P1 HIGH' : 'P2'}) - {o.chunks.length} shards
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-800 dark:text-slate-300 font-semibold mb-1">Shard Index to Corrupt</label>
              <select
                value={selectedChunkIndex}
                onChange={e => setSelectedChunkIndex(Number(e.target.value))}
                className={`w-full p-2.5 rounded-xl border outline-none font-medium ${
                  isDarkMode ? 'bg-slate-900 border-slate-700 text-slate-200' : 'bg-white border-slate-300 text-slate-900 shadow-sm'
                }`}
              >
                {currentSelectedObject?.chunks.map(c => (
                  <option key={c.chunkIndex} value={c.chunkIndex}>
                    {c.isParity ? `Parity Shard #${c.chunkIndex}` : `Data Shard #${c.chunkIndex}`}{' '}
                    {c.isCorrupted ? '[CORRUPTED]' : '[HEALTHY]'}
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={handleInjectBitRot}
              className="w-full py-2.5 px-4 rounded-xl font-semibold bg-amber-600 hover:bg-amber-500 text-white shadow-md shadow-amber-600/20 transition-all flex items-center justify-center gap-2"
            >
              <AlertOctagon className="w-4 h-4" />
              <span>Corrupt Checksum on Shard</span>
            </button>
          </div>
        </div>
      </div>

      {/* Module 3: Network Partition (Split-Brain) Simulation */}
      <div
        className={`rounded-3xl p-6 border transition-all ${
          isDarkMode ? 'liquid-glass-dark border-blue-500/30' : 'liquid-glass-light border-blue-300 shadow-sm'
        }`}
      >
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2.5 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
            <Split className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold tracking-tight text-slate-900 dark:text-white">Inter-Rack Network Partition (Split-Brain Defense)</h3>
            <p className="text-[11px] text-slate-600 dark:text-slate-400 font-mono">Test CAP theorem consistency &amp; partition isolation</p>
          </div>
        </div>

        <div className="space-y-4 text-xs font-mono">
          <div
            className={`p-4 rounded-2xl border ${
              isPartitionActive
                ? isDarkMode
                  ? 'bg-amber-950/20 border-amber-700/60 text-amber-200'
                  : 'bg-amber-50 border-amber-300 text-amber-950 shadow-sm'
                : isDarkMode
                ? 'bg-slate-950/50 border-slate-800 text-slate-300'
                : 'bg-slate-100 border-slate-200 text-slate-800'
            }`}
          >
            <div className="flex items-center justify-between font-semibold mb-2">
              <span>Partition Status</span>
              <span className={isPartitionActive ? 'text-amber-600 dark:text-amber-400 font-bold' : 'text-emerald-600 dark:text-emerald-400 font-bold'}>
                {isPartitionActive ? 'ACTIVE (SEVERED)' : 'HEALTHY (MESHED)'}
              </span>
            </div>
            <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
              {isPartitionActive
                ? 'Inter-rack switch severed. Rack-Beta (Zone us-east-1b) is unreachable. Writes requiring W=2 quorum remain available on Rack-Alpha, but cross-rack consensus rejects split-brain mutations.'
                : 'All inter-rack trunk links operational. Low-latency heartbeat and cross-zone replication nominal.'}
            </p>
          </div>

          <button
            onClick={handleTogglePartition}
            className={`w-full py-2.5 px-4 rounded-xl font-semibold text-xs transition-all flex items-center justify-center gap-2 ${
              isPartitionActive
                ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-600/20'
                : 'bg-rose-600 hover:bg-rose-500 text-white shadow-md shadow-rose-600/20'
            }`}
          >
            <Split className="w-4 h-4" />
            <span>{isPartitionActive ? 'Heal Network Partition' : 'Sever Inter-Rack Link (Inject Partition)'}</span>
          </button>
        </div>
      </div>

      {/* Prioritized Self-Healing Pipeline Log */}
      <div
        className={`rounded-3xl p-6 sm:p-8 transition-colors ${
          isDarkMode ? 'liquid-glass-dark' : 'liquid-glass-light'
        }`}
      >
        <div className={`flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b ${
          isDarkMode ? 'border-slate-800/40' : 'border-slate-200'
        }`}>
          <div className="flex items-center gap-2.5">
            <Wrench className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <h3 className="text-base font-bold tracking-tight text-slate-900 dark:text-white">Prioritized Self-Healing Pipeline &amp; Repair Queue</h3>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleTriggerPrioritizedRecovery}
              disabled={isRecovering}
              className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white shadow-md shadow-emerald-500/20 transition-all"
            >
              <Play className={`w-3.5 h-3.5 ${isRecovering ? 'animate-spin' : ''}`} />
              <span>{isRecovering ? 'Healing Shards...' : 'Execute Prioritized Recovery'}</span>
            </button>
          </div>
        </div>

        {/* Active Pending Repair Queue */}
        <div className="mt-5 space-y-3">
          <h4 className="text-xs font-mono text-slate-600 dark:text-slate-400 flex items-center justify-between">
            <span>Active Failover Queue ({pendingJobs.length} Shards Pending)</span>
            <span className="text-[11px] text-amber-600 dark:text-amber-400 font-semibold">High-Priority (P1) jobs execute first</span>
          </h4>

          {pendingJobs.length === 0 ? (
            <div className={`p-5 text-center text-xs font-mono rounded-2xl border ${
              isDarkMode
                ? 'bg-slate-950/40 border-slate-800 text-slate-400'
                : 'bg-slate-100 border-slate-200 text-slate-600'
            }`}>
              No pending repair jobs. Cluster replicas are 100% synchronized and healthy.
            </div>
          ) : (
            pendingJobs.map((job, idx) => {
              const isP1 = job.priority === 'high';
              return (
                <div
                  key={job.id}
                  className={`p-3.5 rounded-2xl border text-xs font-mono transition-all ${
                    isP1
                      ? isDarkMode
                        ? 'bg-amber-950/30 border-amber-600/60 shadow-md shadow-amber-950/20'
                        : 'bg-amber-50/90 border-amber-300 text-slate-900 shadow-sm'
                      : isDarkMode
                      ? 'bg-slate-950/60 border-slate-800 text-slate-300'
                      : 'bg-white border-slate-200 text-slate-800 shadow-sm'
                  }`}
                >
                  <div className={`flex items-center justify-between pb-2 border-b ${
                    isDarkMode ? 'border-slate-800/40' : 'border-slate-200'
                  }`}>
                    <div className="flex items-center gap-2">
                      <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                        isDarkMode ? 'bg-slate-800 text-slate-300' : 'bg-slate-200 text-slate-700'
                      }`}>
                        #{idx + 1}
                      </span>
                      <span className="font-bold text-slate-900 dark:text-slate-200">{job.objectKey}</span>
                      <span className="text-slate-500 dark:text-slate-400">(Shard #{job.chunkIndex})</span>
                    </div>

                    <span
                      className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                        isP1
                          ? 'bg-amber-500 text-black shadow-sm'
                          : 'bg-blue-500/20 text-blue-700 dark:text-blue-300 border border-blue-500/30'
                      }`}
                    >
                      {isP1 ? 'P1 HIGH PRIORITY' : 'P2 STANDARD'}
                    </span>
                  </div>

                  <div className="mt-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-[11px] text-slate-600 dark:text-slate-400">
                    <div>
                      Target Node: <span className="text-cyan-700 dark:text-cyan-400 font-semibold">{job.targetNodeId}</span> · Reason:{' '}
                      <span className="uppercase">{job.reason}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-emerald-600 dark:text-emerald-400 capitalize font-medium">{job.status}</span>
                      <div className={`w-24 h-2 rounded-full overflow-hidden ${
                        isDarkMode ? 'bg-slate-800' : 'bg-slate-200'
                      }`}>
                        <div
                          className="h-full bg-emerald-500 transition-all duration-300"
                          style={{ width: `${job.progressPercent}%` }}
                        />
                      </div>
                      <span className="tabular-nums font-semibold text-slate-800 dark:text-slate-200">{job.progressPercent}%</span>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Recently Completed Jobs History */}
        {completedJobs.length > 0 && (
          <div className={`mt-6 pt-5 border-t space-y-2.5 ${
            isDarkMode ? 'border-slate-800/40' : 'border-slate-200'
          }`}>
            <h4 className="text-xs font-mono text-slate-600 dark:text-slate-400">Recently Healed Shards</h4>
            <div className="space-y-2">
              {completedJobs.slice(0, 4).map(job => (
                <div
                  key={job.id}
                  className={`p-3 rounded-xl border text-xs font-mono flex items-center justify-between ${
                    isDarkMode ? 'bg-slate-950/40 border-slate-800 text-slate-400' : 'bg-slate-50 border-slate-200 text-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                    <span className="text-slate-800 dark:text-slate-300 font-medium">
                      Restored {job.objectKey} (Shard #{job.chunkIndex}) to {job.targetNodeId}
                    </span>
                  </div>
                  <span className="px-2 py-0.5 rounded-md text-[10px] bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 border border-emerald-500/30 font-semibold">
                    {job.priority === 'high' ? 'P1 HEALED' : 'HEALED'}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
