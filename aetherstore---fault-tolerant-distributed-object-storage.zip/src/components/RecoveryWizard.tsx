import { useState, useEffect, useMemo } from 'react';
import {
  Wrench,
  CheckCircle2,
  AlertTriangle,
  ShieldCheck,
  ShieldAlert,
  Server,
  Database,
  ArrowRight,
  ArrowLeft,
  RefreshCw,
  Download,
  FileText,
  Lock,
  Flame,
  Layers,
  History,
  Terminal,
  Activity,
  Zap,
  Check,
  X,
  Play,
  RotateCcw,
} from 'lucide-react';
import { StorageObject, StorageNode, ObjectChunk, DurabilityPolicyType, ObjectVersion } from '../types/storage';
import { StorageEngine, DURABILITY_POLICIES } from '../services/storageEngine';

interface RecoveryWizardProps {
  isOpen: boolean;
  onClose: () => void;
  objects: StorageObject[];
  nodes: StorageNode[];
  initialObjectId?: string | null;
  isDarkMode: boolean;
  onNotify: (type: 'success' | 'warning' | 'error' | 'info', title: string, msg: string) => void;
  onViewInAuditLogs?: () => void;
}

type WizardStep = 1 | 2 | 3 | 4 | 5;

interface NodeAuditResult {
  nodeId: string;
  nodeName: string;
  rack: string;
  isOnline: boolean;
  chunkIndex: number;
  expectedHash: string;
  actualHash: string;
  isCorrupted: boolean;
  isParity: boolean;
  sizeBytes: number;
}

export function RecoveryWizard({
  isOpen,
  onClose,
  objects,
  nodes,
  initialObjectId,
  isDarkMode,
  onNotify,
  onViewInAuditLogs,
}: RecoveryWizardProps) {
  const [currentStep, setCurrentStep] = useState<WizardStep>(1);
  const [selectedObjectId, setSelectedObjectId] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterHealth, setFilterHealth] = useState<'all' | 'degraded'>('all');

  // Step 2 & 3: Quorum Audit State
  const [isAuditing, setIsAuditing] = useState(false);
  const [auditResults, setAuditResults] = useState<NodeAuditResult[]>([]);
  const [selectedChunkIndex, setSelectedChunkIndex] = useState<number>(0);
  const [recoveryStrategy, setRecoveryStrategy] = useState<'quorum_repair' | 'donor_node' | 'version_restore'>('quorum_repair');
  const [selectedDonorNodeId, setSelectedDonorNodeId] = useState<string>('');
  const [selectedTargetVersion, setSelectedTargetVersion] = useState<number>(1);

  // Step 4: Execution Progress
  const [isExecuting, setIsExecuting] = useState(false);
  const [execProgress, setExecProgress] = useState(0);
  const [execLogs, setExecLogs] = useState<string[]>([]);
  const [executionFinished, setExecutionFinished] = useState(false);

  // Sync initial object on open
  useEffect(() => {
    if (isOpen) {
      if (initialObjectId && objects.some(o => o.id === initialObjectId)) {
        setSelectedObjectId(initialObjectId);
      } else {
        const firstCorrupt = objects.find(o => o.health === 'corrupt' || o.health === 'degraded' || o.chunks.some(c => c.isCorrupted));
        if (firstCorrupt) {
          setSelectedObjectId(firstCorrupt.id);
        } else if (objects.length > 0) {
          setSelectedObjectId(objects[0].id);
        }
      }
      setCurrentStep(1);
      setExecProgress(0);
      setExecLogs([]);
      setExecutionFinished(false);
    }
  }, [isOpen, initialObjectId, objects]);

  const targetObject = useMemo(() => {
    return objects.find(o => o.id === selectedObjectId) || null;
  }, [objects, selectedObjectId]);

  const corruptChunksCount = useMemo(() => {
    if (!targetObject) return 0;
    return targetObject.chunks.filter(c => c.isCorrupted).length;
  }, [targetObject]);

  // Filtered objects for Step 1
  const selectableObjects = useMemo(() => {
    return objects.filter(obj => {
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch = !q || obj.originalName.toLowerCase().includes(q) || obj.key.toLowerCase().includes(q);
      const isDegraded = obj.health === 'corrupt' || obj.health === 'degraded' || obj.chunks.some(c => c.isCorrupted);
      const matchesHealth = filterHealth === 'all' || isDegraded;
      return matchesSearch && matchesHealth;
    });
  }, [objects, searchQuery, filterHealth]);

  // Run multi-node hash audit (Step 2)
  const runQuorumAudit = () => {
    if (!targetObject) return;
    setIsAuditing(true);

    setTimeout(() => {
      const results: NodeAuditResult[] = [];
      targetObject.chunks.forEach(chunk => {
        chunk.nodeIds.forEach(nid => {
          const node = nodes.find(n => n.id === nid);
          const isNodeCrashed = !node || node.status === 'crashed';
          const isBitRot = chunk.isCorrupted;

          results.push({
            nodeId: nid,
            nodeName: node ? node.name : `Node-${nid}`,
            rack: node ? node.rack : 'Unknown',
            isOnline: !isNodeCrashed,
            chunkIndex: chunk.chunkIndex,
            expectedHash: chunk.sha256Hash,
            actualHash: isBitRot ? chunk.actualHash || 'e4b9f2...corrupt' : chunk.sha256Hash,
            isCorrupted: isBitRot,
            isParity: !!chunk.isParity,
            sizeBytes: chunk.sizeBytes,
          });
        });
      });

      setAuditResults(results);

      // Select first corrupted chunk or chunk 0
      const firstCorrupt = targetObject.chunks.find(c => c.isCorrupted);
      if (firstCorrupt) {
        setSelectedChunkIndex(firstCorrupt.chunkIndex);
      } else {
        setSelectedChunkIndex(0);
      }

      // Pick healthy donor node
      const healthyResult = results.find(r => !r.isCorrupted && r.isOnline);
      if (healthyResult) {
        setSelectedDonorNodeId(healthyResult.nodeId);
      }

      // Default version if versions exist
      if (targetObject.versions && targetObject.versions.length > 0) {
        setSelectedTargetVersion(targetObject.versions[0].version);
      }

      setIsAuditing(false);
    }, 400);
  };

  // Inject bit-rot simulation for testing
  const handleSimulateBitRot = (chunkIdx: number = 0) => {
    if (!targetObject) return;
    const node = targetObject.chunks[chunkIdx]?.nodeIds[0] || 'node-1';
    StorageEngine.injectBitRot(targetObject.id, chunkIdx, node);
    onNotify(
      'warning',
      'Bit-Rot Simulated',
      `Injected silent bit-rot on Chunk #${chunkIdx} of "${targetObject.originalName}". Quorum divergence triggered.`
    );
    runQuorumAudit();
  };

  // Step 4: Execute Quorum Repair Stream
  const handleExecuteRecovery = () => {
    if (!targetObject) return;
    setIsExecuting(true);
    setExecProgress(10);
    setExecLogs([`[0.00s] Initializing distributed recovery session for object: ${targetObject.key}`]);

    const policy = DURABILITY_POLICIES[targetObject.policy];

    setTimeout(() => {
      setExecProgress(30);
      setExecLogs(prev => [
        ...prev,
        `[0.40s] Acquiring distributed lease locks across ${policy.name} quorum replicas (W=${policy.writeQuorum}, R=${policy.readQuorum})`,
        `[0.65s] Evaluating Merkle tree root digests: 2/3 replicas verify canonical SHA-256`,
      ]);
    }, 450);

    setTimeout(() => {
      setExecProgress(65);
      if (recoveryStrategy === 'version_restore') {
        setExecLogs(prev => [
          ...prev,
          `[1.00s] Fetching cryptographic baseline manifest for Version v${selectedTargetVersion}...`,
          `[1.25s] Re-aligning block pointers and resetting replica etag to version snapshot...`,
        ]);
      } else {
        const donor = nodes.find(n => n.id === selectedDonorNodeId);
        const donorName = donor ? `${donor.name} [${donor.rack}]` : 'Canonical Quorum Peer';
        setExecLogs(prev => [
          ...prev,
          `[1.00s] Establishing secure TLS 1.3 bitstream transport with donor: ${donorName}`,
          `[1.20s] Streaming pristine payload blocks for Chunk #${selectedChunkIndex}...`,
          `[1.40s] Re-computing SHA-256 digest on restored buffer. Zero corruption confirmed.`,
        ]);
      }
    }, 950);

    setTimeout(() => {
      setExecProgress(90);
      setExecLogs(prev => [
        ...prev,
        `[1.65s] Committing anti-entropy write to target node storage disks...`,
        `[1.85s] Emitting immutable cluster audit event and releasing lease locks...`,
      ]);
    }, 1450);

    setTimeout(() => {
      // Perform actual storage engine repair
      if (recoveryStrategy === 'version_restore') {
        StorageEngine.restoreObjectVersion(targetObject.id, selectedTargetVersion);
      } else {
        StorageEngine.repairObjectChunk(targetObject.id, selectedChunkIndex, selectedDonorNodeId);
      }

      setExecProgress(100);
      setExecutionFinished(true);
      setIsExecuting(false);
      setExecLogs(prev => [
        ...prev,
        `[2.05s] [SUCCESS] Quorum consensus 100% synchronized. Object health restored to HEALTHY.`,
      ]);

      onNotify(
        'success',
        'Recovery Completed',
        `Successfully restored "${targetObject.originalName}" using quorum consensus results.`
      );
    }, 1900);
  };

  // Download recovery certificate
  const handleDownloadCertificate = () => {
    if (!targetObject) return;
    const cert = {
      certificateType: 'AetherStore Quorum Recovery & Anti-Entropy Attestation',
      recoveryId: 'rec_' + Math.random().toString(36).slice(2, 10),
      timestamp: new Date().toISOString(),
      targetObject: {
        id: targetObject.id,
        key: targetObject.key,
        bucket: targetObject.bucket,
        policy: targetObject.policy,
        version: targetObject.version,
        sizeBytes: targetObject.sizeBytes,
      },
      recoveryStrategy,
      selectedChunkIndex,
      donorNodeId: selectedDonorNodeId,
      quorumSummary: {
        totalReplicas: targetObject.chunks[selectedChunkIndex]?.nodeIds.length || 3,
        consensusStatus: '100% Quorum Agreement Verified',
        sha256Digest: targetObject.chunks[selectedChunkIndex]?.sha256Hash,
      },
      auditSignatures: nodes.slice(0, 3).map(n => ({
        node: n.name,
        rack: n.rack,
        attestation: 'Merkle Digest Verified Matched',
      })),
    };

    const blob = new Blob([JSON.stringify(cert, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `recovery_certificate_${targetObject.originalName}_${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    onNotify('success', 'Certificate Exported', 'Downloaded cryptographic recovery attestation document.');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className={`w-full max-w-4xl max-h-[92vh] flex flex-col rounded-3xl border shadow-2xl overflow-hidden transition-all ${
          isDarkMode ? 'bg-slate-950 border-slate-800 text-slate-100' : 'bg-white border-slate-300 text-slate-900'
        }`}
      >
        {/* Wizard Header Bar */}
        <div
          className={`p-5 sm:p-6 border-b flex items-center justify-between gap-4 shrink-0 transition-colors ${
            isDarkMode ? 'border-slate-800 bg-slate-900/40 text-slate-100' : 'border-slate-200 bg-slate-50 text-slate-900'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-600 to-blue-600 text-white flex items-center justify-center shadow-lg shadow-cyan-600/25">
              <Wrench className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold tracking-tight">Interactive Recovery Wizard</h2>
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-semibold border ${
                    isDarkMode
                      ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30'
                      : 'bg-cyan-100 text-cyan-800 border-cyan-300'
                  }`}
                >
                  Step {currentStep} of 5
                </span>
              </div>
              <p className={`text-xs font-mono mt-0.5 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                Restore corrupted data segments and reconcile divergent object versions via Quorum Consensus
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className={`p-2 rounded-xl transition-colors cursor-pointer ${
              isDarkMode
                ? 'text-slate-400 hover:text-slate-100 hover:bg-slate-800'
                : 'text-slate-500 hover:text-slate-900 hover:bg-slate-200'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Navigation Ribbon */}
        <div
          className={`px-6 py-3 border-b overflow-x-auto shrink-0 font-mono text-xs transition-colors ${
            isDarkMode ? 'border-slate-800/80 bg-slate-950/60' : 'border-slate-200 bg-slate-100'
          }`}
        >
          <div className="flex items-center justify-between min-w-[620px] gap-2">
            {[
              { num: 1, title: 'Scope & Target' },
              { num: 2, title: 'Quorum Read Audit' },
              { num: 3, title: 'Consensus Resolution' },
              { num: 4, title: 'Anti-Entropy Repair' },
              { num: 5, title: 'Attestation & Proof' },
            ].map(step => {
              const isPast = currentStep > step.num;
              const isCurrent = currentStep === step.num;

              return (
                <div key={step.num} className="flex items-center gap-2">
                  <div
                    className={`flex items-center justify-center w-6 h-6 rounded-full text-[11px] font-bold transition-all ${
                      isPast
                        ? 'bg-emerald-600 text-white'
                        : isCurrent
                        ? isDarkMode
                          ? 'bg-cyan-500 text-white ring-4 ring-cyan-500/20'
                          : 'bg-cyan-600 text-white ring-4 ring-cyan-200'
                        : isDarkMode
                        ? 'bg-slate-800 text-slate-400'
                        : 'bg-slate-300 text-slate-700'
                    }`}
                  >
                    {isPast ? <Check className="w-3.5 h-3.5 stroke-[3]" /> : step.num}
                  </div>
                  <span
                    className={`text-[11px] ${
                      isCurrent
                        ? isDarkMode
                          ? 'font-bold text-cyan-300'
                          : 'font-bold text-cyan-800'
                        : isPast
                        ? isDarkMode
                          ? 'text-slate-200'
                          : 'text-slate-800 font-semibold'
                        : isDarkMode
                        ? 'text-slate-500'
                        : 'text-slate-600'
                    }`}
                  >
                    {step.title}
                  </span>
                  {step.num < 5 && (
                    <div className={`w-6 h-0.5 mx-1 ${isDarkMode ? 'bg-slate-800' : 'bg-slate-300'}`} />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Wizard Body (Scrollable) */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-7 space-y-6">
          {/* STEP 1: Select Target & Incident Scope */}
          {currentStep === 1 && (
            <div className="space-y-5 animate-in fade-in duration-200">
              <div className="space-y-1">
                <h3 className={`text-base font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                  Step 1: Select Target Object &amp; Incident Scope
                </h3>
                <p className={`text-xs font-mono ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  Identify the object exhibiting bit-rot checksum mismatch, replica divergence, or degraded quorum.
                </p>
              </div>

              {/* Filters */}
              <div className="flex flex-col sm:flex-row gap-3">
                <input
                  type="text"
                  placeholder="Search object by key or name..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className={`flex-1 p-2.5 text-xs rounded-xl border outline-none font-mono ${
                    isDarkMode
                      ? 'bg-slate-900 border-slate-700 text-slate-100 placeholder:text-slate-500'
                      : 'bg-white border-slate-300 text-slate-900 placeholder:text-slate-400'
                  }`}
                />

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setFilterHealth('all')}
                    className={`px-3 py-2 text-xs rounded-xl font-mono border transition-all cursor-pointer ${
                      filterHealth === 'all'
                        ? isDarkMode
                          ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 font-semibold'
                          : 'bg-cyan-100 text-cyan-900 border-cyan-400 font-bold shadow-sm'
                        : isDarkMode
                        ? 'bg-slate-900/60 border-slate-800 text-slate-400'
                        : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    All Objects ({objects.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setFilterHealth('degraded')}
                    className={`px-3 py-2 text-xs rounded-xl font-mono border transition-all flex items-center gap-1.5 cursor-pointer ${
                      filterHealth === 'degraded'
                        ? isDarkMode
                          ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 font-semibold'
                          : 'bg-rose-100 text-rose-900 border-rose-400 font-bold shadow-sm'
                        : isDarkMode
                        ? 'bg-slate-900/60 border-slate-800 text-slate-400'
                        : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <AlertTriangle className={`w-3.5 h-3.5 ${isDarkMode ? 'text-rose-400' : 'text-rose-600'}`} />
                    <span>Degraded / Corrupted</span>
                  </button>
                </div>
              </div>

              {/* Objects List */}
              <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
                {selectableObjects.length === 0 ? (
                  <div className={`py-12 text-center text-xs font-mono ${isDarkMode ? 'text-slate-500' : 'text-slate-600'}`}>
                    No objects match the current filter.
                  </div>
                ) : (
                  selectableObjects.map(obj => {
                    const isSelected = selectedObjectId === obj.id;
                    const isCorrupted = obj.health === 'corrupt' || obj.chunks.some(c => c.isCorrupted);

                    return (
                      <div
                        key={obj.id}
                        onClick={() => setSelectedObjectId(obj.id)}
                        className={`p-3.5 rounded-2xl border text-xs font-mono transition-all cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                          isSelected
                            ? isDarkMode
                              ? 'bg-cyan-950/40 border-cyan-500 shadow-md ring-1 ring-cyan-500/30'
                              : 'bg-cyan-50 border-cyan-500 ring-2 ring-cyan-400 shadow-md'
                            : isCorrupted
                            ? isDarkMode
                              ? 'bg-rose-950/20 border-rose-900/60 hover:bg-rose-950/30'
                              : 'bg-rose-50/80 border-rose-300 hover:bg-rose-100/60'
                            : isDarkMode
                            ? 'bg-slate-900/40 border-slate-800 hover:bg-slate-900'
                            : 'bg-white border-slate-200 hover:bg-slate-50 shadow-sm'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                              isCorrupted
                                ? isDarkMode
                                  ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                                  : 'bg-rose-100 text-rose-700 border border-rose-300'
                                : isDarkMode
                                ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30'
                                : 'bg-cyan-100 text-cyan-800 border border-cyan-300'
                            }`}
                          >
                            <FileText className="w-4 h-4" />
                          </div>

                          <div>
                            <div className="font-semibold flex items-center gap-2">
                              <span className={isDarkMode ? 'text-slate-200' : 'text-slate-900'}>{obj.originalName}</span>
                              <span className={`text-[10px] ${isDarkMode ? 'text-slate-500' : 'text-slate-600'}`}>/{obj.bucket}</span>
                              {obj.versions && obj.versions.length > 1 && (
                                <span
                                  className={`px-1.5 py-0.2 rounded text-[9px] font-bold border ${
                                    isDarkMode
                                      ? 'bg-purple-500/20 text-purple-300 border-purple-500/40'
                                      : 'bg-purple-100 text-purple-800 border-purple-300'
                                  }`}
                                >
                                  v{obj.version} ({obj.versions.length} versions)
                                </span>
                              )}
                            </div>
                            <div className={`text-[11px] flex items-center gap-2 mt-0.5 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                              <span>{(obj.sizeBytes / 1024).toFixed(1)} KB</span>
                              <span>·</span>
                              <span>{DURABILITY_POLICIES[obj.policy]?.name || obj.policy}</span>
                              <span>·</span>
                              <span>{obj.chunks.length} shards</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          {isCorrupted ? (
                            <span
                              className={`px-2 py-0.5 rounded-md text-[10px] font-bold flex items-center gap-1 animate-pulse border ${
                                isDarkMode
                                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                                  : 'bg-rose-100 text-rose-800 border-rose-300'
                              }`}
                            >
                              <ShieldAlert className="w-3 h-3" />
                              <span>Bit-Rot Detected</span>
                            </span>
                          ) : (
                            <span
                              className={`px-2 py-0.5 rounded-md text-[10px] font-bold flex items-center gap-1 border ${
                                isDarkMode
                                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                                  : 'bg-emerald-100 text-emerald-800 border-emerald-300'
                              }`}
                            >
                              <CheckCircle2 className="w-3 h-3" />
                              <span>Nominal (Healthy)</span>
                            </span>
                          )}

                          <input
                            type="radio"
                            name="selectedObject"
                            checked={isSelected}
                            onChange={() => setSelectedObjectId(obj.id)}
                            className="accent-cyan-600 w-4 h-4 cursor-pointer"
                          />
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Simulation Helper Box for Testing */}
              {targetObject && corruptChunksCount === 0 && (
                <div
                  className={`p-4 rounded-2xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs font-mono ${
                    isDarkMode ? 'bg-amber-950/20 border-amber-500/30' : 'bg-amber-50 border-amber-300 shadow-sm'
                  }`}
                >
                  <div className="space-y-1">
                    <div className={`flex items-center gap-1.5 font-bold ${isDarkMode ? 'text-amber-300' : 'text-amber-900'}`}>
                      <AlertTriangle className="w-4 h-4 text-amber-500" />
                      <span>Currently Healthy Object Selected</span>
                    </div>
                    <p className={`text-[11px] ${isDarkMode ? 'text-slate-400' : 'text-slate-700'}`}>
                      Want to experience how the recovery wizard heals bit-rot? You can simulate silent bit corruption on
                      Chunk #0 with one click.
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleSimulateBitRot(0)}
                    className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-amber-600 hover:bg-amber-700 text-white shadow-sm transition-all cursor-pointer whitespace-nowrap"
                  >
                    Simulate Bit-Rot Corruption
                  </button>
                </div>
              )}
            </div>
          )}

          {/* STEP 2: Quorum Read & Multi-Node Hash Audit */}
          {currentStep === 2 && targetObject && (
            <div className="space-y-5 animate-in fade-in duration-200">
              <div
                className={`flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b ${
                  isDarkMode ? 'border-slate-800' : 'border-slate-200'
                }`}
              >
                <div className="space-y-0.5">
                  <h3 className={`text-base font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    Step 2: Quorum Read &amp; Multi-Node Hash Audit
                  </h3>
                  <p className={`text-xs font-mono ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                    Auditing SHA-256 digests across all storage node replicas for "{targetObject.originalName}"
                  </p>
                </div>

                <button
                  type="button"
                  onClick={runQuorumAudit}
                  disabled={isAuditing}
                  className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                    isDarkMode
                      ? 'bg-slate-800 hover:bg-slate-700 text-cyan-300 border-slate-700'
                      : 'bg-white hover:bg-slate-100 text-cyan-800 border-slate-300 shadow-sm'
                  }`}
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isAuditing ? 'animate-spin' : ''}`} />
                  <span>Re-audit Replicas</span>
                </button>
              </div>

              {/* Shard Node Matrix */}
              <div className="overflow-x-auto rounded-2xl border border-slate-200 dark:border-slate-800">
                <table className="w-full text-left text-xs font-mono">
                  <thead>
                    <tr
                      className={`text-[10px] uppercase font-bold border-b ${
                        isDarkMode ? 'border-slate-800 text-slate-400 bg-slate-900/50' : 'border-slate-200 text-slate-700 bg-slate-100'
                      }`}
                    >
                      <th className="py-2.5 px-3">Shard</th>
                      <th className="py-2.5 px-3">Storage Node</th>
                      <th className="py-2.5 px-3">Rack Domain</th>
                      <th className="py-2.5 px-3">Expected SHA-256</th>
                      <th className="py-2.5 px-3">Actual Computed Hash</th>
                      <th className="py-2.5 px-3">Integrity Verdict</th>
                    </tr>
                  </thead>
                  <tbody className={`divide-y ${isDarkMode ? 'divide-slate-800' : 'divide-slate-200'}`}>
                    {auditResults.map((res, i) => (
                      <tr
                        key={i}
                        className={`transition-colors ${
                          res.isCorrupted
                            ? isDarkMode
                              ? 'bg-rose-950/20'
                              : 'bg-rose-50'
                            : !res.isOnline
                            ? isDarkMode
                              ? 'bg-amber-950/20'
                              : 'bg-amber-50'
                            : isDarkMode
                            ? 'hover:bg-slate-900/30'
                            : 'hover:bg-slate-50'
                        }`}
                      >
                        <td className={`py-3 px-3 font-semibold ${isDarkMode ? 'text-slate-200' : 'text-slate-900'}`}>
                          {res.isParity ? `Parity #${res.chunkIndex}` : `Chunk #${res.chunkIndex}`}
                        </td>
                        <td className="py-3 px-3 flex items-center gap-1.5">
                          <Server className={`w-3.5 h-3.5 ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`} />
                          <span className={isDarkMode ? 'text-slate-200' : 'text-slate-800 font-medium'}>{res.nodeName}</span>
                        </td>
                        <td className={`py-3 px-3 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>{res.rack}</td>
                        <td className={`py-3 px-3 font-mono text-[11px] font-semibold ${isDarkMode ? 'text-emerald-400' : 'text-emerald-700'}`}>
                          {res.expectedHash.slice(0, 12)}...
                        </td>
                        <td className="py-3 px-3 font-mono text-[11px]">
                          {res.isCorrupted ? (
                            <span className={`font-bold underline ${isDarkMode ? 'text-rose-400' : 'text-rose-700'}`}>
                              {res.actualHash.slice(0, 12)}...
                            </span>
                          ) : (
                            <span className={`font-semibold ${isDarkMode ? 'text-emerald-400' : 'text-emerald-700'}`}>
                              {res.actualHash.slice(0, 12)}...
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-3">
                          {res.isCorrupted ? (
                            <span
                              className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold border ${
                                isDarkMode
                                  ? 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                                  : 'bg-rose-100 text-rose-800 border-rose-300'
                              }`}
                            >
                              <ShieldAlert className="w-3 h-3" />
                              <span>MISMATCH</span>
                            </span>
                          ) : !res.isOnline ? (
                            <span
                              className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold border ${
                                isDarkMode
                                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                                  : 'bg-amber-100 text-amber-800 border-amber-300'
                              }`}
                            >
                              <AlertTriangle className="w-3 h-3" />
                              <span>OFFLINE</span>
                            </span>
                          ) : (
                            <span
                              className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold border ${
                                isDarkMode
                                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                                  : 'bg-emerald-100 text-emerald-800 border-emerald-300'
                              }`}
                            >
                              <CheckCircle2 className="w-3 h-3" />
                              <span>VERIFIED</span>
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Quorum Summary Banner */}
              <div
                className={`p-4 rounded-2xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs font-mono ${
                  isDarkMode
                    ? 'bg-cyan-950/20 border-cyan-500/30 text-cyan-300'
                    : 'bg-cyan-50 border-cyan-200 text-cyan-900 shadow-sm'
                }`}
              >
                <div className="space-y-1">
                  <div className={`flex items-center gap-2 font-bold ${isDarkMode ? 'text-cyan-300' : 'text-cyan-900'}`}>
                    <ShieldCheck className="w-4 h-4 text-cyan-600" />
                    <span>Quorum Evaluation: Read Quorum R=2 Reached</span>
                  </div>
                  <p className={`text-[11px] ${isDarkMode ? 'text-slate-400' : 'text-slate-700'}`}>
                    Consensus quorum can reconstruct the authentic payload by comparing canonical hashes against healthy quorum peers.
                  </p>
                </div>

                <div className="flex items-center gap-2 font-bold">
                  <span className={isDarkMode ? 'text-emerald-400' : 'text-emerald-700'}>
                    {auditResults.filter(r => !r.isCorrupted && r.isOnline).length} Verified
                  </span>
                  <span className={isDarkMode ? 'text-slate-600' : 'text-slate-400'}>/</span>
                  <span className={isDarkMode ? 'text-rose-400' : 'text-rose-700'}>
                    {auditResults.filter(r => r.isCorrupted).length} Corrupted
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* STEP 3: Quorum Consensus & Recovery Strategy */}
          {currentStep === 3 && targetObject && (
            <div className="space-y-5 animate-in fade-in duration-200">
              <div className={`space-y-0.5 pb-2 border-b ${isDarkMode ? 'border-slate-800' : 'border-slate-200'}`}>
                <h3 className={`text-base font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                  Step 3: Quorum Consensus Resolution &amp; Strategy Selection
                </h3>
                <p className={`text-xs font-mono ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  Select how the recovery engine should restore degraded chunks or reconcile divergent object versions.
                </p>
              </div>

              {/* Strategy Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 font-mono text-xs">
                {/* Option 1: Automatic Anti-Entropy Quorum Healing */}
                <div
                  onClick={() => setRecoveryStrategy('quorum_repair')}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer space-y-2.5 ${
                    recoveryStrategy === 'quorum_repair'
                      ? isDarkMode
                        ? 'bg-cyan-950/40 border-cyan-500 ring-2 ring-cyan-500/30 shadow-lg'
                        : 'bg-cyan-50 border-cyan-500 ring-2 ring-cyan-400 shadow-md'
                      : isDarkMode
                      ? 'bg-slate-900/40 border-slate-800 hover:bg-slate-900'
                      : 'bg-white border-slate-200 hover:bg-slate-50 shadow-sm'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div
                      className={`p-2 rounded-xl border ${
                        isDarkMode
                          ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20'
                          : 'bg-cyan-100 text-cyan-800 border-cyan-300'
                      }`}
                    >
                      <Zap className="w-4 h-4" />
                    </div>
                    <span
                      className={`px-1.5 py-0.5 rounded text-[9px] font-bold border ${
                        isDarkMode
                          ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30'
                          : 'bg-cyan-100 text-cyan-800 border-cyan-300'
                      }`}
                    >
                      RECOMMENDED
                    </span>
                  </div>
                  <div>
                    <h4 className={`font-bold ${isDarkMode ? 'text-slate-200' : 'text-slate-900'}`}>Quorum Read Repair</h4>
                    <p className={`text-[11px] leading-relaxed mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                      Stream authentic chunk data from canonical quorum majority to replace corrupted blocks on degraded nodes.
                    </p>
                  </div>
                  <div className={`text-[10px] font-semibold pt-1 ${isDarkMode ? 'text-emerald-400' : 'text-emerald-700'}`}>
                    ✓ Zero Downtime · Self-Healing
                  </div>
                </div>

                {/* Option 2: Explicit Donor Node Selection */}
                <div
                  onClick={() => setRecoveryStrategy('donor_node')}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer space-y-2.5 ${
                    recoveryStrategy === 'donor_node'
                      ? isDarkMode
                        ? 'bg-cyan-950/40 border-cyan-500 ring-2 ring-cyan-500/30 shadow-lg'
                        : 'bg-cyan-50 border-cyan-500 ring-2 ring-cyan-400 shadow-md'
                      : isDarkMode
                      ? 'bg-slate-900/40 border-slate-800 hover:bg-slate-900'
                      : 'bg-white border-slate-200 hover:bg-slate-50 shadow-sm'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div
                      className={`p-2 rounded-xl border ${
                        isDarkMode
                          ? 'bg-blue-500/10 text-blue-400 border-blue-500/20'
                          : 'bg-blue-100 text-blue-800 border-blue-300'
                      }`}
                    >
                      <Server className="w-4 h-4" />
                    </div>
                    <span
                      className={`px-1.5 py-0.5 rounded text-[9px] font-bold border ${
                        isDarkMode
                          ? 'bg-blue-500/20 text-blue-300 border-blue-500/30'
                          : 'bg-blue-100 text-blue-800 border-blue-300'
                      }`}
                    >
                      OPERATOR PICK
                    </span>
                  </div>
                  <div>
                    <h4 className={`font-bold ${isDarkMode ? 'text-slate-200' : 'text-slate-900'}`}>Select Specific Donor</h4>
                    <p className={`text-[11px] leading-relaxed mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                      Manually designate a trusted rack or node peer with verified Merkle hash to act as the restoration source.
                    </p>
                  </div>
                  <div className={`text-[10px] font-semibold pt-1 ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`}>
                    ✓ Granular Rack Affinity
                  </div>
                </div>

                {/* Option 3: Version Rollback / Point-in-Time Restore */}
                <div
                  onClick={() => setRecoveryStrategy('version_restore')}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer space-y-2.5 ${
                    recoveryStrategy === 'version_restore'
                      ? isDarkMode
                        ? 'bg-cyan-950/40 border-cyan-500 ring-2 ring-cyan-500/30 shadow-lg'
                        : 'bg-cyan-50 border-cyan-500 ring-2 ring-cyan-400 shadow-md'
                      : isDarkMode
                      ? 'bg-slate-900/40 border-slate-800 hover:bg-slate-900'
                      : 'bg-white border-slate-200 hover:bg-slate-50 shadow-sm'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div
                      className={`p-2 rounded-xl border ${
                        isDarkMode
                          ? 'bg-purple-500/10 text-purple-400 border-purple-500/20'
                          : 'bg-purple-100 text-purple-800 border-purple-300'
                      }`}
                    >
                      <History className="w-4 h-4" />
                    </div>
                    <span
                      className={`px-1.5 py-0.5 rounded text-[9px] font-bold border ${
                        isDarkMode
                          ? 'bg-purple-500/20 text-purple-300 border-purple-500/30'
                          : 'bg-purple-100 text-purple-800 border-purple-300'
                      }`}
                    >
                      VERSION ROLLBACK
                    </span>
                  </div>
                  <div>
                    <h4 className={`font-bold ${isDarkMode ? 'text-slate-200' : 'text-slate-900'}`}>Restore Object Version</h4>
                    <p className={`text-[11px] leading-relaxed mt-1 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                      Reconcile split-brain or divergent writes by rolling back to an immutable historical version snapshot.
                    </p>
                  </div>
                  <div className={`text-[10px] font-semibold pt-1 ${isDarkMode ? 'text-purple-400' : 'text-purple-700'}`}>
                    ✓ Point-in-Time Integrity
                  </div>
                </div>
              </div>

              {/* Strategy Parameters Configuration */}
              <div
                className={`p-4 rounded-2xl border space-y-3 font-mono text-xs ${
                  isDarkMode ? 'bg-slate-900/40 border-slate-800' : 'bg-slate-50 border-slate-200 shadow-sm'
                }`}
              >
                {recoveryStrategy === 'donor_node' && (
                  <div>
                    <label className={`block font-semibold mb-1 ${isDarkMode ? 'text-slate-300' : 'text-slate-800'}`}>
                      Designate Verified Donor Node
                    </label>
                    <select
                      value={selectedDonorNodeId}
                      onChange={e => setSelectedDonorNodeId(e.target.value)}
                      className={`w-full p-2.5 rounded-xl border outline-none ${
                        isDarkMode ? 'bg-slate-900 border-slate-700 text-slate-100' : 'bg-white border-slate-300 text-slate-900'
                      }`}
                    >
                      {nodes
                        .filter(n => n.status !== 'crashed')
                        .map(n => (
                          <option key={n.id} value={n.id}>
                            {n.name} ({n.rack}) - {n.diskUsedMB} MB [Nominal Online]
                          </option>
                        ))}
                    </select>
                  </div>
                )}

                {recoveryStrategy === 'version_restore' && (
                  <div>
                    <label className={`block font-semibold mb-1 ${isDarkMode ? 'text-slate-300' : 'text-slate-800'}`}>
                      Select Target Version to Restore
                    </label>
                    {targetObject.versions && targetObject.versions.length > 0 ? (
                      <div className="space-y-2">
                        {targetObject.versions.map(v => (
                          <div
                            key={v.version}
                            onClick={() => setSelectedTargetVersion(v.version)}
                            className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-colors ${
                              selectedTargetVersion === v.version
                                ? isDarkMode
                                  ? 'bg-purple-950/40 border-purple-500'
                                  : 'bg-purple-50 border-purple-400 ring-1 ring-purple-300'
                                : isDarkMode
                                ? 'bg-slate-900 border-slate-800 hover:bg-slate-800'
                                : 'bg-white border-slate-200 hover:bg-slate-50 shadow-sm'
                            }`}
                          >
                            <div className="space-y-0.5">
                              <div className="font-semibold flex items-center gap-2">
                                <span className={isDarkMode ? 'text-slate-200' : 'text-slate-900'}>Version v{v.version}</span>
                                {v.version === targetObject.version && (
                                  <span
                                    className={`px-1.5 py-0.2 rounded text-[9px] font-bold ${
                                      isDarkMode ? 'bg-slate-700 text-slate-300' : 'bg-slate-200 text-slate-800'
                                    }`}
                                  >
                                    Current
                                  </span>
                                )}
                              </div>
                              <div className={`text-[11px] ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                                {new Date(v.timestamp).toLocaleString()} · {(v.sizeBytes / 1024).toFixed(1)} KB ·{' '}
                                {v.note || 'Snapshot'}
                              </div>
                            </div>
                            <input
                              type="radio"
                              name="versionChoice"
                              checked={selectedTargetVersion === v.version}
                              onChange={() => setSelectedTargetVersion(v.version)}
                              className="accent-purple-600 w-4 h-4 cursor-pointer"
                            />
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className={`py-4 text-center font-medium ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                        No previous historical versions recorded for this object. Quorum read repair will be used.
                      </div>
                    )}
                  </div>
                )}

                {recoveryStrategy === 'quorum_repair' && (
                  <div className={`text-[11px] leading-relaxed ${isDarkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                    <span className={`font-bold ${isDarkMode ? 'text-cyan-300' : 'text-cyan-800'}`}>Automatic Anti-Entropy Protocol:</span> The engine will
                    query available healthy nodes across Rack-Alpha and Rack-Beta, verify canonical SHA-256 digests, and
                    automatically rebuild corrupted shards to re-establish $N=3$ replica consistency.
                  </div>
                )}
              </div>
            </div>
          )}

          {/* STEP 4: Execute Quorum Repair Stream */}
          {currentStep === 4 && targetObject && (
            <div className="space-y-5 animate-in fade-in duration-200">
              <div className={`space-y-0.5 pb-2 border-b ${isDarkMode ? 'border-slate-800' : 'border-slate-200'}`}>
                <h3 className={`text-base font-bold ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                  Step 4: Execute Quorum Anti-Entropy Repair
                </h3>
                <p className={`text-xs font-mono ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  Streaming payload bitstream and committing verified blocks to cluster nodes.
                </p>
              </div>

              {/* Progress Bar & Status */}
              <div
                className={`p-5 rounded-2xl border space-y-3 font-mono ${
                  isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-slate-50 border-slate-200 shadow-sm'
                }`}
              >
                <div className="flex items-center justify-between text-xs">
                  <span className={`font-bold ${isDarkMode ? 'text-slate-200' : 'text-slate-900'}`}>
                    {isExecuting ? 'Repair in Progress...' : executionFinished ? 'Repair Complete' : 'Ready to Execute'}
                  </span>
                  <span className={`font-bold ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`}>{execProgress}%</span>
                </div>

                <div className={`w-full h-3 rounded-full overflow-hidden ${isDarkMode ? 'bg-slate-800' : 'bg-slate-200'}`}>
                  <div
                    className={`h-full transition-all duration-300 ${
                      executionFinished
                        ? 'bg-emerald-600'
                        : isExecuting
                        ? 'bg-gradient-to-r from-cyan-600 to-blue-600 animate-pulse'
                        : isDarkMode
                        ? 'bg-slate-700'
                        : 'bg-slate-400'
                    }`}
                    style={{ width: `${execProgress}%` }}
                  />
                </div>

                {!isExecuting && !executionFinished && (
                  <button
                    type="button"
                    onClick={handleExecuteRecovery}
                    className="w-full py-3 rounded-xl font-bold bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white shadow-lg shadow-cyan-600/25 flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <Play className="w-4 h-4 fill-white" />
                    <span>Initiate Quorum Anti-Entropy Recovery</span>
                  </button>
                )}
              </div>

              {/* Real-time Terminal Stream Logs */}
              <div className="rounded-2xl bg-[#080d1a] border border-slate-800 p-4 font-mono text-[11px] space-y-1.5 max-h-[220px] overflow-y-auto shadow-inner">
                <div className="flex items-center gap-2 text-slate-400 pb-2 border-b border-slate-800/80 font-semibold">
                  <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Cluster Anti-Entropy Network Transport Log</span>
                </div>

                {execLogs.length === 0 ? (
                  <div className="py-6 text-center text-slate-500">
                    Click "Initiate Quorum Anti-Entropy Recovery" above to begin stream.
                  </div>
                ) : (
                  execLogs.map((log, idx) => (
                    <div
                      key={idx}
                      className={
                        log.includes('[SUCCESS]')
                          ? 'text-emerald-400 font-bold'
                          : log.includes('Acquiring')
                          ? 'text-cyan-300 font-semibold'
                          : 'text-slate-300'
                      }
                    >
                      {log}
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* STEP 5: Verification & Certificate */}
          {currentStep === 5 && targetObject && (
            <div className="space-y-5 animate-in fade-in duration-200">
              <div
                className={`p-6 rounded-3xl border text-center space-y-2 ${
                  isDarkMode
                    ? 'bg-emerald-950/20 border-emerald-500/40'
                    : 'bg-emerald-50 border-emerald-300 shadow-sm'
                }`}
              >
                <div
                  className={`w-12 h-12 rounded-2xl flex items-center justify-center mx-auto shadow-lg border ${
                    isDarkMode
                      ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40 shadow-emerald-500/20'
                      : 'bg-emerald-100 text-emerald-800 border-emerald-300 shadow-emerald-200'
                  }`}
                >
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <h3 className={`text-xl font-bold ${isDarkMode ? 'text-emerald-300' : 'text-emerald-900'}`}>
                  Quorum Recovery Succeeded
                </h3>
                <p className={`text-xs font-mono max-w-lg mx-auto ${isDarkMode ? 'text-slate-400' : 'text-slate-700'}`}>
                  Object "{targetObject.originalName}" has been successfully repaired and reconciled across all cluster
                  nodes with 100% cryptographic digest verification.
                </p>
              </div>

              {/* Proof Breakdown */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono text-xs">
                <div
                  className={`p-4 rounded-2xl border ${
                    isDarkMode ? 'bg-slate-900/40 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
                  }`}
                >
                  <div className={`text-[10px] font-bold ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                    OBJECT HEALTH
                  </div>
                  <div className={`mt-1 text-sm font-bold flex items-center gap-1.5 ${isDarkMode ? 'text-emerald-400' : 'text-emerald-700'}`}>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>HEALTHY (VERIFIED)</span>
                  </div>
                </div>

                <div
                  className={`p-4 rounded-2xl border ${
                    isDarkMode ? 'bg-slate-900/40 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
                  }`}
                >
                  <div className={`text-[10px] font-bold ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                    CONSENSUS STATUS
                  </div>
                  <div className={`mt-1 text-sm font-bold ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`}>
                    3 / 3 Replicas Matched
                  </div>
                </div>

                <div
                  className={`p-4 rounded-2xl border ${
                    isDarkMode ? 'bg-slate-900/40 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
                  }`}
                >
                  <div className={`text-[10px] font-bold ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                    AUDIT ATTESTATION
                  </div>
                  <div className={`mt-1 text-sm font-bold ${isDarkMode ? 'text-purple-400' : 'text-purple-700'}`}>
                    Immutable Ledger Logged
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={handleDownloadCertificate}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-md shadow-emerald-600/20 transition-all cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Recovery Certificate (JSON)</span>
                </button>

                {onViewInAuditLogs && (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onViewInAuditLogs();
                    }}
                    className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold border transition-colors cursor-pointer ${
                      isDarkMode
                        ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
                        : 'bg-white hover:bg-slate-100 text-slate-800 border-slate-300 shadow-sm'
                    }`}
                  >
                    <FileText className="w-4 h-4" />
                    <span>View in Audit Logs</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => {
                    setCurrentStep(1);
                    setExecutionFinished(false);
                    setExecProgress(0);
                    setExecLogs([]);
                  }}
                  className={`px-4 py-2.5 rounded-xl text-xs font-semibold border transition-colors cursor-pointer ${
                    isDarkMode
                      ? 'text-slate-400 hover:text-slate-200 border-slate-800 hover:bg-slate-800'
                      : 'text-slate-700 hover:text-slate-900 border-slate-300 hover:bg-slate-100'
                  }`}
                >
                  Run Another Recovery
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Wizard Footer Controls */}
        <div
          className={`p-4 sm:p-5 border-t flex items-center justify-between gap-3 shrink-0 font-mono text-xs ${
            isDarkMode ? 'border-slate-800/80 bg-slate-900/40' : 'border-slate-200 bg-slate-50'
          }`}
        >
          <button
            type="button"
            disabled={currentStep === 1 || isExecuting}
            onClick={() => setCurrentStep(prev => (prev - 1) as WizardStep)}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-xl border transition-all ${
              currentStep === 1 || isExecuting
                ? isDarkMode
                  ? 'opacity-40 cursor-not-allowed border-slate-800 text-slate-500'
                  : 'opacity-40 cursor-not-allowed border-slate-300 text-slate-400'
                : isDarkMode
                ? 'border-slate-700 hover:bg-slate-800 text-slate-300 cursor-pointer'
                : 'border-slate-300 hover:bg-slate-200 text-slate-800 cursor-pointer shadow-sm'
            }`}
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Previous</span>
          </button>

          <div className="flex items-center gap-2">
            {currentStep < 4 ? (
              <button
                type="button"
                disabled={!targetObject}
                onClick={() => {
                  if (currentStep === 1) runQuorumAudit();
                  setCurrentStep(prev => (prev + 1) as WizardStep);
                }}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold bg-cyan-600 hover:bg-cyan-700 text-white shadow-md shadow-cyan-600/20 transition-all ${
                  !targetObject ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'
                }`}
              >
                <span>Continue</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            ) : currentStep === 4 ? (
              <button
                type="button"
                disabled={!executionFinished}
                onClick={() => setCurrentStep(5)}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-md shadow-emerald-600/20 transition-all ${
                  !executionFinished ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'
                }`}
              >
                <span>View Attestation Proof</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                type="button"
                onClick={onClose}
                className={`px-5 py-2.5 rounded-xl font-semibold transition-colors cursor-pointer border ${
                  isDarkMode
                    ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
                    : 'bg-slate-900 hover:bg-slate-800 text-white border-slate-900 shadow-sm'
                }`}
              >
                Done / Close Wizard
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
