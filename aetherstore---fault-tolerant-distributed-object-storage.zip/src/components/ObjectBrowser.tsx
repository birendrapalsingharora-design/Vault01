import { useState, useRef } from 'react';
import {
  UploadCloud,
  FileText,
  Lock,
  Unlock,
  CheckCircle,
  Download,
  Trash2,
  Layers,
  ShieldCheck,
  Eye,
  AlertTriangle,
  RefreshCw,
  Search,
  Hash,
  QrCode,
  Flame,
  Wrench,
} from 'lucide-react';
import { StorageObject, DurabilityPolicyType, UserAccount } from '../types/storage';
import { StorageEngine, DURABILITY_POLICIES } from '../services/storageEngine';
import { QuotaService } from '../services/quotaService';
import { OfflineSyncService } from '../services/offlineSyncService';
import { QRCodeModal } from './QRCodeModal';

interface ObjectBrowserProps {
  objects: StorageObject[];
  currentUser?: UserAccount | null;
  isDarkMode: boolean;
  isOnline: boolean;
  onNotify: (type: 'success' | 'warning' | 'error' | 'info', title: string, msg: string) => void;
  onOpenRecoveryWizard?: (objectId?: string) => void;
}

export function ObjectBrowser({
  objects,
  currentUser,
  isDarkMode,
  isOnline,
  onNotify,
  onOpenRecoveryWizard,
}: ObjectBrowserProps) {
  const [selectedBucket, setSelectedBucket] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [policy, setPolicy] = useState<DurabilityPolicyType>('quorum_w2_r2_n3');
  const [uploadPriority, setUploadPriority] = useState<'high' | 'normal'>('normal');
  const [enableE2EE, setEnableE2EE] = useState(true);
  const [passphrase, setPassphrase] = useState('AetherMasterKey2026!');
  const [isUploading, setIsUploading] = useState(false);
  const [selectedObject, setSelectedObject] = useState<StorageObject | null>(null);
  const [decryptPassphrase, setDecryptPassphrase] = useState('AetherMasterKey2026!');
  const [previewContent, setPreviewContent] = useState<{ url?: string; text?: string; title: string } | null>(null);
  const [qrTargetObject, setQrTargetObject] = useState<StorageObject | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  const fileInputRef = useRef<HTMLInputElement>(null);

  const buckets = ['all', 'infrastructure', 'docs', 'backups', 'media'];

  const filteredObjects = objects.filter(obj => {
    const matchesBucket = selectedBucket === 'all' || obj.bucket === selectedBucket;
    const matchesSearch = obj.originalName.toLowerCase().includes(searchQuery.toLowerCase()) || obj.key.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesBucket && matchesSearch;
  });

  const isAllSelected = filteredObjects.length > 0 && filteredObjects.every(obj => selectedIds.has(obj.id));
  const totalSelectedBytes = objects
    .filter(obj => selectedIds.has(obj.id))
    .reduce((sum, obj) => sum + obj.sizeBytes, 0);

  const userEmail = currentUser?.email || 'shuvammali12@gmail.com';
  const userQuota = QuotaService.getQuotaForUser(userEmail);
  const userObjects = objects.filter(o =>
    o.ownerEmail ? o.ownerEmail.toLowerCase() === userEmail.toLowerCase() : userEmail === 'shuvammali12@gmail.com'
  );
  const userUsedBytes = userObjects.reduce((acc, o) => acc + o.sizeBytes, 0);
  const userUsedMB = +(userUsedBytes / (1024 * 1024)).toFixed(2);
  const userQuotaBytes = userQuota.storageQuotaMB * 1024 * 1024;
  const userUsedPercent = Math.min(100, +((userUsedBytes / userQuotaBytes) * 100).toFixed(1));
  const isNearLimit = userUsedPercent >= userQuota.warningThresholdPercent;
  const isOverQuota = userUsedBytes >= userQuotaBytes;

  const handleSelectAll = () => {
    if (isAllSelected) {
      setSelectedIds(prev => {
        const next = new Set(prev);
        filteredObjects.forEach(obj => next.delete(obj.id));
        return next;
      });
    } else {
      setSelectedIds(prev => {
        const next = new Set(prev);
        filteredObjects.forEach(obj => next.add(obj.id));
        return next;
      });
    }
  };

  const handleToggleSelect = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleBulkDelete = () => {
    const ids = Array.from(selectedIds);
    if (ids.length === 0) return;

    const res = StorageEngine.bulkDeleteObjects(ids);
    setSelectedIds(new Set());
    if (selectedObject && ids.includes(selectedObject.id)) {
      setSelectedObject(null);
    }
    onNotify(
      'success',
      'Bulk Delete Executed',
      `Tombstoned ${res.deletedCount} objects and released ${(res.freedBytes / 1024).toFixed(1)} KB of replica storage across the cluster.`
    );
  };

  const handleBulkRepair = () => {
    const ids = Array.from(selectedIds);
    if (ids.length === 0) return;

    const res = StorageEngine.bulkRepairObjects(ids);
    onNotify(
      'success',
      'Batch Repair Executed',
      `Restored ${res.repairedCount} corrupted replicas across ${ids.length} selected objects.`
    );
  };

  const handleFileUpload = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const file = files[0];
    setIsUploading(true);

    try {
      const buffer = await file.arrayBuffer();
      const bucketName = selectedBucket === 'all' ? 'infrastructure' : selectedBucket;

      if (!isOnline) {
        OfflineSyncService.enqueueAction('UPLOAD', {
          fileName: file.name,
          bucket: bucketName,
          size: file.size,
        });
        onNotify(
          'warning',
          'Queued in Offline Buffer',
          `"${file.name}" saved to local IndexedDB queue. Will auto-commit to cluster upon reconnect.`
        );
        setIsUploading(false);
        return;
      }

      const res = await StorageEngine.putObject(
        file.name,
        bucketName,
        buffer,
        file.type || 'application/octet-stream',
        policy,
        enableE2EE,
        enableE2EE ? passphrase : undefined,
        uploadPriority,
        currentUser?.email
      );

      if (res.success) {
        onNotify('success', 'Stored with Quorum', res.message);
      } else {
        onNotify('error', 'Quorum Write Rejected', res.message);
      }
    } catch (err) {
      onNotify('error', 'Upload Error', 'Failed to read and chunk file.');
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleDownloadObject = async (obj: StorageObject) => {
    const res = await StorageEngine.getObject(
      obj.id,
      obj.isEncrypted ? decryptPassphrase : undefined
    );

    if (res.success && res.dataUrl) {
      const a = document.createElement('a');
      a.href = res.dataUrl;
      a.download = obj.originalName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

      if (res.readRepaired) {
        onNotify(
          'warning',
          'Read Repair Executed',
          `A corrupted chunk was detected during retrieval. The engine automatically healed the chunk from healthy quorum replicas!`
        );
      } else {
        onNotify('success', 'Object Retrieved & Verified', `Integrity check passed: ${res.message}`);
      }
    } else {
      onNotify('error', 'Retrieval Failed', res.message);
    }
  };

  const handlePreviewObject = async (obj: StorageObject) => {
    const res = await StorageEngine.getObject(
      obj.id,
      obj.isEncrypted ? decryptPassphrase : undefined
    );

    if (res.success) {
      setPreviewContent({
        url: res.dataUrl,
        text: res.textContent,
        title: obj.originalName,
      });
      if (res.readRepaired) {
        onNotify(
          'warning',
          'Auto-Healed During Read',
          `SHA-256 mismatch detected; recovered via quorum peer replica.`
        );
      }
    } else {
      onNotify('error', 'Preview Failed', res.message);
    }
  };

  const handleDeleteObject = (obj: StorageObject) => {
    StorageEngine.deleteObject(obj.id);
    setSelectedIds(prev => {
      const next = new Set(prev);
      next.delete(obj.id);
      return next;
    });
    if (selectedObject?.id === obj.id) setSelectedObject(null);
    onNotify('info', 'Object Deleted', `Removed "${obj.originalName}" and freed node blocks.`);
  };

  return (
    <div className="space-y-6">
      {/* Upload Zone & Config Box */}
      <div
        className={`rounded-3xl p-6 sm:p-8 transition-colors ${
          isDarkMode ? 'liquid-glass-dark' : 'liquid-glass-light'
        }`}
      >
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-1">
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight">Object Ingestion &amp; Distribution</h2>
            <p className="text-xs sm:text-sm text-slate-400">
              Files are chunked, client-side encrypted with AES-256-GCM, and replicated across multi-AZ failure domains.
            </p>
          </div>

          {/* Quick upload trigger */}
          <div className="flex items-center gap-3">
            <input
              type="file"
              ref={fileInputRef}
              onChange={e => handleFileUpload(e.target.files)}
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-semibold bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/20 hover:opacity-95 transition-all"
            >
              <UploadCloud className="w-4 h-4" />
              <span>{isUploading ? 'Chunking & Writing...' : 'Upload & Replicate'}</span>
            </button>
          </div>
        </div>

        {/* Durability Policy & Encryption Config Grid */}
        <div className={`mt-6 grid grid-cols-1 md:grid-cols-3 gap-4 pt-6 border-t ${isDarkMode ? 'border-slate-800/40' : 'border-slate-200'}`}>
          {/* Policy Selection */}
          <div className="space-y-2">
            <label className={`block text-xs font-semibold ${isDarkMode ? 'text-slate-300' : 'text-slate-800'}`}>
              Durability &amp; Replication Policy
            </label>
            <select
              value={policy}
              onChange={e => setPolicy(e.target.value as DurabilityPolicyType)}
              className={`w-full p-2.5 text-xs rounded-xl border outline-none font-mono ${
                isDarkMode ? 'bg-slate-900 border-slate-700 text-slate-200' : 'bg-white border-slate-300 text-slate-900 shadow-sm'
              }`}
            >
              <option value="3x_replication">3-Way Replication (N=3, 2 Racks)</option>
              <option value="quorum_w2_r2_n3">Dynamo Quorum (W=2, R=2, N=3)</option>
              <option value="erasure_coding_4_2">Reed-Solomon RS(4,2) Erasure Coding</option>
            </select>
            <p className={`text-[11px] font-mono ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
              {DURABILITY_POLICIES[policy].faultTolerance} · Overhead: {DURABILITY_POLICIES[policy].storageOverhead}
            </p>
          </div>

          {/* E2EE Toggle */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className={`text-xs font-semibold ${isDarkMode ? 'text-slate-300' : 'text-slate-800'}`}>
                Client-Side AES-256-GCM
              </label>
              <button
                onClick={() => setEnableE2EE(!enableE2EE)}
                className={`flex items-center gap-1 text-[11px] font-mono px-2 py-0.5 rounded-lg border transition-colors cursor-pointer ${
                  enableE2EE
                    ? isDarkMode
                      ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30'
                      : 'bg-cyan-100 text-cyan-900 border-cyan-300 font-bold'
                    : isDarkMode
                    ? 'bg-slate-800 text-slate-400 border-slate-700'
                    : 'bg-slate-100 text-slate-700 border-slate-300'
                }`}
              >
                {enableE2EE ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
                <span>{enableE2EE ? 'E2EE Enabled' : 'Plaintext'}</span>
              </button>
            </div>
            <input
              type="password"
              disabled={!enableE2EE}
              value={passphrase}
              onChange={e => setPassphrase(e.target.value)}
              placeholder="Encryption Passphrase"
              className={`w-full p-2.5 text-xs rounded-xl border outline-none font-mono ${
                isDarkMode ? 'bg-slate-900 border-slate-700 text-slate-200' : 'bg-white border-slate-300 text-slate-900 shadow-sm'
              } ${!enableE2EE ? 'opacity-40 cursor-not-allowed' : ''}`}
            />
            <p className={`text-[11px] font-mono ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
              PBKDF2 100k iters · 96-bit random IV
            </p>
          </div>

          {/* Target Bucket */}
          <div className="space-y-2">
            <label className={`block text-xs font-semibold ${isDarkMode ? 'text-slate-300' : 'text-slate-800'}`}>
              Target Storage Bucket
            </label>
            <div className="flex flex-wrap gap-1.5">
              {buckets.slice(1).map(b => (
                <button
                  key={b}
                  onClick={() => setSelectedBucket(b)}
                  className={`px-3 py-1.5 text-xs font-mono rounded-lg border transition-colors cursor-pointer ${
                    selectedBucket === b
                      ? isDarkMode
                        ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40 font-semibold'
                        : 'bg-cyan-100 text-cyan-900 border-cyan-400 font-bold shadow-sm'
                      : isDarkMode
                      ? 'bg-slate-800/40 text-slate-400 border-slate-800 hover:text-slate-200'
                      : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100 shadow-sm'
                  }`}
                >
                  /{b}
                </button>
              ))}
            </div>
          </div>

          {/* Recovery SLA Priority */}
          <div className="space-y-2">
            <label className={`block text-xs font-semibold ${isDarkMode ? 'text-slate-300' : 'text-slate-800'}`}>
              Failover Recovery SLA
            </label>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setUploadPriority('normal')}
                className={`px-3 py-1.5 text-xs font-mono rounded-lg border transition-colors cursor-pointer ${
                  uploadPriority === 'normal'
                    ? isDarkMode
                      ? 'bg-blue-500/20 text-blue-300 border-blue-500/40 font-semibold'
                      : 'bg-blue-100 text-blue-900 border-blue-400 font-bold shadow-sm'
                    : isDarkMode
                    ? 'bg-slate-800/40 text-slate-400 border-slate-800 hover:text-slate-200'
                    : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100 shadow-sm'
                }`}
              >
                P2 Standard
              </button>
              <button
                type="button"
                onClick={() => setUploadPriority('high')}
                className={`px-3 py-1.5 text-xs font-mono rounded-lg border transition-colors flex items-center gap-1.5 cursor-pointer ${
                  uploadPriority === 'high'
                    ? isDarkMode
                      ? 'bg-amber-500/25 text-amber-300 border-amber-500/50 font-bold shadow-sm'
                      : 'bg-amber-100 text-amber-900 border-amber-400 font-bold shadow-sm'
                    : isDarkMode
                    ? 'bg-slate-800/40 text-slate-400 border-slate-800 hover:text-slate-200'
                    : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100 shadow-sm'
                }`}
              >
                <Flame className={`w-3.5 h-3.5 ${isDarkMode ? 'text-amber-400' : 'text-amber-600'}`} />
                <span>P1 High Priority (Heals First)</span>
              </button>
            </div>
          </div>

          {/* Active Tenant Quota Meter */}
          <div className={`sm:col-span-2 lg:col-span-4 p-3.5 rounded-2xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs font-mono ${
            isDarkMode ? 'bg-slate-900/60 border-slate-800' : 'bg-slate-100/90 border-slate-300 shadow-sm'
          }`}>
            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className={`font-semibold ${isDarkMode ? 'text-slate-200' : 'text-slate-900'}`}>Account Quota ({userQuota.tier} Tier):</span>
                <span className={`font-bold ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`}>{userUsedMB} MB / {userQuota.storageQuotaMB} MB</span>
                <span
                  className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                    isOverQuota
                      ? isDarkMode
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30 animate-pulse'
                        : 'bg-rose-100 text-rose-900 border border-rose-300 animate-pulse'
                      : isNearLimit
                      ? isDarkMode
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                        : 'bg-amber-100 text-amber-900 border border-amber-300'
                      : isDarkMode
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                  }`}
                >
                  {userUsedPercent}% used
                </span>
                <span className={isDarkMode ? 'text-slate-400' : 'text-slate-600 font-medium'}>
                  · {userObjects.length} / {userQuota.maxObjectsQuota > 0 ? `${userQuota.maxObjectsQuota} objs` : '∞'}
                </span>
              </div>
              <div className={`text-[10px] ${isDarkMode ? 'text-slate-500' : 'text-slate-600'}`}>
                Enforcement Policy:{' '}
                <span className={`font-semibold ${isDarkMode ? 'text-slate-300' : 'text-slate-900'}`}>{userQuota.enforcementMode.toUpperCase()} LIMIT</span>{' '}
                ({userQuota.enforcementMode === 'hard' ? 'Hard write rejection if exceeded' : 'Soft notification only'})
              </div>
            </div>

            <div className={`w-full sm:w-52 h-2.5 rounded-full overflow-hidden shrink-0 ${isDarkMode ? 'bg-slate-800' : 'bg-slate-300'}`}>
              <div
                className={`h-full transition-all duration-300 ${
                  isOverQuota ? 'bg-rose-500' : isNearLimit ? 'bg-amber-500' : 'bg-cyan-600'
                }`}
                style={{ width: `${Math.min(100, userUsedPercent)}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Object Catalog Section */}
      <div
        className={`rounded-3xl p-6 sm:p-8 transition-colors ${
          isDarkMode ? 'liquid-glass-dark' : 'liquid-glass-light'
        }`}
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800/40">
          <div className="flex items-center gap-3">
            <h3 className="text-lg font-bold tracking-tight">Stored Objects ({filteredObjects.length})</h3>
            <span className="text-xs text-slate-400 font-mono">Verified with SHA-256 digests</span>
          </div>

          <div className="flex items-center gap-2">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search key or bucket..."
                className={`pl-9 pr-3 py-1.5 text-xs rounded-xl border outline-none font-mono ${
                  isDarkMode ? 'bg-slate-900 border-slate-700 text-slate-200' : 'bg-slate-50 border-slate-300 text-slate-800'
                }`}
              />
            </div>

            {/* Launch Recovery Wizard Button */}
            {onOpenRecoveryWizard && (
              <button
                type="button"
                onClick={() => onOpenRecoveryWizard()}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-gradient-to-r from-cyan-500/15 to-blue-500/15 hover:from-cyan-500/25 hover:to-blue-500/25 text-cyan-300 border border-cyan-500/30 transition-all cursor-pointer shadow-sm shrink-0"
                title="Launch Guided Quorum Anti-Entropy Recovery Wizard"
              >
                <Wrench className="w-3.5 h-3.5 text-cyan-400" />
                <span className="hidden sm:inline">Recovery Wizard</span>
              </button>
            )}
          </div>
        </div>

        {/* Bulk Action Bar (Visible when objects are selected) */}
        {selectedIds.size > 0 && (
          <div className={`mt-4 p-3.5 sm:p-4 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs font-mono shadow-xl animate-in fade-in duration-200 border ${
            isDarkMode ? 'bg-cyan-950/40 border-cyan-500/40' : 'bg-cyan-50 border-cyan-300 text-cyan-950 shadow-cyan-100'
          }`}>
            <div className="flex items-center gap-2.5">
              <span className={`w-2.5 h-2.5 rounded-full animate-pulse ${isDarkMode ? 'bg-cyan-400' : 'bg-cyan-600'}`} />
              <span className={`font-semibold ${isDarkMode ? 'text-cyan-300' : 'text-cyan-900 font-bold'}`}>
                {selectedIds.size} {selectedIds.size === 1 ? 'object' : 'objects'} selected
              </span>
              <span className={isDarkMode ? 'text-slate-400' : 'text-slate-600'}>
                ({(totalSelectedBytes / 1024).toFixed(1)} KB total)
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={handleBulkRepair}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-semibold bg-emerald-600 hover:bg-emerald-500 text-white shadow-sm transition-all cursor-pointer"
                title="Execute batch verification and repair across selected objects"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Batch Repair ({selectedIds.size})</span>
              </button>

              <button
                onClick={handleBulkDelete}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl font-semibold bg-rose-600 hover:bg-rose-500 text-white shadow-md shadow-rose-600/20 transition-all cursor-pointer"
                title="Tombstone selected objects and release chunk replicas across cluster"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Bulk Delete ({selectedIds.size})</span>
              </button>

              <button
                onClick={() => setSelectedIds(new Set())}
                className={`px-2.5 py-1.5 rounded-xl border transition-colors cursor-pointer ${
                  isDarkMode
                    ? 'text-slate-400 hover:text-slate-200 border-slate-700/60 hover:bg-slate-800'
                    : 'text-slate-700 hover:text-slate-900 border-slate-300 hover:bg-slate-100 shadow-sm'
                }`}
              >
                Deselect All
              </button>
            </div>
          </div>
        )}

        {/* Object Table */}
        <div className={`mt-4 overflow-x-auto rounded-2xl border ${isDarkMode ? 'border-slate-800' : 'border-slate-200'}`}>
          <table className="w-full text-left text-xs">
            <thead>
              <tr className={`border-b font-mono uppercase text-[10px] font-bold ${
                isDarkMode ? 'border-slate-800/60 text-slate-400 bg-slate-900/40' : 'border-slate-200 text-slate-700 bg-slate-100'
              }`}>
                <th className="py-3 px-3 w-10 text-center">
                  <input
                    type="checkbox"
                    checked={isAllSelected}
                    onChange={handleSelectAll}
                    title={isAllSelected ? 'Deselect All' : 'Select All'}
                    className={`w-4 h-4 rounded cursor-pointer accent-cyan-600 ${
                      isDarkMode ? 'border-slate-700 bg-slate-900' : 'border-slate-300 bg-white'
                    }`}
                  />
                </th>
                <th className="py-3 px-3">Object Key</th>
                <th className="py-3 px-3">Bucket</th>
                <th className="py-3 px-3">Size</th>
                <th className="py-3 px-3">Policy</th>
                <th className="py-3 px-3">Encryption</th>
                <th className="py-3 px-3">Health</th>
                <th className="py-3 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className={`divide-y ${isDarkMode ? 'divide-slate-800/40' : 'divide-slate-200'}`}>
              {filteredObjects.length === 0 ? (
                <tr>
                  <td colSpan={8} className={`py-8 text-center text-xs font-mono ${isDarkMode ? 'text-slate-500' : 'text-slate-600'}`}>
                    No objects match the current filters. Upload a file above to test replication.
                  </td>
                </tr>
              ) : (
                filteredObjects.map(obj => {
                  const isSelected = selectedIds.has(obj.id);
                  return (
                    <tr
                      key={obj.id}
                      onClick={() => setSelectedObject(obj)}
                      className={`cursor-pointer transition-colors ${
                        isSelected
                          ? isDarkMode
                            ? 'bg-cyan-950/40 border-l-2 border-l-cyan-400'
                            : 'bg-cyan-50 border-l-2 border-l-cyan-600'
                          : selectedObject?.id === obj.id
                          ? isDarkMode
                            ? 'bg-cyan-950/20'
                            : 'bg-cyan-50/70'
                          : isDarkMode
                          ? 'hover:bg-slate-900/40'
                          : 'hover:bg-slate-50'
                      }`}
                    >
                      <td className="py-3.5 px-3 w-10 text-center" onClick={e => e.stopPropagation()}>
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => handleToggleSelect(obj.id)}
                          className={`w-4 h-4 rounded cursor-pointer accent-cyan-600 ${
                            isDarkMode ? 'border-slate-700 bg-slate-900' : 'border-slate-300 bg-white'
                          }`}
                        />
                      </td>
                      <td className={`py-3.5 px-3 font-semibold flex items-center gap-2 ${isDarkMode ? 'text-slate-200' : 'text-slate-900'}`}>
                        <FileText className={`w-4 h-4 shrink-0 ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`} />
                        <span className="truncate max-w-[200px]">{obj.originalName}</span>
                        {obj.priority === 'high' && (
                          <span
                            className={`px-1.5 py-0.5 rounded text-[9px] font-bold shrink-0 flex items-center gap-1 border shadow-sm ${
                              isDarkMode
                                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                                : 'bg-amber-100 text-amber-900 border-amber-300'
                            }`}
                            title="P1 High Priority: Healed first during node loss"
                          >
                            <Flame className={`w-2.5 h-2.5 ${isDarkMode ? 'text-amber-400' : 'text-amber-600'}`} />
                            <span>P1 SLA</span>
                          </span>
                        )}
                      </td>
                    <td className={`py-3.5 px-3 font-mono ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>/{obj.bucket}</td>
                    <td className={`py-3.5 px-3 font-mono tabular-nums ${isDarkMode ? 'text-slate-300' : 'text-slate-800 font-medium'}`}>
                      {(obj.sizeBytes / 1024).toFixed(1)} KB
                    </td>
                    <td className={`py-3.5 px-3 font-mono ${isDarkMode ? 'text-slate-300' : 'text-slate-800'}`}>
                      {DURABILITY_POLICIES[obj.policy]?.name || obj.policy}
                    </td>
                    <td className="py-3.5 px-3 font-mono">
                      {obj.isEncrypted ? (
                        <span className={`inline-flex items-center gap-1 text-[11px] font-medium ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`}>
                          <Lock className="w-3 h-3" />
                          AES-256
                        </span>
                      ) : (
                        <span className={`text-[11px] ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Plaintext</span>
                      )}
                    </td>
                    <td className="py-3.5 px-3">
                      <span
                        className={`text-[11px] font-mono px-2 py-0.5 rounded-md font-semibold border ${
                          obj.health === 'healthy'
                            ? isDarkMode
                              ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                              : 'bg-emerald-100 text-emerald-900 border-emerald-300'
                            : obj.health === 'corrupt'
                            ? isDarkMode
                              ? 'bg-rose-500/20 text-rose-400 border-rose-500/30 font-bold animate-pulse'
                              : 'bg-rose-100 text-rose-900 border-rose-300 font-bold animate-pulse'
                            : isDarkMode
                            ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                            : 'bg-amber-100 text-amber-900 border-amber-300'
                        }`}
                      >
                        {obj.health.toUpperCase()}
                      </span>
                    </td>
                    <td className="py-3.5 px-3 text-right">
                      <div className="flex items-center justify-end gap-1.5" onClick={e => e.stopPropagation()}>
                        <button
                          onClick={() => {
                            const next = obj.priority === 'high' ? 'normal' : 'high';
                            StorageEngine.setObjectPriority(obj.id, next);
                            onNotify(
                              'info',
                              'Priority Updated',
                              `"${obj.originalName}" set to ${next === 'high' ? 'P1 High Priority (Heals first)' : 'P2 Standard'}.`
                            );
                          }}
                          title={obj.priority === 'high' ? 'Demote from High Priority' : 'Promote to High Priority (P1 Failover SLA)'}
                          className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                            obj.priority === 'high'
                              ? isDarkMode
                                ? 'text-amber-400 bg-amber-500/15 hover:bg-amber-500/25'
                                : 'text-amber-700 bg-amber-100 hover:bg-amber-200'
                              : isDarkMode
                              ? 'text-slate-400 hover:text-amber-400 hover:bg-slate-800'
                              : 'text-slate-600 hover:text-amber-700 hover:bg-slate-100'
                          }`}
                        >
                          <Flame className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setQrTargetObject(obj)}
                          title="Share Access Link via QR Code"
                          className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                            isDarkMode
                              ? 'text-slate-400 hover:text-cyan-400 hover:bg-slate-800'
                              : 'text-slate-600 hover:text-cyan-700 hover:bg-slate-100'
                          }`}
                        >
                          <QrCode className="w-3.5 h-3.5" />
                        </button>
                        {onOpenRecoveryWizard && (
                          <button
                            onClick={() => onOpenRecoveryWizard(obj.id)}
                            title={
                              obj.health === 'corrupt' || obj.chunks.some(c => c.isCorrupted)
                                ? 'Launch Recovery Wizard (Bit-Rot Detected)'
                                : 'Launch Quorum Recovery Wizard for this object'
                            }
                            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                              obj.health === 'corrupt' || obj.chunks.some(c => c.isCorrupted)
                                ? isDarkMode
                                  ? 'text-rose-400 bg-rose-500/20 hover:bg-rose-500/30 animate-pulse border border-rose-500/40'
                                  : 'text-rose-900 bg-rose-100 hover:bg-rose-200 animate-pulse border border-rose-300'
                                : isDarkMode
                                ? 'text-slate-400 hover:text-cyan-400 hover:bg-slate-800'
                                : 'text-slate-600 hover:text-cyan-700 hover:bg-slate-100'
                            }`}
                          >
                            <Wrench className="w-3.5 h-3.5" />
                          </button>
                        )}
                        <button
                          onClick={() => handlePreviewObject(obj)}
                          title="Preview Object Content"
                          className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                            isDarkMode
                              ? 'text-slate-400 hover:text-cyan-400 hover:bg-slate-800'
                              : 'text-slate-600 hover:text-cyan-700 hover:bg-slate-100'
                          }`}
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDownloadObject(obj)}
                          title="Verify & Download with Quorum"
                          className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                            isDarkMode
                              ? 'text-slate-400 hover:text-emerald-400 hover:bg-slate-800'
                              : 'text-slate-600 hover:text-emerald-700 hover:bg-slate-100'
                          }`}
                        >
                          <Download className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteObject(obj)}
                          title="Tombstone & Delete Replicas"
                          className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                            isDarkMode
                              ? 'text-slate-400 hover:text-rose-400 hover:bg-slate-800'
                              : 'text-slate-600 hover:text-rose-700 hover:bg-slate-100'
                          }`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
          </table>
        </div>

        {/* Selected Object Chunk Drill-Down Inspector */}
        {selectedObject && (
          <div className={`mt-6 pt-6 border-t space-y-4 animate-fadeIn ${isDarkMode ? 'border-slate-800/60' : 'border-slate-200'}`}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Layers className={`w-4 h-4 ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`} />
                <h4 className={`text-sm font-bold tracking-tight ${isDarkMode ? 'text-slate-100' : 'text-slate-900'}`}>
                  Shard Distribution Topology: {selectedObject.originalName}
                </h4>
              </div>
              <div className="flex items-center gap-2">
                {selectedObject.isEncrypted && (
                  <div className="flex items-center gap-2">
                    <span className={`text-xs font-mono ${isDarkMode ? 'text-slate-400' : 'text-slate-600 font-medium'}`}>Decrypt Key:</span>
                    <input
                      type="password"
                      value={decryptPassphrase}
                      onChange={e => setDecryptPassphrase(e.target.value)}
                      className={`px-2 py-1 text-xs rounded-lg font-mono outline-none border ${
                        isDarkMode
                          ? 'bg-slate-900 border-slate-700 text-slate-200'
                          : 'bg-white border-slate-300 text-slate-900 shadow-sm'
                      }`}
                    />
                  </div>
                )}
                <button
                  onClick={() => setQrTargetObject(selectedObject)}
                  className={`flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-lg border transition-colors cursor-pointer ${
                    isDarkMode
                      ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
                      : 'bg-white hover:bg-slate-100 text-slate-800 border-slate-300 shadow-sm'
                  }`}
                  title="Share Object Access via QR Code"
                >
                  <QrCode className={`w-3.5 h-3.5 ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`} />
                  <span>Share QR</span>
                </button>
                {onOpenRecoveryWizard && (
                  <button
                    onClick={() => onOpenRecoveryWizard(selectedObject.id)}
                    className={`flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-lg border transition-colors cursor-pointer ${
                      isDarkMode
                        ? 'bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 border-cyan-500/40'
                        : 'bg-cyan-100 hover:bg-cyan-200 text-cyan-900 border-cyan-300 font-bold shadow-sm'
                    }`}
                    title="Launch Guided Quorum Anti-Entropy Recovery Wizard"
                  >
                    <Wrench className={`w-3.5 h-3.5 ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`} />
                    <span>Recovery Wizard</span>
                  </button>
                )}
                <button
                  onClick={() => handleDownloadObject(selectedObject)}
                  className="flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white transition-colors cursor-pointer shadow-sm"
                >
                  <Download className="w-3.5 h-3.5" />
                  Fetch &amp; Quorum Verify
                </button>
              </div>
            </div>

            {/* Chunk Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {selectedObject.chunks.map((chunk, idx) => (
                <div
                  key={chunk.chunkId}
                  className={`p-3.5 rounded-2xl border text-xs font-mono transition-all ${
                    chunk.isCorrupted
                      ? isDarkMode
                        ? 'bg-rose-950/40 border-rose-600 text-rose-200'
                        : 'bg-rose-50 border-rose-300 text-rose-950 shadow-sm'
                      : isDarkMode
                      ? 'bg-slate-950/70 border-slate-800 text-slate-300'
                      : 'bg-white border-slate-300 text-slate-900 shadow-sm'
                  }`}
                >
                  <div className="flex items-center justify-between font-bold">
                    <span>
                      {chunk.isParity ? `Parity Shard #${idx + 1}` : `Data Shard #${chunk.chunkIndex + 1}`}
                    </span>
                    <span className={chunk.isCorrupted ? (isDarkMode ? 'text-rose-400 font-bold' : 'text-rose-700 font-bold') : (isDarkMode ? 'text-emerald-400' : 'text-emerald-700 font-bold')}>
                      {chunk.isCorrupted ? 'CHECKSUM FAIL' : 'HEALTHY'}
                    </span>
                  </div>

                  <div className={`mt-2 space-y-1 text-[11px] ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                    <div className="truncate">Digest: {chunk.sha256Hash.slice(0, 20)}...</div>
                    <div>Bytes: {chunk.sizeBytes} B</div>
                    <div className={`flex items-center gap-1 ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700 font-semibold'}`}>
                      <span>Nodes:</span>
                      <span className="font-semibold">{chunk.nodeIds.join(', ')}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Preview Modal */}
      {previewContent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div
            className={`w-full max-w-2xl rounded-3xl p-6 border shadow-2xl transition-all ${
              isDarkMode ? 'liquid-glass-dark border-slate-700 text-slate-100' : 'liquid-glass-light border-slate-300 text-slate-900 shadow-2xl'
            }`}
          >
            <div className={`flex items-center justify-between pb-4 border-b ${isDarkMode ? 'border-slate-800/60' : 'border-slate-200'}`}>
              <h4 className="text-base font-bold tracking-tight flex items-center gap-2">
                <FileText className={`w-4 h-4 ${isDarkMode ? 'text-cyan-400' : 'text-cyan-700'}`} />
                <span>Verified Preview: {previewContent.title}</span>
              </h4>
              <button
                onClick={() => setPreviewContent(null)}
                className={`px-3 py-1 text-xs rounded-lg transition-colors cursor-pointer ${
                  isDarkMode
                    ? 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    : 'bg-slate-200 text-slate-800 hover:bg-slate-300'
                }`}
              >
                Close
              </button>
            </div>
            <div className={`mt-4 max-h-96 overflow-y-auto font-mono text-xs p-4 rounded-xl border whitespace-pre-wrap ${
              isDarkMode
                ? 'bg-slate-950/80 border-slate-800 text-slate-200'
                : 'bg-slate-50 border-slate-300 text-slate-900'
            }`}>
              {previewContent.text ? (
                previewContent.text
              ) : previewContent.url ? (
                <div className="text-center py-6">
                  <p className={`mb-3 ${isDarkMode ? 'text-slate-400' : 'text-slate-600'}`}>Binary object verified against quorum.</p>
                  <a
                    href={previewContent.url}
                    download={previewContent.title}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold bg-cyan-600 hover:bg-cyan-500 text-white shadow-sm"
                  >
                    <Download className="w-4 h-4" /> Download File
                  </a>
                </div>
              ) : (
                'Object empty'
              )}
            </div>
          </div>
        </div>
      )}
      {/* QR Code Sharing Overlay Modal */}
      <QRCodeModal
        isOpen={!!qrTargetObject}
        onClose={() => setQrTargetObject(null)}
        object={qrTargetObject}
        isDarkMode={isDarkMode}
        onNotify={onNotify}
      />
    </div>
  );
}
