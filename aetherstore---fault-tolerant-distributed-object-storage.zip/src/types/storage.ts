export type NodeStatus = 'online' | 'degraded' | 'crashed' | 'partitioned';

export interface StorageNode {
  id: string;
  name: string;
  rack: 'Rack-Alpha' | 'Rack-Beta';
  zone: 'us-east-1a' | 'us-east-1b';
  status: NodeStatus;
  diskCapacityMB: number;
  diskUsedMB: number;
  chunksStored: number;
  latencyMs: number;
  uptimeSeconds: number;
  lastHeartbeat: number;
}

export interface ObjectChunk {
  chunkId: string;
  objectId: string;
  chunkIndex: number;
  totalChunks: number;
  isParity?: boolean;
  sizeBytes: number;
  sha256Hash: string;
  actualHash?: string;
  isCorrupted: boolean;
  nodeIds: string[]; // which nodes currently hold this replica
  dataBase64: string; // the chunk payload (or encrypted ciphertext)
}

export type DurabilityPolicyType = '3x_replication' | 'quorum_w2_r2_n3' | 'erasure_coding_4_2';

export interface DurabilityPolicy {
  id: DurabilityPolicyType;
  name: string;
  description: string;
  replicaCount: number;
  writeQuorum: number;
  readQuorum: number;
  dataShards: number;
  parityShards: number;
  storageOverhead: string;
  faultTolerance: string;
}

export interface EncryptionMeta {
  algorithm: 'AES-GCM-256';
  ivBase64: string;
  saltBase64: string;
  authTagVerified: boolean;
  keyFingerprint: string;
}

export interface ObjectVersion {
  version: number;
  timestamp: number;
  sizeBytes: number;
  etag: string;
  sha256Hash: string;
  policy: DurabilityPolicyType;
  authorEmail?: string;
  note?: string;
}

export interface StorageObject {
  id: string;
  key: string;
  bucket: string;
  originalName: string;
  mimeType: string;
  sizeBytes: number;
  createdAt: number;
  updatedAt: number;
  version: number;
  versions?: ObjectVersion[];
  policy: DurabilityPolicyType;
  isEncrypted: boolean;
  encryptionMeta?: EncryptionMeta;
  chunks: ObjectChunk[];
  etag: string;
  health: 'healthy' | 'degraded' | 'corrupt' | 'unavailable';
  priority?: 'high' | 'normal';
  ownerEmail?: string;
  ownerId?: string;
}

export type QuotaTier = 'Free' | 'Developer' | 'Pro' | 'Enterprise' | 'Custom';
export type QuotaEnforcementMode = 'hard' | 'soft';

export interface UserQuotaConfig {
  userId: string;
  userEmail: string;
  userName: string;
  role: 'admin' | 'user';
  storageQuotaMB: number;
  maxObjectsQuota: number; // 0 = unlimited
  tier: QuotaTier;
  enforcementMode: QuotaEnforcementMode;
  warningThresholdPercent: number; // e.g. 80
  updatedAt: number;
  lastUpdatedBy?: string;
}

export interface UserQuotaUsage {
  userId: string;
  userEmail: string;
  userName: string;
  role: 'admin' | 'user';
  storageQuotaMB: number;
  maxObjectsQuota: number;
  tier: QuotaTier;
  enforcementMode: QuotaEnforcementMode;
  warningThresholdPercent: number;
  usedBytes: number;
  usedMB: number;
  objectCount: number;
  usedPercent: number;
  objectsPercent: number;
  isOverStorageQuota: boolean;
  isOverObjectQuota: boolean;
  isNearQuotaLimit: boolean;
  updatedAt: number;
}

export interface ClusterEvent {
  id: string;
  timestamp: number;
  type: 'info' | 'warning' | 'error' | 'success' | 'healing';
  title: string;
  message: string;
  nodeId?: string;
  objectId?: string;
  hashExpected?: string;
  hashActual?: string;
  actionType?: 'hash_verification' | 'replica_repair' | 'bit_rot_detection' | 'quorum_consensus' | 'scrub' | 'rebalance';
}

export interface RepairJob {
  id: string;
  objectId: string;
  objectKey: string;
  chunkIndex: number;
  reason: 'bit_rot' | 'node_failure' | 'rebalance' | 'scrub';
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  sourceNodeId?: string;
  targetNodeId: string;
  progressPercent: number;
  startedAt: number;
  priority?: 'high' | 'normal';
}

export interface UserAccount {
  id: string;
  email: string;
  name: string;
  role?: 'admin' | 'user';
  avatar?: string;
  provider: 'local' | 'google' | 'biometric';
  hasBiometrics: boolean;
  passkeyCredentialId?: string;
  encryptionSalt: string;
  createdAt: number;
}

export interface BenchmarkMetrics {
  totalWrites: number;
  totalReads: number;
  successfulWrites: number;
  successfulReads: number;
  writeLatencyHistory: number[];
  readLatencyHistory: number[];
  opsPerSec: number;
  currentConcurrency: number;
  conflictsResolved: number;
}
